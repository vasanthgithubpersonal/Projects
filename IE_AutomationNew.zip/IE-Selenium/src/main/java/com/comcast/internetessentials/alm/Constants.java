/**
 *
 */
package com.comcast.internetessentials.alm;
import org.openqa.selenium.internal.Base64Encoder;
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;




import com.comcast.internetessentials.libraries.GetParameters;

/**
 *
 * These constants are used throughout the code to set the server to work with.
 * To execute this code, change these settings to fit those of your server.
 */
public class Constants {
    private Constants() {
    }

    public static final boolean VERSIONED = true;
    public static String AlmConfigpath = "C:/ALMConfig/ConfigFiles/AlmConfig";
    protected static GetParameters getParams = new GetParameters();
    static String File = "";

    // public static final String HOST = "almapp.comcast.net";
    /*
     * public static final String HOST = nodeFromKey(readfromConfigFile(),
     * "HOST =", "PORT").trim(); public static final String PORT =
     * nodeFromKey(readfromConfigFile(), "PORT =", "USERNAME").trim(); public
     * static final String USERNAME = nodeFromKey(readfromConfigFile(),
     * "USERNAME=", "PASSWORD").trim(); public static final String PASSWORD =
     * nodeFromKey(readfromConfigFile(), "PASSWORD=", "DOMAIN").trim(); //public
     * static final String USERNAME = "AutoRes_Update"; //public static final
     * String PASSWORD = ""; public static final String DOMAIN =
     * nodeFromKey(readfromConfigFile(), "DOMAIN=", "PROJECT=").trim(); public
     * static final String PROJECT = nodeFromKey(readfromConfigFile(),
     * "PROJECT=", "VERSIONED=").trim();
     */

    public static final String HOST = getParams.getEnvPerValue("ALM_HOST");
    public static final String PORT = getParams.getEnvPerValue("ALM_PORT");
    public static final String USERNAME = getParams.getEnvPerValue("ALM_USERNAME");
    public static final String PASSWORD = DecodeString(getParams.getEnvPerValue("ALM_PASSWORD"));
    // public static final String USERNAME = "AutoRes_Update";
    // public static final String PASSWORD = "";
    public static final String DOMAIN = getParams.getEnvPerValue("ALM_DOMAIN");
    public static final String PROJECT = getParams.getEnvPerValue("ALM_PROJECT");

	/**
	 * @return
	 */
    public final static String readfromConfigFile() {

	FileReader in = null;
	try {
	    in = new FileReader(AlmConfigpath + ".txt");
	} catch (FileNotFoundException e) {
	    // TODO Auto-generated catch block
	    e.printStackTrace();
	}
	BufferedReader br = new BufferedReader(in);
	String data;

	// System.out.println();
	try {
	    while ((data = br.readLine()) != null) {

		File = File + data;

	    }
	} catch (IOException e) {
	    // TODO Auto-generated catch block
	    e.printStackTrace();
	}
	try {
	    br.close();
	} catch (IOException e) {
	    // TODO Auto-generated catch block
	    e.printStackTrace();
	}
	// System.out.println("The File is"+File);
	return File;

    }

	/**
	 * @param xmlStr
	 * @param str1
	 * @param str2
	 * @return
	 */
    public static String nodeFromKey(String xmlStr, String str1, String str2) {
	int startPosition = 0;
	int endPosition = 0;
	startPosition = xmlStr.indexOf(str1) + str1.length();
	if (startPosition == -1) {
	    System.out.printf("No Value found for ::%s\n", str1);
	    return (null);

	}

	else if (xmlStr.indexOf(str1) == -1) {
	    System.out.printf("No Value found for ::%s\n", str1);
	    return (null);

	}

	endPosition = xmlStr.indexOf(str2, startPosition);
	if (endPosition == -1) {
	    System.out.printf("No Value found for ::%s\n", str2);
	    return (null);

	}
	// System.out.printf("endPosition value is :: %d\n",endPosition);
	String resultval = xmlStr.substring(startPosition, endPosition);
	// System.out.printf("Result value is :: %s\n",resultval);
	return (resultval);
    }
    
    public static String DecodeString(String input) {
		if (input != null && !input.equals("")) {
			return new String(new Base64Encoder().decode(input));
		} else {
			return "";
		}
	}

}