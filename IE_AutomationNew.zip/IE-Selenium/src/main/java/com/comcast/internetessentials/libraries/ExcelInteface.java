package com.comcast.internetessentials.libraries;

import java.io.FileInputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import org.apache.poi.hssf.usermodel.HSSFDateUtil;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

/**
 * The ExcelInteface program is implemented to interact with the external data
 * source. i.e Excel Sheet
 * 
 * @author 589478
 * @since 2017-02-23
 * @version 1.0
 */
public class ExcelInteface {

	protected XSSFWorkbook xssfWorkbook;
	protected XSSFSheet dataSheet;
	protected FileInputStream fileInputStream;
	protected String xlsPath;
	protected String xlsSheetName;

	/**
	 * Default Constructor
	 */
	public ExcelInteface() {
	}

	/**
	 * Parameterized Constructor Open the Work book and navigate to the sheet
	 * 
	 * @param xlsPath
	 *            (required) Excel path
	 * @param xlsSheetName
	 *            (required) Excel sheet name
	 */
	public ExcelInteface(String xlsPath, String xlsSheetName) {
		this.xlsPath = xlsPath;
		this.xlsSheetName = xlsSheetName;

		try {
			fileInputStream = new FileInputStream(xlsPath);
			xssfWorkbook = new XSSFWorkbook(fileInputStream);
		} catch (IOException e) {
			e.printStackTrace();
			throw new RuntimeException(e.getMessage());
		}
		dataSheet = xssfWorkbook.getSheet(xlsSheetName);
	}

	/**
	 * Get the Excel Row Number
	 * 
	 * @param ColNum
	 *            (required) Column Number to be specified
	 * @param RowValue
	 *            (required) Row text to be specified
	 * @return Row Number will be returned
	 */
	public Integer getRowNo(Integer ColNum, String RowValue) {
		int rNo = 2;
		for (Row row : dataSheet) {
			if (row.getCell(ColNum).getStringCellValue()
					.equalsIgnoreCase(RowValue)) {
				rNo = row.getRowNum();
				break;
			}
		}
		return rNo;
	}

	/**
	 * Get the Excel Row data
	 * 
	 * @param rowNo
	 *            (required) Row number to be specified
	 * @return Row will be returned
	 */
	public ArrayList<String> getRowValues(Integer rowNo) {
		ArrayList<String> rowList = new ArrayList<String>();
		Row row = dataSheet.getRow(rowNo);
		for (Cell cell : row) {

			switch (cell.getCellType()) {
			case Cell.CELL_TYPE_NUMERIC:
				if (HSSFDateUtil.isCellDateFormatted(cell)) {
					SimpleDateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy");
					rowList.add(dateFormat.format(cell.getDateCellValue()));
				}
				break;
			default:
				cell.setCellType(Cell.CELL_TYPE_STRING);
				rowList.add(cell.getStringCellValue().trim());
				break;
			}
		}
		return rowList;
	}
}
