package com.comcast.internetessentials.reporting;

import java.io.File;

public class ReportPath {
	private static ReportPath instance = null;
	private String reportPath;
	public static String RESULT_FOLDER = "Results";
	Util util = new Util();

	
	/**
	 * Default Constructor to create the Results folder
	 */
	@SuppressWarnings({ "unused", "static-access" })
	protected ReportPath() {
		String finalfolder = "Result_" + util.getTimeStamp();
		reportPath = System.getenv("RESULTPATH");
		if (reportPath == null || reportPath == "") {
			reportPath = util.getRelativePath() + File.separator
					+ RESULT_FOLDER + File.separator + finalfolder;
			(new File(reportPath)).mkdirs();
		} else {
			(new File(reportPath)).mkdirs();

		}
	}

	/**
	 * Get the current report folder
	 * 
	 * @return
	 */
	public String getReportPath() {
		return reportPath;
	}

	/**
	 * Function to get the report path instance
	 */
	public static synchronized ReportPath getInstance() {
		if (instance == null) {
			instance = new ReportPath();
		}
		return instance;
	}
}
