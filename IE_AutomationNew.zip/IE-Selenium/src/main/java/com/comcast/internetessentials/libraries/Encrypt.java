package com.comcast.internetessentials.libraries;

import java.awt.Image;

import javax.swing.Box;
import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPasswordField;
import javax.swing.JTextArea;

import org.apache.commons.codec.binary.Base64;


/**
 * The Encrypt program is implemented to encrypt the user cerdentials
 * 
 * @author 589478
 * @since 2017-03-06
 * @version 1.1
 */
public class Encrypt {

	public static void main(String[] args) {
		
		Box box = Box.createHorizontalBox();
	    JLabel label = new JLabel("Please enter your password : ");
	    box.add(label);
	    JPasswordField passwordField = new JPasswordField(24);
	    box.add(passwordField);

	    String relativePath = System.getProperty("user.dir");
	    relativePath = relativePath + "\\src\\test\\resources\\Logo\\InternetEssentials.png";
	    ImageIcon icon = new ImageIcon(relativePath);
	    Image image = icon.getImage();
	    Image newimg = image.getScaledInstance(140, 140,  java.awt.Image.SCALE_SMOOTH);
	    icon = new ImageIcon(newimg);
	    
	    int button = JOptionPane.showConfirmDialog(null, box, "Enter your password", JOptionPane.OK_CANCEL_OPTION, JOptionPane.INFORMATION_MESSAGE, icon);
	    if (button == JOptionPane.OK_OPTION) {
	        String password = new String(passwordField.getPassword());
	        String encryptedPassword;
	        if (password != null && !password.equals("")) {
	            byte[] bytesEncoded = Base64.encodeBase64(password.getBytes());
	            JTextArea richTextField = new JTextArea(10, 10);
	            encryptedPassword = new String(bytesEncoded);
	            richTextField.setText(encryptedPassword);
	            richTextField.setOpaque(false);
	            richTextField.setEditable(false);
	            JOptionPane.showMessageDialog(null, richTextField);
	        } else {
	            JOptionPane.showMessageDialog(null,
	                    "Password cannot be null. Please enter password to encrypt.");

			}
		}
	}

}
