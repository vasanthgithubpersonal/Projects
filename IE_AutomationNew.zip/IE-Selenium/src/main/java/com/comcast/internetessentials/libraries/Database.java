package com.comcast.internetessentials.libraries;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Date;

import org.apache.poi.util.SystemOutLogger;

import bsh.util.Util;

import com.microsoft.sqlserver.jdbc.SQLServerDataSource;
import com.microsoft.sqlserver.jdbc.SQLServerException;

/**
 * The Database program is implemented to interact with the database
 * 
 * @author 589478
 * @since 2017-03-06
 * @version 1.1
 */

public class Database {

	public static GetParameters getParams;
	protected ResultSet resultSet;
	protected Statement statement;
	public static Connection conn;
	SQLServerDataSource ds;
	String dbUserName = null;
	String dbPassword = null;
	String dbConnectedTo = null;
	String dbServerName = null;

	public final static int STATUS_MASTER_ID = 11;

	/**
	 * Parameterized Constructor Read data from the Properties file and
	 * Environments excel sheet
	 * 
	 * @param getparam
	 *            (required) GetParameters Instance
	 */

	public Database(GetParameters getparam) {
		this.getParams = getparam;
	}

	/**
	 * Establish the database connection
	 * 
	 * @param application
	 *            (required) Application to connect with database
	 */

	public void connectDataBase(String application) throws Exception {

		try {
			Class.forName(getParams.getEnvPerValue("JDBC_SQLSERVER_DRIVER"))
					.newInstance();

			ds = new SQLServerDataSource();
			ds.setUser(getParams.getEnvPerValue("DB_USERNAME"));
			ds.setPassword(Utilities.data.get("DB_PASSWORD"));
			ds.setServerName(getParams.getEnvPerValue("DB_SERVERNAME"));
			ds.setDatabaseName(getParams.getEnvPerValue("DATABASE_NAME"));
			conn = ds.getConnection();

			dbConnectedTo = application;
			System.out.println(dbConnectedTo + " DB connection is established");

		} catch (SQLServerException ex) {
			System.out
					.println("Could not be able to connect database. Please check the connection string parameters :"
							+ " Error Message : " + ex.getMessage());
		} catch (Exception ex) {
			System.out.println("ServiceName - Error Message : "
					+ ex.getMessage());
			throw new RuntimeException("Unable to connect database :"
					+ application);
		}

	}

	/**
	 * Close the database connection
	 */

	public static void disconnectDB() {
		if (conn != null) {
			try {
				conn.close();
				System.out.println("DB connection closed");
			} catch (SQLException e) {

				System.out.println(e.getMessage());
				System.out.println("Unable to close the connection");

			}
		}
	}

	/**
	 * It will execute the query and returns true if value found
	 * 
	 * @param tableName
	 *            (required) Table Name to be passed
	 * @param columnName
	 *            (required) Column Name to be passed
	 * @param columnValue
	 *            (required) Column Value to be passed
	 * 
	 * @return true/false If value found/If value not found
	 */
	public boolean IsDbValueExists(String tableName, String columnName,
			String columnValue) {
		try {
			PreparedStatement ps = null;
			String query = "SELECT TOP 1 " + columnName + " FROM " + tableName
					+ " WHERE " + columnName + " = ?;";

			ps = conn.prepareStatement(query);
			ps.setString(1, columnValue);
			ResultSet rs = ps.executeQuery();
			if (rs.next()) {
				return true;
			}
		} catch (SQLException ex) {
			System.out.println("Error in executing the query");
			ex.getStackTrace();
		}

		return false;
	}

	/**
	 * It will retrieve the column value from the database
	 * 
	 * @param tableName
	 *            (required) Table Name to be passed
	 * @param columnName
	 *            (required) Column Name to be passed
	 * @param applicationNumber
	 *            (required) Application Number to be passed
	 * 
	 * @return String Retrieve the Column Value
	 */

	public String getDbColumnValue(String tableName, String columnName) {

		String columnValue = null;
		String query = null;
		PreparedStatement ps = null;

		try {
			switch (columnName.toUpperCase()) {
			case "STATUS":
				query = "SELECT S.StatusDesc AS " + columnName + " ";
				query += "FROM " + tableName + " A ";
				query += "INNER JOIN StatusMaster S ";
				query += "ON A.StatusMasterId = S.StatusMasterId ";
				query += "WHERE A.ApplicationNumber = ? OR A.TelephoneNumber = ?;";
				break;

			case "ADDRESS":
				query = "SELECT CONCAT(StreetAddress,', ', UnitType,' ', UnitNumber,', ', ZipCode) AS "
						+ columnName + " ";
				query += "FROM " + tableName + " ";
				query += "WHERE ApplicationNumber = ? OR TelephoneNumber = ?;";
				break;

			default:
				query = "SELECT "+ columnName + " FROM " + tableName + " WHERE ApplicationNumber = ? OR TelephoneNumber = ?;";
				break;
			}
			System.out.println("SQL Query is: " + query);
			if (Utilities.applicationNumber != null
					|| Utilities.telephoneNumber != null) {
				ps = conn.prepareStatement(query);
				ps.setString(1, Utilities.applicationNumber);
				ps.setString(2, Utilities.telephoneNumber);
				ResultSet rs = ps.executeQuery();
				if (rs.next()) {
					columnValue = rs.getString(columnName);
					return columnValue;
				}
			} else {
				System.out.println("Application Number or Telephone Number is null");
			}
		}

		catch (Exception ex) {
			System.out.println(ex.getMessage());
		}
		return columnValue;

	}

	/**
	 * It will update the application status based on the Application Number
	 * provided
	 * 
	 * @param applicationNumber
	 *            (required) Application Number to be passed
	 */

	public void updateApplicationStatus(String applicationNumber) {
		try {
			PreparedStatement ps = null;

			String query = "UPDATE Application SET StatusMasterId = "
					+ STATUS_MASTER_ID + " where ApplicationNumber = ? OR TelephoneNumber = ?;";

			ps = conn.prepareStatement(query);
			ps.setString(1, Utilities.applicationNumber);
			ps.setString(2, Utilities.telephoneNumber);
			int rowCount = ps.executeUpdate();

			if (rowCount >= 1) {
				System.out
						.println("Status Master Id column is updated successfully for this application number = "
								+ Utilities.applicationNumber);
			} else {
				System.out
						.println("Status Master Id column is not updated successfully for this application number = "
								+ Utilities.applicationNumber);
			}

		} catch (SQLException ex) {
			ex.printStackTrace();
		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}
}
