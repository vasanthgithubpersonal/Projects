package com.comcast.internetessentials.libraries;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.Random;

import org.apache.commons.codec.binary.Base64;

import com.comcast.internetessentials.online.pages.BasicDetails;
import com.comcast.internetessentials.online.pages.PersonalDetails;
import com.google.common.base.Objects;

/**
 * The Utilities program is implemented which contains all the common reusable
 * methods
 * 
 * @author 589478
 * @since 2017-03-03
 * @version 1.0
 */

public class Utilities extends Reports {
	// protected EnvironmentParameters envParameters = new
	// EnvironmentParameters();
	public static GetParameters getParams;
	private Database db = new Database(getparams);
	public static String applicationNumber = null;
	public static String telephoneNumber = null;

	public static HashMap<String, String> data = new HashMap<String, String>();

	/**
	 * Default Constructor It will load the test data for IE application
	 */

	public Utilities(GetParameters getParameters) {
		super(getParameters);
		testDataPreparation();
		Utilities.getParams = getParameters;

	}

	private synchronized void testDataPreparation() {
	
		firstName();
		lastName();
		emailAddress();
		phoneNumber();
		hearAboutIE();
		InternetServiceProvider();
		SocialSecurityNumber();
		DOB();
		decrypt();

	}

	/**
	 * This program will generate random strings
	 * 
	 * @param name
	 *            (required) Length to be passed
	 */
	private String getRandomString(int length) {
		String characters = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
		Random random = new Random();
		StringBuilder sb = new StringBuilder();

		for (int i = 0; i < length; i++) {
			sb.append(characters.charAt(random.nextInt(characters.length())));
		}
		return sb.toString();
	}

	/**
	 * This program will generate random date
	 * 
	 * @param startYear
	 *            (required) Maximum year to be passed
	 * 
	 * @param endYear
	 *            (required) Minimum year to be passed
	 */
	private String getRandomDate(int startYear, int endYear) {

		DateFormat formatter = new SimpleDateFormat("MM/dd/yyyy");
		GregorianCalendar calendar = new GregorianCalendar();

		int year = getYearRange(startYear, endYear);
		calendar.set(Calendar.YEAR, year);
		int dayOfYear = getYearRange(1,
				calendar.getActualMaximum(Calendar.DAY_OF_YEAR));

		calendar.set(Calendar.DAY_OF_YEAR, dayOfYear);
		String date = null;
		if (calendar.get(Calendar.MONTH) == 0) {
			date = formatter.format(calendar.getTime());
		} else {
			date = formatter.format(calendar.getTime());
		}
		return date;
	}

	/**
	 * This program will generate random year
	 * 
	 * @param start
	 *            (required) Maximum year to be passed
	 * 
	 * @param end
	 *            (required) Minimum year to be passed
	 */
	private int getYearRange(int start, int end) {
		return start + (int) Math.round(Math.random() * (end - start));
	}

	/**
	 * This program will generate random strings for FirstName
	 */
	private void firstName() {
		set("FIRSTNAME", "AutoFirst" + getRandomString(5));
	}

	/**
	 * This program will generate random strings for LastName
	 */
	private void lastName() {
		set("LASTNAME", "AutoLast" + getRandomString(5));
	}

	/**
	 * This program will generate random telephone numbers
	 */
	public void phoneNumber() {
		Random random = new Random();
		int number = random.nextInt(900000000) + 1000000000;
		set("PHONENUMBER", Integer.toString(number));
	}

	/**
	 * This program will generate random email address
	 */
	private void emailAddress() {
		set("EMAIL", getRandomString(5) + "@gmail.com");
	}

	/**
	 * This program will generate random date of birth
	 */
	private void DOB() {
		int minYear = 1899;
		int maxYear = 1937;
		String dateOfBirth = null;
		dateOfBirth = getRandomDate(maxYear, minYear);
		set("DOB", dateOfBirth);
	}

	/**
	 * This program will get any of the random values from an array
	 */
	private void hearAboutIE() {

		String[] arr = new String[] { "Family/Friends", "My child's school",
				"Community Groups/Non-Profit", "TV", "Radio", "Newspaper",
				"Online", "Other" };

		int index = new Random().nextInt(arr.length);
		set("HEAR_ABOUT_IE", arr[index]);

	}

	/**
	 * This program will get the random Internet Service Provider
	 */
	private void InternetServiceProvider() {
		String[] serviceProvider = new String[] {
				"I don't currently have home Internet", "Verizon FiOS",
				"AT&T Uverse", "Century Link", "WOW", "MediaComm", "Frontier",
				"Suddenlink", "Brighthouse", "Other" };

		int index = new Random().nextInt(serviceProvider.length);
		set("INTERNET_SERVICE_PROVIDER", serviceProvider[index]);

	}

	/**
	 * This program will generate random SSN
	 */	
	private void SocialSecurityNumber() {
		String SSNNumber = String.format("%09d",
				new Random().nextInt(1000000000));
		set("SSN", SSNNumber);
	}
	
	/*private void SocialSecurityNumber() {
		String SSNNumber = "";
		SSNNumber = getparams.getTestPerValue("SSNValue");	//This is temporary arrangement until delete/cancel calls are automated
		if(SSNNumber.isEmpty() || SSNNumber.toUpperCase().trim() == "NA"){
		SSNNumber = String.format("%09d",
				new Random().nextInt(1000000000));
		}
		set("SSN", SSNNumber.replace("-", ""));
	}*/
	/*@SuppressWarnings("unused")
	private String getLastFourDigitSSN(){
		String SSN = get("SSN");
		SSN = SSN.substring(6, 9);
		return SSN;
	}*/
	
	/**
	 * This program will decrypt the User credentials
	 */	
	public void decrypt() {
		 String agentPassword = getparams.getEnvPerValue("AGENT_PASSWORD") + "_AgentPassword";
		 String dbPassword = getparams.getEnvPerValue("DB_PASSWORD") + "_dbPassword";

		 
		decryptPassword(agentPassword);
		decryptPassword(dbPassword);
		
	}
	
	/**
	 * This program will decrypt the User credentials
	 * 
	 * @param password
	 *            (required) Encrypted password to be passed
	 */	
	private void decryptPassword(String password) {
		
		String[] arrPassword = null;

		if(password.toLowerCase().contains("agentpassword")){
			arrPassword = password.split("_");
		}
		else if(password.toLowerCase().contains("_dbpassword")){
			arrPassword = password.split("_");
		}
		byte[] passwordDecoded = Base64.decodeBase64(arrPassword[0]);
		String plainText = new String(passwordDecoded);
		
		if(password.toLowerCase().contains("agentpassword")){
			set("AGENT_PASSWORD", plainText);	
		}else{
			set("DB_PASSWORD", plainText);
		}
		
	}

	/**
	 * This program will generate the random number
	 * 
	 * @param size
	 *            (required) Size to be passed
	 * 
	 * @return int 
	 * 			Returns the random number
	 */	
	public int getRandomNumber(int size) {
		int a;
		Random rdm = new Random();
		return a = rdm.nextInt(size) - 1;
	}

	/**
	 * This program sets the Application status
	 * 
	 * @param applicationState
	 *            (required) Application State to be passed
	 * @param ssn
	 *            (required) SSN to be passed
	 * @param autoApproved
	 *            (required) AutoApproved to be passed
	 */	
	
	public void setApplicationStatus(String applicationState, String ssn,
			String autoApproved) {
		switch (applicationState) {
		case "Submitted":

			if (ssn.isEmpty() || ssn.equalsIgnoreCase("no")) {
				if (autoApproved.equalsIgnoreCase("no")) {
					set("APPLICATION_STATUS", "Pending Verification Docs and ID");
					set("AUTO_APPROVED", "N");
				} else {
					set("APPLICATION_STATUS", "Pending Verification - ID");
					set("AUTO_APPROVED", "Y");
				}
			} else {
				if (autoApproved.equalsIgnoreCase("no")) {
					set("APPLICATION_STATUS", "Pending Verification - Docs");
					set("AUTO_APPROVED", "N");
				} else {
					set("APPLICATION_STATUS", "Approved");
					set("AUTO_APPROVED", "Y");
				}
			}
			break;

		case "Saved":
			set("APPLICATION_STATUS", "Saved");
			set("AUTO_APPROVED", "NULL");
			break;

		case "Initiated":
			set("APPLICATION_STATUS", "Initiated");
			set("AUTO_APPROVED", "NULL");
			break;
		}
	}

	/**
	 * This program is to verify the value against database
	 * 
	 * @param tableName
	 *            (required) tableName to be passed
	 * @param columnName
	 *            (required) columnName to be passed
	 * @param expectedResult
	 *            (required) expectedResult to be passed
	 */	
	
	public void verifyDBValue(String tableName, String columnName,
			String expectedResult) {
		String actualResult = db.getDbColumnValue(tableName, columnName);

		if (Objects.equal(expectedResult, actualResult)) {
			reportPassEvent(columnName, actualResult, expectedResult);
		} else {
			reportFailEvent(columnName, actualResult, expectedResult);
		}

	}
	
	/**
	 * This program is to verify the BasicDetailsPage data against database
	 */	

	public void verifyBasicDetailsPage() {
		String tableName = "Application";

		verifyDBValue(tableName, "FirstName", get("FIRSTNAME"));
		verifyDBValue(tableName, "LastName", get("LASTNAME"));
		verifyDBValue(tableName, "TelephoneNumber", get("PHONENUMBER"));

		if (getparams.getTestPerValue("Email").equalsIgnoreCase("yes")) {
			verifyDBValue(tableName, "Email", get("EMAIL"));
		} else {
			verifyDBValue(tableName, "Email", null);
		}

		verifyDBValue(tableName, "Address", get("ADDRESS"));
	}

	/**
	 * This program is to verify the PersonalDetailsPage data against database
	 */	
	public void verifyPersonalDetailsPage() {
		String tableName = "Application";

		verifyDBValue("Application", "DateOfBirth",getDateFormat(get("DOB"), "YYYY-MM-DD"));
		
		// SSN expected and Actual values will not displayed in the reports
		// because of the encryption
		String ssn = db.getDbColumnValue(tableName, "SSN");
		if (getparams.getTestPerValue("SSN").equalsIgnoreCase("yes")
				&& ssn != null) {
			report.reportPassEvent("SSN  Verification","Expected and Actual are same");
		} else if (getparams.getTestPerValue("SSN").equalsIgnoreCase("no")
				&& ssn == null) {
			report.reportPassEvent("SSN  Verification",
					"Expected and Actual are same");
		} else {
			report.reportSoftFailEvent("SSN  Verification",
					"Expected and Actual are not same");
		}
		verifyDBValue(tableName, "HearAboutIE", get("HEAR_ABOUT_IE"));
		verifyDBValue(tableName, "HaveServiceFromOtherProvider",
				get("INTERNET_SERVICE_PROVIDER"));
	}
	
	/**
	 * This program is for report done event
	 */	

	public void reportDoneEvent(String fieldName, String text) {
		report.reportDoneEvent(fieldName, text);
	}
	
	/**
	 * This program is for report pass event
	 */

	public void reportPassEvent(String columnName, String expected,
			String actual) {
		report.reportPassEvent(columnName + " Verification", "Expected : "
				+ expected + " and Actual : " + actual + " are same");
	}

	/**
	 * This program is for report fail event
	 */
	
	public void reportFailEvent(String columnName, String actual,
			String expected) {
		report.reportSoftFailEvent(columnName + " Verification", "Expected : "
				+ expected + " and Actual : " + actual + " are not same");
	}

	/**
	 * This program is to get the date format
	 * 
	 * @param date
	 *            (required) Date to be passed
	 * @param format
	 *            (required) Format to be passed
	 *            
	 * @return String 
	 * 			Returns the new Date
	 */	
	
	public String getDateFormat(String date, String format) {
		String newDate = null;
		switch (format.toUpperCase()) {
		case "YYYY-MM-DD":
			String[] arr = PersonalDetails.DOB.split("/");
			newDate = arr[2] + "-" + arr[0] + "-" + arr[1];
			break;
		case "MM/DD/YYYY":
			newDate = PersonalDetails.DOB;
			break;
		}
		return newDate;
	}

	/**
	 * This program is to get the random file name
	 */	
	public String getRandomFileName() {
		String[] fileName = new String[] { "Chrysanthemum.jpg", "Desert.jpg",
				"Lighthouse.jpg", "Penguins.jpg", "Test.pdf" };
		int index = new Random().nextInt(fileName.length);
		return fileName[index];
	}

	/**
	 * Assign the key and value for the test data
	 * 
	 * @param key
	 *            (required) Key to be passed
	 * @param key
	 *            (required) Value to be passed
	 * 
	 */
	public void set(String key, String value) {
		if (key != null)
			data.put(key, value);
	}

	/**
	 * Retrieve the value based on the key passed
	 * 
	 * @param key
	 *            (required) Key to be passed
	 */
	public String get(String key) {
		if (key != null)
			return data.get(key.toUpperCase());
		else
			return null;
	}
}
