package com.comcast.internetessentials.online.pages;

import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;

import com.comcast.internetessentials.libraries.GetParameters;
import com.comcast.internetessentials.libraries.Reports;
import com.comcast.internetessentials.libraries.Utilities;
import com.comcast.internetessentials.reporting.SeleniumReport;

public class DocumentsUpload extends Documents {
	
	public static String expectedDocsText = "";

	@FindBy(xpath = "//*[@id='terms']")
	@CacheLookup
	protected WebElement _docConfirm;
	
	@FindBy(xpath = "//*[@id='FileUploadSave']")
	@CacheLookup
	protected WebElement _docSave;
	
	/*@FindBy(xpath = "//*[@id='submitbtn']")
	@CacheLookup
	protected WebElement _docNext;*/
	
	@FindBy(id = "submitbtn")
	@CacheLookup
	protected WebElement _docNext;
	
	
	@FindBy(xpath = "//*[@id='SaveOkBtn']")
	@CacheLookup
	private WebElement _popupOk;
	
	@FindBy(xpath = "//span[@id = 'applicationSavedID']")
	@CacheLookup
	private WebElement _applicationNumber;
	
	public DocumentsUpload(WebDriver browser, GetParameters params) {
		super(browser, params);
	}

	public void programTypesDocumentUploadPage() {

		
		waitforPageLoadComplete();
		report.addTestLogSection("Documents Upload Page");
		try {
			String documentsList = getParams
					.getTestPerValue("DocumentsToUpload");
			String[] documents = documentsList.split(",");
			for (int i = 0; i < documents.length; i++) {

				if (documents[i].startsWith("NSLP")) {
					expandProgramType(NSLP_ACCORDIAN);
				} else if (documents[i].startsWith("HUD")) {
					expandProgramType(HUD_ACCORDIAN);
				} else if (documents[i].startsWith("SR")) {
					expandProgramType(SR_ACCORDIAN);
				} else if (documents[i].startsWith("CC")) {
					expandProgramType(CC_ACCORDIAN);
				}

				switch (documents[i]) {
				case "NSLP_CURRENT_PARTICIPATION":
					if (getParams.getTestPerValue("NSLP").equalsIgnoreCase(
							"yes")
							&& getParams.getTestPerValue("DocUploadButton")
									.equalsIgnoreCase("fileuploadnow")) {
						uploadProgramDocuments(NSLP_CURRENT_PARTICIPATION,
								NSLP_CURRENT_PARTICIPATION_FILE_UPLOAD,
								"NSLP Current Participation");
						expectedDocsText += "NSLP or Head Start participation letter:";
					}
					break;

				case "NSLP_SNAP":
					if (getParams.getTestPerValue("NSLP").equalsIgnoreCase(
							"yes")
							&& getParams.getTestPerValue("DocUploadButton")
									.equalsIgnoreCase("fileuploadnow")) {
						uploadProgramDocuments(NSLP_SNAP,
								NSLP_SNAP_FILE_UPLOAD, "NSLP SNAP");
					}
					break;

				case "NSLP_TANF":
					if (getParams.getTestPerValue("NSLP").equalsIgnoreCase(
							"yes")
							&& getParams.getTestPerValue("DocUploadButton")
									.equalsIgnoreCase("fileuploadnow")) {
						uploadProgramDocuments(NSLP_TANF,
								NSLP_TANF_FILE_UPLOAD, "NSLP TANF");

					}
					break;
				case "NSLP_FDPIR":
					if (getParams.getTestPerValue("NSLP").equalsIgnoreCase(
							"yes")
							&& getParams.getTestPerValue("DocUploadButton")
									.equalsIgnoreCase("fileuploadnow")) {

						uploadProgramDocuments(NSLP_FDPIR,
								NSLP_FDPIR_FILE_UPLOAD, "NSLP FDPIR");

					}
					break;
				case "NSLP_REPORTCARD":
					if (getParams.getTestPerValue("NSLP").equalsIgnoreCase(
							"yes")
							&& getParams.getTestPerValue("DocUploadButton")
									.equalsIgnoreCase("fileuploadnow")) {

						uploadProgramDocuments(NSLP_REPORTCARD,
								NSLP_REPORTCARD_FILE_UPLOAD, "NSLP Report card");
						
						expectedDocsText += "Student's recent progress or report card:";


					}
					break;
				case "NSLP_STUDENTID":
					if (getParams.getTestPerValue("NSLP").equalsIgnoreCase(
							"yes")
							&& getParams.getTestPerValue("DocUploadButton")
									.equalsIgnoreCase("fileuploadnow")) {

						uploadProgramDocuments(NSLP_STUDENTID,
								NSLP_STUDENTID_FILE_UPLOAD, "NSLP Student Id");
						
						expectedDocsText += "Student ID:";

					}
					break;
				case "NSLP_SCHOOL_LETTER":
					if (getParams.getTestPerValue("NSLP").equalsIgnoreCase(
							"yes")
							&& getParams.getTestPerValue("DocUploadButton")
									.equalsIgnoreCase("fileuploadnow")) {

						uploadProgramDocuments(NSLP_SCHOOL_LETTER,
								NSLP_SCHOOL_LETTER_FILE_UPLOAD,
								"NSLP School Letter");
						
						expectedDocsText += "Student bonafide letter from school:";

					}
					break;
				case "NSLP_HOMESCHOOL_SNAP":
					if (getParams.getTestPerValue("NSLP").equalsIgnoreCase(
							"yes")
							&& getParams.getTestPerValue("DocUploadButton")
									.equalsIgnoreCase("fileuploadnow")) {
						uploadProgramDocuments(NSLP_HOMESCHOOL_SNAP,
								NSLP_HOMESCHOOL_SNAP_FILE_UPLOAD,
								"NSLP HomeSchool SNAP");
						
						

					}
					break;
				case "NSLP_HOMESCHOOL_TANF":
					if (getParams.getTestPerValue("NSLP").equalsIgnoreCase(
							"yes")
							&& getParams.getTestPerValue("DocUploadButton")
									.equalsIgnoreCase("fileuploadnow")) {

						uploadProgramDocuments(NSLP_HOMESCHOOL_TANF,
								NSLP_HOMESCHOOL_TANF_FILE_UPLOAD,
								"NSLP HomeSchool TANF");

					}
					break;
				case "NSLP_HOMESCHOOL_FDPIR":
					if (getParams.getTestPerValue("NSLP").equalsIgnoreCase(
							"yes")
							&& getParams.getTestPerValue("DocUploadButton")
									.equalsIgnoreCase("fileuploadnow")) {
						uploadProgramDocuments(NSLP_HOMESCHOOL_FDPIR,
								NSLP_HOMESCHOOL_FDPIR_FILE_UPLOAD,
								"NSLP HomeSchool FDPIR");

					}
					break;
				case "NSLP_HOMESCHOOL_WAIVER":
					if (getParams.getTestPerValue("NSLP").equalsIgnoreCase(
							"yes")
							&& getParams.getTestPerValue("DocUploadButton")
									.equalsIgnoreCase("fileuploadnow")) {
						uploadProgramDocuments(NSLP_HOMESCHOOL_WAIVER,
								NSLP_HOMESCHOOL_WAIVER_FILE_UPLOAD,
								"NSLP HomeSchool Waiver");
						
						expectedDocsText += "Homeschool waiver document from state or district:";
						
					}
					break;

				case "NSLP_HOMESCHOOL_PROOF_OF_PARTICIPATION":
					if (getParams.getTestPerValue("NSLP").equalsIgnoreCase(
							"yes")
							&& getParams.getTestPerValue("DocUploadButton")
									.equalsIgnoreCase("fileuploadnow")) {
						uploadProgramDocuments(
								NSLP_HOMESCHOOL_PROOF_OF_PARTICIPATION,
								NSLP_HOMESCHOOL_PROOF_OF_PARTICIPATION_FILE_UPLOAD,
								"NSLP HomeSchool Proof of Participation");
						
						expectedDocsText += "Homeschool club, association or organization participation letter:";
					}
					break;

				// HUD
				case "HUD_PUBLIC_LEASE":
					if (getParams.getTestPerValue("HUD")
							.equalsIgnoreCase("yes")
							&& getParams.getTestPerValue("DocUploadButton")
									.equalsIgnoreCase("fileuploadnow")) {
						uploadProgramDocuments(HUD_PUBLIC_LEASE,
								HUD_PUBLIC_LEASE_FILE_UPLOAD,
								"HUD Public Lease");
					}
					break;
				case "HUD_PUBLIC_TIC_FORM":
					if (getParams.getTestPerValue("HUD")
							.equalsIgnoreCase("yes")
							&& getParams.getTestPerValue("DocUploadButton")
									.equalsIgnoreCase("fileuploadnow")) {
						uploadProgramDocuments(HUD_PUBLIC_TIC_FORM,
								HUD_PUBLIC_TIC_FORM_FILE_UPLOAD,
								"HUD Public TIC");
					}
					break;
				case "HUD_PUBLIC_RENT_STATEMENT":
					if (getParams.getTestPerValue("HUD")
							.equalsIgnoreCase("yes")
							&& getParams.getTestPerValue("DocUploadButton")
									.equalsIgnoreCase("fileuploadnow")) {
						uploadProgramDocuments(HUD_PUBLIC_RENT_STATEMENT,
								HUD_PUBLIC_RENT_STATEMENT_FILE_UPLOAD,
								"HUD Public Rent Statement");
					}
					break;
				case "HUD_PUBLIC_RENT_LETTER":
					if (getParams.getTestPerValue("HUD")
							.equalsIgnoreCase("yes")
							&& getParams.getTestPerValue("DocUploadButton")
									.equalsIgnoreCase("fileuploadnow")) {
						uploadProgramDocuments(HUD_PUBLIC_RENT_LETTER,
								HUD_PUBLIC_RENT_LETTER_FILE_UPLOAD,
								"HUD Public Rent");
					}
					break;
				case "HUD_HOUSING_CHOICE_LEASE":
					if (getParams.getTestPerValue("HUD")
							.equalsIgnoreCase("yes")
							&& getParams.getTestPerValue("DocUploadButton")
									.equalsIgnoreCase("fileuploadnow")) {
						uploadProgramDocuments(HUD_HOUSING_CHOICE_LEASE,
								HUD_HOUSING_CHOICE_LEASE_FILE_UPLOAD,
								"HUD Housing Choice Lease");
					}
					break;
				case "HUD_HOUSING_CHOICE_TIC_FORM":
					if (getParams.getTestPerValue("HUD")
							.equalsIgnoreCase("yes")
							&& getParams.getTestPerValue("DocUploadButton")
									.equalsIgnoreCase("fileuploadnow")) {
						uploadProgramDocuments(HUD_HOUSING_CHOICE_TIC_FORM,
								HUD_HOUSING_CHOICE_TIC_FORM_FILE_UPLOAD,
								"HUD Housing Choice TIC");
					}
					break;
				case "HUD_HOUSING_CHOICE_VOUCHER_FORM":
					if (getParams.getTestPerValue("HUD")
							.equalsIgnoreCase("yes")
							&& getParams.getTestPerValue("DocUploadButton")
									.equalsIgnoreCase("fileuploadnow")) {
						uploadProgramDocuments(HUD_HOUSING_CHOICE_VOUCHER_FORM,
								HUD_HOUSING_CHOICE_VOUCHER_FORM_FILE_UPLOAD,
								"HUD Housing Choice Voucher");
					}
					break;
				case "HUD_HOUSING_CHOICE_FAMILY_REPORT":
					if (getParams.getTestPerValue("HUD")
							.equalsIgnoreCase("yes")
							&& getParams.getTestPerValue("DocUploadButton")
									.equalsIgnoreCase("fileuploadnow")) {
						uploadProgramDocuments(
								HUD_HOUSING_CHOICE_FAMILY_REPORT,
								HUD_HOUSING_CHOICE_FAMILY_REPORT_FILE_UPLOAD,
								"HUD Housing Choice Family");
					}
					break;
				case "HUD_HOUSING_CHOICE_LEASE_UP_DOC":
					if (getParams.getTestPerValue("HUD")
							.equalsIgnoreCase("yes")
							&& getParams.getTestPerValue("DocUploadButton")
									.equalsIgnoreCase("fileuploadnow")) {
						uploadProgramDocuments(HUD_HOUSING_CHOICE_LEASE_UP_DOC,
								HUD_HOUSING_CHOICE_LEASE_UP_DOC_FILE_UPLOAD,
								"HUD Housing Choice Lease Up");
					}
					break;
				case "HUD_MULTIFAMILY_LEASE":
					if (getParams.getTestPerValue("HUD")
							.equalsIgnoreCase("yes")
							&& getParams.getTestPerValue("DocUploadButton")
									.equalsIgnoreCase("fileuploadnow")) {
						uploadProgramDocuments(HUD_MULTIFAMILY_LEASE,
								HUD_MULTIFAMILY_LEASE_FILE_UPLOAD,
								"HUD Multifamily Lease");
					}
					break;
				case "HUD_MULTIFAMILY_TIC_FORM":
					if (getParams.getTestPerValue("HUD")
							.equalsIgnoreCase("yes")
							&& getParams.getTestPerValue("DocUploadButton")
									.equalsIgnoreCase("fileuploadnow")) {
						uploadProgramDocuments(HUD_MULTIFAMILY_TIC_FORM,
								HUD_MULTIFAMILY_TIC_FORM_FILE_UPLOAD,
								"HUD Multifamily TIC");
					}
					break;
				case "HUD_MULTIFAMILY_HAP":
					if (getParams.getTestPerValue("HUD")
							.equalsIgnoreCase("yes")
							&& getParams.getTestPerValue("DocUploadButton")
									.equalsIgnoreCase("fileuploadnow")) {
						uploadProgramDocuments(HUD_MULTIFAMILY_HAP,
								HUD_MULTIFAMILY_HAP_FILE_UPLOAD,
								"HUD Multifamily HAP");
					}
					break;
				case "HUD_MULTIFAMILY_TENENT_ELIGIBILITY":
					if (getParams.getTestPerValue("HUD")
							.equalsIgnoreCase("yes")
							&& getParams.getTestPerValue("DocUploadButton")
									.equalsIgnoreCase("fileuploadnow")) {
						uploadProgramDocuments(
								HUD_MULTIFAMILY_TENENT_ELIGIBILITY,
								HUD_MULTIFAMILY_TENENT_ELIGIBILITY_FILE_UPLOAD,
								"HUD Tenent Eligibility");
					}
					break;

				// SENIOR PROGRAM
				case "SR_LICENSE":
					if (getParams.getTestPerValue("SR").equalsIgnoreCase("yes")
							&& getParams.getTestPerValue("DocUploadButton")
									.equalsIgnoreCase("fileuploadnow")) {
						uploadProgramDocuments(SR_LICENSE,
								SR_LICENSE_FILE_UPLOAD, "SR License");
					}
					break;
				case "SR_STATE_ID":
					if (getParams.getTestPerValue("SR").equalsIgnoreCase("yes")
							&& getParams.getTestPerValue("DocUploadButton")
									.equalsIgnoreCase("fileuploadnow")) {
						uploadProgramDocuments(SR_STATE_ID,
								SR_STATE_ID_FILE_UPLOAD, "SR State Id");
					}
					break;
				case "SR_PASSPORT":
					if (getParams.getTestPerValue("SR").equalsIgnoreCase("yes")
							&& getParams.getTestPerValue("DocUploadButton")
									.equalsIgnoreCase("fileuploadnow")) {
						uploadProgramDocuments(SR_PASSPORT,
								SR_PASSPORT_FILE_UPLOAD, "SR Passport");
					}
					break;
				case "SR_BIRTH_CERTIFICATE":
					if (getParams.getTestPerValue("SR").equalsIgnoreCase("yes")
							&& getParams.getTestPerValue("DocUploadButton")
									.equalsIgnoreCase("fileuploadnow")) {
						uploadProgramDocuments(SR_BIRTH_CERTIFICATE,
								SR_BIRTH_CERTIFICATE_FILE_UPLOAD,
								"SR Birth Certificate");
					}
					break;
				case "SR_VOTER_CARD":
					if (getParams.getTestPerValue("SR").equalsIgnoreCase("yes")
							&& getParams.getTestPerValue("DocUploadButton")
									.equalsIgnoreCase("fileuploadnow")) {
						uploadProgramDocuments(SR_VOTER_CARD,
								SR_VOTER_CARD_FILE_UPLOAD, "SR Voter Card");
					}
					break;
				case "SR_FEDERAL_MEDICAID":
					if (getParams.getTestPerValue("SR").equalsIgnoreCase("yes")
							&& getParams.getTestPerValue("DocUploadButton")
									.equalsIgnoreCase("fileuploadnow")) {
						uploadProgramDocuments(SR_FEDERAL_MEDICAID,
								SR_FEDERAL_MEDICAID_FILE_UPLOAD, "SR Medicaid");
					}
					break;
				case "SR_FEDERAL_SNAP":
					if (getParams.getTestPerValue("SR").equalsIgnoreCase("yes")
							&& getParams.getTestPerValue("DocUploadButton")
									.equalsIgnoreCase("fileuploadnow")) {
						uploadProgramDocuments(SR_FEDERAL_SNAP,
								SR_FEDERAL_SNAP_FILE_UPLOAD, "SR SNAP");
					}
					break;

				case "SR_FEDERAL_SSI":
					if (getParams.getTestPerValue("SR").equalsIgnoreCase("yes")
							&& getParams.getTestPerValue("DocUploadButton")
									.equalsIgnoreCase("fileuploadnow")) {
						uploadProgramDocuments(SR_FEDERAL_SSI,
								SR_FEDERAL_SSI_FILE_UPLOAD, "SR SSI");
					}
					break;
				case "SR_FEDERAL_SECTION8":
					if (getParams.getTestPerValue("SR").equalsIgnoreCase("yes")
							&& getParams.getTestPerValue("DocUploadButton")
									.equalsIgnoreCase("fileuploadnow")) {
						uploadProgramDocuments(SR_FEDERAL_SECTION8,
								SR_FEDERAL_SECTION8_FILE_UPLOAD, "SR Section 8");
					}
					break;
				case "SR_FEDERAL_LIHEAP":
					if (getParams.getTestPerValue("SR").equalsIgnoreCase("yes")
							&& getParams.getTestPerValue("DocUploadButton")
									.equalsIgnoreCase("fileuploadnow")) {
						uploadProgramDocuments(SR_FEDERAL_LIHEAP,
								SR_FEDERAL_LIHEAP_FILE_UPLOAD, "SR LIHEAP");
					}
					break;
				case "SR_FEDERAL_TANF":
					if (getParams.getTestPerValue("SR").equalsIgnoreCase("yes")
							&& getParams.getTestPerValue("DocUploadButton")
									.equalsIgnoreCase("fileuploadnow")) {
						uploadProgramDocuments(SR_FEDERAL_TANF,
								SR_FEDERAL_TANF_FILE_UPLOAD, "SR TANF");
					}
					break;
				case "SR_FEFERAL_NSLP":
					if (getParams.getTestPerValue("SR").equalsIgnoreCase("yes")
							&& getParams.getTestPerValue("DocUploadButton")
									.equalsIgnoreCase("fileuploadnow")) {
						uploadProgramDocuments(SR_FEFERAL_NSLP,
								SR_FEFERAL_NSLP_FILE_UPLOAD, "SR Federal NSLP");
					}
					break;
				case "SR_FEDERAL_INDIAN_AFFAIRS":
					if (getParams.getTestPerValue("SR").equalsIgnoreCase("yes")
							&& getParams.getTestPerValue("DocUploadButton")
									.equalsIgnoreCase("fileuploadnow")) {
						uploadProgramDocuments(SR_FEDERAL_INDIAN_AFFAIRS,
								SR_FEDERAL_INDIAN_AFFAIRS_FILE_UPLOAD,
								"SR Indian Affairs");
					}
					break;
				case "SR_FEDERAL_TTANF":
					if (getParams.getTestPerValue("SR").equalsIgnoreCase("yes")
							&& getParams.getTestPerValue("DocUploadButton")
									.equalsIgnoreCase("fileuploadnow")) {
						uploadProgramDocuments(SR_FEDERAL_TTANF,
								SR_FEDERAL_TTANF_FILE_UPLOAD, "SR TTANF");
					}
					break;
				case "SR_FEDERAL_FDPIR":
					if (getParams.getTestPerValue("SR").equalsIgnoreCase("yes")
							&& getParams.getTestPerValue("DocUploadButton")
									.equalsIgnoreCase("fileuploadnow")) {
						uploadProgramDocuments(SR_FEDERAL_FDPIR,
								SR_FEDERAL_FDPIR_FILE_UPLOAD,
								"SR Federal FDPIR");
					}
					break;
				case "SR_FEDERAL_HEAD_START":
					if (getParams.getTestPerValue("SR").equalsIgnoreCase("yes")
							&& getParams.getTestPerValue("DocUploadButton")
									.equalsIgnoreCase("fileuploadnow")) {
						uploadProgramDocuments(SR_FEDERAL_HEAD_START,
								SR_FEDERAL_HEAD_START_FILE_UPLOAD,
								"SR Federal HeadStart");
					}
					break;
				case "SR_FEDERAL_MEDICARE_PROGRAM":
					if (getParams.getTestPerValue("SR").equalsIgnoreCase("yes")
							&& getParams.getTestPerValue("DocUploadButton")
									.equalsIgnoreCase("fileuploadnow")) {
						uploadProgramDocuments(SR_FEDERAL_MEDICARE_PROGRAM,
								SR_FEDERAL_MEDICARE_PROGRAM_FILE_UPLOAD,
								"SR Medicare Program");
					}
					break;
				// COMMUNITY COLLEGE
				case "CC_SCHOOL_YEAR_TRANSCRIPT":
					if (getParams.getTestPerValue("CC").equalsIgnoreCase("yes")
							&& getParams.getTestPerValue("DocUploadButton")
									.equalsIgnoreCase("fileuploadnow")) {
						uploadProgramDocuments(CC_SCHOOL_YEAR_TRANSCRIPT,
								CC_SCHOOL_YEAR_TRANSCRIPT_FILE_UPLOAD,
								"CC Transcript");
						expectedDocsText += "Current or prior school year transcript:";
						
						
					}
					break;
				case "CC_SCHOOL_YEAR_CLASS_SCHEDULE":
					if (getParams.getTestPerValue("CC").equalsIgnoreCase("yes")
							&& getParams.getTestPerValue("DocUploadButton")
									.equalsIgnoreCase("fileuploadnow")) {
						uploadProgramDocuments(CC_SCHOOL_YEAR_CLASS_SCHEDULE,
								CC_SCHOOL_YEAR_CLASS_SCHEDULE_FILE_UPLOAD,
								"CC Class Schedule");
						expectedDocsText += "School-Class schedule:";
					}
					break;
				case "CC_PELL_GRANT_AWARD_LETTER":
					if (getParams.getTestPerValue("CC").equalsIgnoreCase("yes")
							&& getParams.getTestPerValue("DocUploadButton")
									.equalsIgnoreCase("fileuploadnow")) {
						uploadProgramDocuments(CC_PELL_GRANT_AWARD_LETTER,
								CC_PELL_GRANT_AWARD_LETTER_FILE_UPLOAD,
								"CC Pell Grant Award");
						expectedDocsText += "Pell Grant Award Letter from the community college:";
					}
					break;
				case "CC_SAR":
					if (getParams.getTestPerValue("CC").equalsIgnoreCase("yes")
							&& getParams.getTestPerValue("DocUploadButton")
									.equalsIgnoreCase("fileuploadnow")) {
						uploadProgramDocuments(CC_SAR, CC_SAR_FILE_UPLOAD,
								"CC SAR");
						expectedDocsText += "2-page Student Aid Report (SAR) with Pell Grant eligibility:";

					}
					break;

				// PHILADELPHIA
				case "PA_MEDICAID":
					if (getParams.getTestPerValue("PHBBA").equalsIgnoreCase(
							"yes")
							&& getParams.getTestPerValue("DocUploadButton")
									.equalsIgnoreCase("fileuploadnow")) {
						uploadProgramDocuments(PA_MEDICAID,
								PA_MEDICAID_FILE_UPLOAD, "PA Medicaid");
					}
					break;
				case "PA_SSI":
					if (getParams.getTestPerValue("PHBBA").equalsIgnoreCase(
							"yes")
							&& getParams.getTestPerValue("DocUploadButton")
									.equalsIgnoreCase("fileuploadnow")) {
						uploadProgramDocuments(PA_SSI, PA_SSI_FILE_UPLOAD,
								"PA SSI");
					}
					break;
				case "PA_LIHEAP":
					if (getParams.getTestPerValue("PHBBA").equalsIgnoreCase(
							"yes")
							&& getParams.getTestPerValue("DocUploadButton")
									.equalsIgnoreCase("fileuploadnow")) {
						uploadProgramDocuments(PA_LIHEAP,
								PA_LIHEAP_FILE_UPLOAD, "PA LIHEAP");
					}
					break;
				case "PA_FREE_LUNCH_PROGRAM":
					if (getParams.getTestPerValue("PHBBA").equalsIgnoreCase(
							"yes")
							&& getParams.getTestPerValue("DocUploadButton")
									.equalsIgnoreCase("fileuploadnow")) {
						uploadProgramDocuments(PA_FREE_LUNCH_PROGRAM,
								PA_FREE_LUNCH_PROGRAM_FILE_UPLOAD,
								"PA Free Lunch Program");
					}
					break;
				case "PA_EAEDC":
					if (getParams.getTestPerValue("PHBBA").equalsIgnoreCase(
							"yes")
							&& getParams.getTestPerValue("DocUploadButton")
									.equalsIgnoreCase("fileuploadnow")) {
						uploadProgramDocuments(PA_EAEDC, PA_EAEDC_FILE_UPLOAD,
								"PA EAEDC");
					}
					break;
				case "PA_SNAP":
					if (getParams.getTestPerValue("PHBBA").equalsIgnoreCase(
							"yes")
							&& getParams.getTestPerValue("DocUploadButton")
									.equalsIgnoreCase("fileuploadnow")) {
						uploadProgramDocuments(PA_SNAP, PA_SNAP_FILE_UPLOAD,
								"PA SNAP");
					}
					break;
				case "PA_FEDERAL_PUBLIC_HOUSE_ASSISTANCE":
					if (getParams.getTestPerValue("PHBBA").equalsIgnoreCase(
							"yes")
							&& getParams.getTestPerValue("DocUploadButton")
									.equalsIgnoreCase("fileuploadnow")) {
						uploadProgramDocuments(
								PA_FEDERAL_PUBLIC_HOUSE_ASSISTANCE,
								PA_FEDERAL_PUBLIC_HOUSE_ASSISTANCE_FILE_UPLOAD,
								"PA Public House Assistance");
					}
					break;
				case "PA_TANF":
					if (getParams.getTestPerValue("PHBBA").equalsIgnoreCase(
							"yes")
							&& getParams.getTestPerValue("DocUploadButton")
									.equalsIgnoreCase("fileuploadnow")) {
						uploadProgramDocuments(PA_TANF, PA_TANF_FILE_UPLOAD,
								"PA TANF");
					}
					break;
				case "PA_INDIAN_AFFAIRS":
					if (getParams.getTestPerValue("PHBBA").equalsIgnoreCase(
							"yes")
							&& getParams.getTestPerValue("DocUploadButton")
									.equalsIgnoreCase("fileuploadnow")) {
						uploadProgramDocuments(PA_INDIAN_AFFAIRS,
								PA_INDIAN_AFFAIRS_FILE_UPLOAD,
								"PA Indian Affairs");
					}
					break;
				case "PA_TTANF":
					if (getParams.getTestPerValue("PHBBA").equalsIgnoreCase(
							"yes")
							&& getParams.getTestPerValue("DocUploadButton")
									.equalsIgnoreCase("fileuploadnow")) {
						uploadProgramDocuments(PA_TTANF, PA_TTANF_FILE_UPLOAD,
								"PA TTANF");
					}
					break;
				case "PA_FDPIR":
					if (getParams.getTestPerValue("PHBBA").equalsIgnoreCase(
							"yes")
							&& getParams.getTestPerValue("DocUploadButton")
									.equalsIgnoreCase("fileuploadnow")) {
						uploadProgramDocuments(PA_FDPIR, PA_FDPIR_FILE_UPLOAD,
								"PA FDPIR");
					}
					break;
				case "PA_HEAD_START":
					if (getParams.getTestPerValue("PHBBA").equalsIgnoreCase(
							"yes")
							&& getParams.getTestPerValue("DocUploadButton")
									.equalsIgnoreCase("fileuploadnow")) {
						uploadProgramDocuments(PA_HEAD_START,
								PA_HEAD_START_FILE_UPLOAD, "PA Head Start");
					}
					break;

				default:
					System.out.println("Please provide the valid document");
				}

			}
		} catch (Exception ex) {
			System.out.println(ex.getMessage());
		}
		
		//Click the Confirm button
		if(waitForElement(_docConfirm, 5)){
			//scrollToElement(_docConfirm);
			//scrollToElementAndClick(_docConfirm);
			scrollToElement(_docConfirm);
			click(_docConfirm);
			//clickCheckboxOrRadioButton(_docConfirm);
		}
		
		if(getParams.getTestPerValue("AppState").trim().equalsIgnoreCase("save")&& getParams.getTestPerValue("PageToExit").trim().equalsIgnoreCase("documentsuploadpage"))
		{
			if(waitForElement(_docSave, 5))
				scrollToElementAndClick(_docSave);	
			
			
			if(waitForElement(_popupOk, 5)){
				click(_popupOk);
				
				if(waitForElement(_applicationNumber, 10)){
					//Assigning Application Number to the static variable 
					Utilities.applicationNumber = _applicationNumber.getText();
				}
			}
			util.setApplicationStatus("Saved",getParams.getTestPerValue("SSN"),getParams.getTestPerValue("AutoApproved"));	
		}
		else
		{
			//Click the Next in the Documents Upload page
			if(waitForElement(_docNext, 5))
				scrollToElement(_docNext);
				click(_docNext);
				//scrollToElementAndClick(_docNext);
			
			
			waitforPageLoadComplete();		
			util.setApplicationStatus("Initiated",getParams.getTestPerValue("SSN"),getParams.getTestPerValue("AutoApproved"));
		}
		
		if(util.get("APPLICATION_STATUS").equalsIgnoreCase("saved"))
			util.verifyDBValue("Application", "Status", util.get("APPLICATION_STATUS"));
		
		else
			util.verifyDBValue("Application", "Status", util.get("APPLICATION_STATUS"));
		
		
		
	}

	private void expandProgramType(WebElement element) {
		if (waitForElement(element, 2)) {
			if (element.getAttribute("class").contains("collapsed")) {
				click(element);
			}
		}
	}
	
	private void uploadProgramDocuments(WebElement docRadioButton,
			WebElement docAddFile, String docName) {
		String text = null;
		waitforPageLoadComplete();
		// Click the document radio button
		//if(waitForElement(docRadioButton,10)){
			clickCheckboxOrRadioButton(docRadioButton);	
		//}
		// Scroll into view
		scrollToElement(docAddFile);
		if (waitForElement(docAddFile, 5)) {
			// Highlight WebElement
			highlightWebElement(docAddFile, "blue");
			//sleep(2000);
			// /Click on Add File link
			
			try{
				actionClickOnAxis(docAddFile);
				sleep(3000);
				// Uploading a file
				
				fileUpload(util.getRandomFileName());
				sleep(3000);
				
				text = getWebelementToString(docAddFile);
				scrollToElement(docRadioButton);
				int i=0;
				boolean flag = true;
				WebElement element = null;
				while(i < 20 && flag){
					try{
						i++;
						System.out.println("Incremented " +i );
						element = driver.findElement(By.xpath(text
								+ "/preceding::img[1][@class = 'loadingspinner']"));
						sleep(1000);
						flag = true;
						
					}catch(Exception ex){
						flag = false;
						break;
					}
				}
				verifyDocumentsUpload(text, docName, element);
				
				
			}catch(Exception e){
				System.out.println(e.getMessage());
				report.reportSoftFailEvent(docName + " Upload Status ", "Document not uploaded successfully");
			}
		}

	}

/*	private void uploadProgramDocuments(WebElement docRadioButton,
			WebElement docAddFile, String docName) {
		String text = null;
		waitforPageLoadComplete();
		// Click the document radio button
		//if(waitForElement(docRadioButton,10)){
			clickCheckboxOrRadioButton(docRadioButton);	
		//}
		// Scroll into view
		scrollToElement(docAddFile);
		if (waitForElement(docAddFile, 5)) {
			// Highlight WebElement
			highlightWebElement(docAddFile, "blue");
			//sleep(2000);
			// /Click on Add File link
			
			try{
				actionClickOnAxis(docAddFile);
				sleep(3000);
				// Uploading a file
				
				fileUpload(util.getRandomFileName());
				sleep(3000);
				text = getWebelementToString(docAddFile);
				scrollToElement(docRadioButton);
				verifyDocumentsUpload(text, docName);
				
			}catch(Exception e){
				//util.reportsoEvent(docName + " Upload Status ", "Document uploaded successfully");
				report.reportSoftFailEvent(docName + " Upload Status ", "Document not uploaded successfully");
			}
		}

	}*/
}
