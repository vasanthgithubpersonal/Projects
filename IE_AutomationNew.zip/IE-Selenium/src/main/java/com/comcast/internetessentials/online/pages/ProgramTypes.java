package com.comcast.internetessentials.online.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import com.comcast.internetessentials.libraries.Common;
import com.comcast.internetessentials.libraries.GetParameters;
import com.comcast.internetessentials.libraries.Reports;
import com.comcast.internetessentials.libraries.Utilities;
import com.comcast.internetessentials.reporting.SeleniumReport;

public class ProgramTypes extends Common {

	@FindBy(xpath = "//input[@id='checkboxNSLP']/following-sibling::div[@class = 'class_checkbox']")
	@CacheLookup
	private WebElement _NSLP;
	
	@FindBy(xpath = "//*[@id='SchoolName']")
	@CacheLookup
	private WebElement _NSLPSchool;

	@FindBy(xpath = "//*[@id='checkboxNSLPhome']")
	@CacheLookup
	private WebElement _NSLPHomeSchool;

	@FindBy(xpath = "//input[@id='checkboxCollege']/following-sibling::div[@class = 'class_checkbox']")
	@CacheLookup
	private WebElement _CC;

	@FindBy(xpath = "//*[@id='CollegeName']")
	@CacheLookup
	private WebElement _CCCollege;

	@FindBy(xpath = "//input[@id='checkboxSenior']/following-sibling::div[@class = 'class_checkbox']")
	@CacheLookup
	private WebElement _SR;

	@FindBy(xpath = "//*[@id='SeniorGrp']")
	@CacheLookup
	private WebElement _SROrganization;

	@FindBy(xpath = "//input[@id='checkboxPublicHousing']/following-sibling::div[@class = 'class_checkbox']")
	@CacheLookup
	private WebElement _HUD;

	@FindBy(xpath = "//input[@id='checkboxPhiladelphiaBroadband']/following-sibling::div[@class = 'class_checkbox']")
	@CacheLookup
	private WebElement _PHBBA;

	@FindBy(xpath = "//input[@id='checkboxNone']/following-sibling::div[@class = 'class_checkbox']")
	@CacheLookup
	private WebElement _programTypeNone;

	@FindBy(xpath = "//*[@id='backBtn']")
	@CacheLookup
	private WebElement _programTypeBack;

	@FindBy(xpath = "//*[@id='save']")
	@CacheLookup
	private WebElement _programTypeSave;
	
	@FindBy(xpath = "//*[@id='SaveOkBtn']")
	@CacheLookup
	private WebElement _popupOk;

	@FindBy(xpath = "//*[@id='submit']")
	@CacheLookup
	private WebElement _programTypeNext;
	
	@FindBy(xpath = "//span[@id = 'applicationSavedID']")
	@CacheLookup
	private WebElement _applicationNumber;
	
	@FindBy(xpath = "//div[@id = 'sorry_page']//following::div[@class = 'topFont']")
	@CacheLookup
	private WebElement _oopsMessage;
	

	public ProgramTypes(WebDriver browser, GetParameters getParameters) {
		super(browser,getParameters);
		PageFactory.initElements(browser, this);
	}

	public void programSelectionPage() {

		waitforPageLoadComplete();
		report.addTestLogSection("Program Selection Page");
		if (!getParams.getTestPerValue("NSLP").isEmpty() && getParams.getTestPerValue("NSLP").trim().equalsIgnoreCase("yes")){
			{
				
				if(waitForElement(_NSLP, 10)){
					clickCheckboxOrRadioButton(_NSLP);
					util.reportDoneEvent("NSLP Program", "Selected");
				}
									
			if(!getParams.getTestPerValue("NSLP_HomeSchool").isEmpty() && getParams.getTestPerValue("NSLP_HomeSchool").trim().equalsIgnoreCase("yes")) {
				if(waitForElement(_NSLPHomeSchool, 10)){
					clickCheckboxOrRadioButton(_NSLPHomeSchool);	
					util.reportDoneEvent("NSLP Home Schooled", "Selected");
				}
				}
			}
			/*if (!getParams.getTestPerValue("NSLP_SchoolName").isEmpty()) {
				if(_NSLPSchool.isEnabled()){
					javaScriptSendKeys(_NSLPSchool,getParams.getTestPerValue("NSLP_SchoolName").toUpperCase().trim());
					util.reportDoneEvent("NSLP School Name", getParams.getTestPerValue("NSLP_SchoolName").toUpperCase());
				}
				
			}*/
			
			if (!getParams.getTestPerValue("NSLP_SchoolName").equalsIgnoreCase("na") || !getParams.getTestPerValue("NSLP_SchoolName").equalsIgnoreCase("no")) {
				if(_NSLPSchool.isEnabled()){
					javaScriptSendKeys(_NSLPSchool,getParams.getTestPerValue("NSLP_SchoolName").toUpperCase().trim());
					util.reportDoneEvent("NSLP School Name", getParams.getTestPerValue("NSLP_SchoolName").toUpperCase());
				}
				
			}
		}
		
		if(!getParams.getTestPerValue("CC").isEmpty() && getParams.getTestPerValue("CC").trim().equalsIgnoreCase("yes")){
			if(waitForElement(_CC, 10)){
				clickCheckboxOrRadioButton(_CC);	
				util.reportDoneEvent("Community College Program", "Selected");
			}
			
			/*if(!getParams.getTestPerValue("CC_CollegeName").isEmpty()){
				javaScriptSendKeys(_CCCollege,getParams.getTestPerValue("CC_CollegeName").toUpperCase().trim());
				util.reportDoneEvent("Community College Name", getParams.getTestPerValue("CC_CollegeName").toUpperCase());
			}*/
			
			if(!getParams.getTestPerValue("CC_CollegeName").equalsIgnoreCase("na") || !getParams.getTestPerValue("CC_CollegeName").equalsIgnoreCase("no")){
				javaScriptSendKeys(_CCCollege,getParams.getTestPerValue("CC_CollegeName").toUpperCase().trim());
				util.reportDoneEvent("Community College Name", getParams.getTestPerValue("CC_CollegeName").toUpperCase());
			}
		}
		
		if(!getParams.getTestPerValue("SR").isEmpty() && getParams.getTestPerValue("SR").trim().equalsIgnoreCase("yes")){
			if(waitForElement(_SR, 10)){
				clickCheckboxOrRadioButton(_SR);
				util.reportDoneEvent("Senior Program", "Selected");
			}
			
			/*if(!getParams.getTestPerValue("SR_OrganizationName").isEmpty()){
				javaScriptSendKeys(_SROrganization,getParams.getTestPerValue("SR_OrganizationName").toUpperCase().trim());
				util.reportDoneEvent("Senior Program Name", getParams.getTestPerValue("SR_OrganizationName").toUpperCase());
			}*/
			
			if(!getParams.getTestPerValue("SR_OrganizationName").equalsIgnoreCase("na") || !getParams.getTestPerValue("SR_OrganizationName").equalsIgnoreCase("no")){
				javaScriptSendKeys(_SROrganization,getParams.getTestPerValue("SR_OrganizationName").toUpperCase().trim());
				util.reportDoneEvent("Senior Program Name", getParams.getTestPerValue("SR_OrganizationName").toUpperCase());
			}
		}
		
		if(!getParams.getTestPerValue("HUD").isEmpty() && getParams.getTestPerValue("HUD").trim().equalsIgnoreCase("yes")){
			if(waitForElement(_HUD, 10)){
				clickCheckboxOrRadioButton(_HUD);	
				util.reportDoneEvent("Housing Assistance Program", "Selected");
			}
		}
		
		if(!getParams.getTestPerValue("PHBBA").isEmpty() && getParams.getTestPerValue("PHBBA").trim().equalsIgnoreCase("yes")){
			if(waitForElement(_PHBBA, 10)){
				clickCheckboxOrRadioButton(_PHBBA);	
				util.reportDoneEvent("Philadelphia Program", "Selected");
			}
		}
		
		//save and next
		if(getParams.getTestPerValue("AppState").trim().equalsIgnoreCase("save")&& getParams.getTestPerValue("PageToExit").trim().equalsIgnoreCase("programselectionpage"))
		{
			if(waitForElement(_programTypeSave, 5))
				scrollToElementAndClick(_programTypeSave);	
			
			
			if(waitForElement(_popupOk, 5)){
				click(_popupOk);
				
				if(waitForElement(_applicationNumber, 10)){
					//Assigning Application Number to the static variable 
					Utilities.applicationNumber = _applicationNumber.getText();
				}
			}
			util.setApplicationStatus("Saved",getParams.getTestPerValue("SSN"),getParams.getTestPerValue("AutoApproved"));	
		}
		else
		{
			if(waitForElement(_programTypeNext, 5))
				//scrollToElementAndClick(_programTypeNext);
				
				scrollToElement(_programTypeNext);
				click(_programTypeNext);
			//_programTypeNext.sendKeys(Keys.ENTER);
			
			waitforPageLoadComplete();		
			util.setApplicationStatus("Initiated",getParams.getTestPerValue("SSN"),getParams.getTestPerValue("AutoApproved"));
			
	/*		if(_oopsMessage.getText().trim().equalsIgnoreCase("oops...")){
				//driver.close();
				report.reportHardFailEvent("Application Terminated", "OOPS Error thrown in the applciation");	
				
			}*/
			
		}
		
		//Verifying the Application Status
		if(util.get("APPLICATION_STATUS").equalsIgnoreCase("saved")){
			util.verifyDBValue("Application", "Status", util.get("APPLICATION_STATUS"));
		}
		else
			util.verifyDBValue("Application", "Status", util.get("APPLICATION_STATUS"));
	
		
	}
	
	
	
	
	
	
}
