package com.comcast.internetessentials.online.pages;

import java.util.Random;

import org.apache.commons.codec.language.bm.Rule.RPattern;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.comcast.internetessentials.libraries.Common;
import com.comcast.internetessentials.libraries.GetParameters;
import com.comcast.internetessentials.libraries.Reports;
import com.comcast.internetessentials.libraries.Utilities;
import com.comcast.internetessentials.reporting.SeleniumReport;

public class BasicDetails extends Common {

	@FindBy(xpath = "//*[@id='FirstName']")
	@CacheLookup
	private WebElement _firstName;

	@FindBy(xpath = "//*[@id='LastName']")
	@CacheLookup
	private WebElement _lastName;

	@FindBy(xpath = "//*[@id='Email']")
	@CacheLookup
	private WebElement _emailField;

	@FindBy(xpath = "//*[@id='CEmail']")
	@CacheLookup
	private WebElement _confirmEmailField;

	@FindBy(xpath = "//*[@id='emailCheckBox']")
	@CacheLookup
	private WebElement _emailcheckBox;

	@FindBy(xpath = "//*[@id='PhoneField1']")
	@CacheLookup
	private WebElement _phoneField;

	@FindBy(xpath = "//*[@id='txtStreetAdd']")
	@CacheLookup
	private WebElement _streetAddress;

	@FindBy(xpath = "//*[@id='UnitNum']")
	@CacheLookup
	private WebElement _apartment;

	@FindBy(xpath = "//*[@id='ZipCode']")
	@CacheLookup
	private WebElement _zipCode;

	@FindBy(id = "edit-submit")
	@CacheLookup
	public WebElement _basicPageNext;

	@FindBy(xpath = "//*[@name = 'PersonalDetailsNext']")
	@CacheLookup
	public WebElement _personalDetailsNext;

	public BasicDetails(WebDriver browser, GetParameters getParameters) {
		super(browser, getParameters);
		PageFactory.initElements(browser, this);
		
				
	}

	

	public void basicDetialsPage(String email) {
		String address = null;
		try {
			db.connectDataBase("InternetEssential");
			report.addTestLogSection("Basic Details Page");

			sendText(_firstName, util.get("FIRSTNAME"));
			util.reportDoneEvent("FirstName", util.get("FIRSTNAME"));

			sendText(_lastName, util.get("LASTNAME"));
			util.reportDoneEvent("LastName", util.get("LASTNAME"));

			if (email.equalsIgnoreCase("yes")) {
				sendText(_emailField, util.get("EMAIL"));
				sendText(_confirmEmailField, util.get("EMAIL"));
				util.reportDoneEvent("Email", util.get("EMAIL"));
			} else {
				click(_emailcheckBox);
				util.reportDoneEvent("Email Checkbox", "Clicked Successfully");
			}

			// Verify in db for TelephoneNumber
			while (db.IsDbValueExists("Application", "TelephoneNumber", util.get("PHONENUMBER"))) {
				Random random = new Random();
				int number = random.nextInt(900000000) + 1000000000;
				util.set("PHONENUMBER", Integer.toString(number));
			}
			
			sendText(_phoneField, util.get("PHONENUMBER"));
			util.reportDoneEvent("PhoneNumber", util.get("PHONENUMBER"));
			
			
			// Assigning it to the static variable
			Utilities.telephoneNumber = util.get("PHONENUMBER");
			
			
			//Apartment verify in TestData
			if(!getParams.getTestPerValue("Apartment").toLowerCase().startsWith("APT".toLowerCase())){
				address = getParams.getTestPerValue("Address") + ", APT "+getParams.getTestPerValue("Apartment") + ", " + getParams.getTestPerValue("ZipCode");
				util.set("ADDRESS", address);
			}else{
				address = getParams.getTestPerValue("Address") + ", "+getParams.getTestPerValue("Apartment") + ", " + getParams.getTestPerValue("ZipCode");
				util.set("ADDRESS", address);
			}

			sendText(_streetAddress, getParams.getTestPerValue("Address"));
			sendText(_apartment, getParams.getTestPerValue("Apartment"));
			sendText(_zipCode, getParams.getTestPerValue("ZipCode"));
			util.reportDoneEvent("Apartment, Address, ZipCode", util.get("ADDRESS"));

			scrollToElementAndClick(_basicPageNext);
			waitforPageLoadComplete();
			util.setApplicationStatus("Initiated", getParams.getTestPerValue("SSN"),getParams.getTestPerValue("AutoApproved"));
			//Verify page data
			util.verifyBasicDetailsPage();
			
			//Verifying the Application Status
			
			if(util.get("APPLICATION_STATUS").equalsIgnoreCase("initiated")){
				util.verifyDBValue("Application", "Status", util.get("APPLICATION_STATUS"));
			}
			

		} catch (Exception ex) {
			System.out.println(ex.getMessage());
		}

	}
}
