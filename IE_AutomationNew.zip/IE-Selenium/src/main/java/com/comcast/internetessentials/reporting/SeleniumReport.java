/*
 *
 */
package com.comcast.internetessentials.reporting;

import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.asserts.SoftAssert;

/**
 * @author 589478
 * @version 1.0
 */
public class SeleniumReport extends Report {

	private String message;

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	/**
	 * Function to set the {@link WebDriver} object
	 * 
	 * @param driver
	 *            The {@link WebDriver} object
	 */
	public void setDriver(WebDriver driver) {
		this.browser = driver;
	}

	/**
	 * Constructor to initialize the Report
	 * 
	 * @param reportSettings
	 *            The {@link ReportSettings} object
	 * @param reportTheme
	 *            The {@link ReportTheme} object
	 */
	public SeleniumReport(ReportSettings reportSettings, ReportTheme reportTheme) {
		super(reportSettings, reportTheme);
	}

	/**
	 * Method to take screen shot via selenium
	 */
/*
	@Override
	protected void takeScreenshot(String screenshotPath) {

		if (browser == null) {
			throw new FrameworkException("Report.driver is not initialized!");
		}

		File scrFile = ((TakesScreenshot) browser)
				.getScreenshotAs(OutputType.FILE);

		try {
			FileUtils.copyFile(scrFile, new File(screenshotPath), true);
		} catch (Exception e) {
			e.printStackTrace();
			throw new FrameworkException(
					"Error while writing screenshot to file");
		}
	}*/

	/**
	 * Add a Done step to the test report
	 * 
	 * @param stepName
	 * @param description
	 */

	public void reportDoneEvent(String stepName, String description) {
		this.updateTestLog(stepName, description, Status.DONE);
	}

	/**
	 * Add a Passed step to the test report
	 * 
	 * @param stepName
	 * @param description
	 */

	public void reportPassEvent(String stepName, String description) {
		this.updateTestLog(stepName, description, Status.PASS);
	}

	/**
	 * Reports a pass event with screenshot forced (overrides the default
	 * behavior from framework.properties)
	 * 
	 * @param stepName
	 * @param description
	 */
	public void reportPassScreenshotEvent(String stepName, String description) {
		boolean blntmp = false;

		if (!getReportSettings().takeScreenshotPassedStep) {
			getReportSettings().takeScreenshotPassedStep = true;
			blntmp = true;
		}

		this.updateTestLog(stepName, description, Status.PASS);
		setMessage(stepName + ":" + description);

		if (blntmp) {
			getReportSettings().takeScreenshotPassedStep = false;
		}
	}

	/**
	 * Add a failed report to the test report. And it will terminate the
	 * testcase execution
	 * 
	 * @param stepName
	 * @param description
	 */
	public void reportHardFailEvent(String stepName, String description) {
		this.updateTestLog(stepName, description, Status.FAIL);
		Assert.fail("Error in Step: " + stepName + "\n Descripton: "
				+ description);
	}

	/**
	 * Add a failed report to the test report. And it will continue the testcase
	 * execution
	 * 
	 * @param stepName
	 * @param description
	 */

	public void reportSoftFailEvent(String stepName, String description) {

		this.updateTestLog(stepName, description, Status.FAIL);

		SoftAssert softAssert = new SoftAssert();
		softAssert.fail("Error in Step: " + stepName + "\n Descripton: "
				+ description);

	}
}