package com.comcast.internetessentials.online.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.comcast.internetessentials.libraries.Common;
import com.comcast.internetessentials.libraries.GetParameters;
import com.comcast.internetessentials.libraries.Reports;
import com.comcast.internetessentials.reporting.SeleniumReport;

/**
 * @author 589478
 *
 */
public class Documents extends Common {
	
	//PROGRAM TYPES ACCORDIAN
	@FindBy(xpath = "//div[contains(text(),'Families with School-Aged Children:')]/ancestor::a[contains(@class, 'accordion-toggle')]")
	@CacheLookup
	protected WebElement NSLP_ACCORDIAN;
	
	@FindBy(xpath = "//div[contains(text(),'Housing Assistance Program:')]/ancestor::a[contains(@class, 'accordion-toggle')]")
	@CacheLookup
	protected WebElement HUD_ACCORDIAN;
	
	@FindBy(xpath = "//div[contains(text(),'Senior Program:')]/ancestor::a[contains(@class, 'accordion-toggle')]")
	@CacheLookup
	protected WebElement SR_ACCORDIAN;
	
	@FindBy(xpath = "//div[contains(text(),'Community College Program:')]/ancestor::a[contains(@class, 'accordion-toggle')]")
	@CacheLookup
	protected WebElement CC_ACCORDIAN;

	
	
	//FAMILIES WITH SCHOOL AGED CHILDREN
	@FindBy(xpath = "//*[contains(text(),'families participating in the National School Lunch Program')]/following::input[@type='radio'][1]")
	@CacheLookup
	protected WebElement NSLP_CURRENT_PARTICIPATION;

	
	//XPath changed
	@FindBy(xpath = "//*[contains(text(),'families participating in the National School Lunch Program')]/following::div[@id='UploadFile'][1]/a")
	@CacheLookup
	protected WebElement NSLP_CURRENT_PARTICIPATION_FILE_UPLOAD;

	@FindBy(xpath = "//*[contains(text(),'families who do not participate in the NSLP, but attend public, charter')]/following::input[@type='radio'][1]")
	@CacheLookup
	protected WebElement NSLP_SNAP;

	@FindBy(xpath = "//*[contains(text(),'families who do not participate in the NSLP, but attend public, charter')]/following::div[@id='UploadFile'][1]/a")
	@CacheLookup
	protected WebElement NSLP_SNAP_FILE_UPLOAD;

	@FindBy(xpath = "//*[contains(text(),'families who do not participate in the NSLP, but attend public, charter')]/following::input[@type='radio'][2]")
	@CacheLookup
	protected WebElement NSLP_TANF;

	@FindBy(xpath = "//*[contains(text(),'families who do not participate in the NSLP, but attend public, charter')]/following::div[@id='UploadFile'][2]/a")
	@CacheLookup
	protected WebElement NSLP_TANF_FILE_UPLOAD;

	@FindBy(xpath = "//*[contains(text(),' families who do not participate in the NSLP, but attend public, charter')]/following::input[@type='radio'][3]")
	@CacheLookup
	protected WebElement NSLP_FDPIR;

	//Xpath changed
	@FindBy(xpath = "//*[contains(text(),'families who do not participate in the NSLP, but attend public, charter')]/following::div[@id='UploadFile'][3]/a")
	@CacheLookup
	protected WebElement NSLP_FDPIR_FILE_UPLOAD;

	@FindBy(xpath = "//*[contains(text(),' families who do not participate in the NSLP, but attend public, charter')]/following::input[@type='radio'][4]")
	@CacheLookup
	protected WebElement NSLP_REPORTCARD;

	@FindBy(xpath = "//*[contains(text(),'families who do not participate in the NSLP, but attend public, charter')]/following::div[@id='UploadFile'][4]/a")
	@CacheLookup
	protected WebElement NSLP_REPORTCARD_FILE_UPLOAD;

	@FindBy(xpath = "//*[contains(text(),' families who do not participate in the NSLP, but attend public, charter')]/following::input[@type='radio'][5]")
	@CacheLookup
	protected WebElement NSLP_STUDENTID;

	@FindBy(xpath = "//*[contains(text(),'families who do not participate in the NSLP, but attend public, charter')]/following::div[@id='UploadFile'][5]/a")
	@CacheLookup
	protected WebElement NSLP_STUDENTID_FILE_UPLOAD;

	@FindBy(xpath = "//*[contains(text(),' families who do not participate in the NSLP, but attend public, charter')]/following::input[@type='radio'][6]")
	@CacheLookup
	protected WebElement NSLP_SCHOOL_LETTER;

	//xpath changed
	@FindBy(xpath = "//*[contains(text(),'families who do not participate in the NSLP, but attend public, charter')]/following::div[@id='UploadFile'][6]/a")
	@CacheLookup
	protected WebElement NSLP_SCHOOL_LETTER_FILE_UPLOAD;

	@FindBy(xpath = "//*[contains(text(),'families who do not participate in the NSLP, and are homeschooled')]/following::input[@type='radio'][1]")
	@CacheLookup
	protected WebElement NSLP_HOMESCHOOL_SNAP;

	//XPATH Changed
	@FindBy(xpath = "//*[contains(text(),'families who do not participate in the NSLP, and are homeschooled')]/following::div[@id='UploadFile'][1]/a")
	@CacheLookup
	protected WebElement NSLP_HOMESCHOOL_SNAP_FILE_UPLOAD;

	@FindBy(xpath = "//*[contains(text(),'families who do not participate in the NSLP, and are homeschooled')]/following::input[@type='radio'][2]")
	@CacheLookup
	protected WebElement NSLP_HOMESCHOOL_TANF;

	@FindBy(xpath = "//*[contains(text(),'families who do not participate in the NSLP, and are homeschooled')]/following::div[@id='UploadFile'][2]/a")
	@CacheLookup
	protected WebElement NSLP_HOMESCHOOL_TANF_FILE_UPLOAD;

	@FindBy(xpath = "//*[contains(text(),'families who do not participate in the NSLP, and are homeschooled')]/following::input[@type='radio'][3]")
	@CacheLookup
	protected WebElement NSLP_HOMESCHOOL_FDPIR;

	@FindBy(xpath = "//*[contains(text(),'families who do not participate in the NSLP, and are homeschooled')]/following::div[@id='UploadFile'][3]/a")
	@CacheLookup
	protected WebElement NSLP_HOMESCHOOL_FDPIR_FILE_UPLOAD;

	@FindBy(xpath = "//*[contains(text(),'families who do not participate in the NSLP, and are homeschooled')]/following::input[@type='radio'][4]")
	@CacheLookup
	protected WebElement NSLP_HOMESCHOOL_WAIVER;

	//Xpath Changed
	@FindBy(xpath = "//*[contains(text(),'families who do not participate in the NSLP, and are homeschooled')]/following::div[@id='UploadFile'][4]/a")
	@CacheLookup
	protected WebElement NSLP_HOMESCHOOL_WAIVER_FILE_UPLOAD;

	@FindBy(xpath = "//*[contains(text(),'families who do not participate in the NSLP, and are homeschooled')]/following::input[@type='radio'][5]")
	@CacheLookup
	protected WebElement NSLP_HOMESCHOOL_PROOF_OF_PARTICIPATION;
	
	@FindBy(xpath = "//*[contains(text(),'families who do not participate in the NSLP, and are homeschooled')]/following::div[@id='UploadFile'][5]/a")
	@CacheLookup
	protected WebElement NSLP_HOMESCHOOL_PROOF_OF_PARTICIPATION_FILE_UPLOAD;
	
	//HOUSE ASSISTANCE PROGRAM
	@FindBy(xpath = "//*[contains(text(),'Department of Housing and Urban Development (HUD)')]/following::input[@type='radio'][1]")
	@CacheLookup
	protected WebElement HUD_PUBLIC_LEASE;
	
	@FindBy(xpath = "//*[contains(text(),'Department of Housing and Urban Development (HUD)')]/following::div[@id='UploadFile'][1]/a")
	@CacheLookup
	protected WebElement HUD_PUBLIC_LEASE_FILE_UPLOAD;
	
	@FindBy(xpath = "//*[contains(text(),'Department of Housing and Urban Development (HUD)')]/following::input[@type='radio'][2]")
	@CacheLookup
	protected WebElement HUD_PUBLIC_TIC_FORM;
	
	@FindBy(xpath = "//*[contains(text(),'Department of Housing and Urban Development (HUD)')]/following::div[@id='UploadFile'][2]/a")
	@CacheLookup
	protected WebElement HUD_PUBLIC_TIC_FORM_FILE_UPLOAD;
	
	@FindBy(xpath = "//*[contains(text(),'Department of Housing and Urban Development (HUD)')]/following::input[@type='radio'][3]")
	@CacheLookup
	protected WebElement HUD_PUBLIC_RENT_STATEMENT;
	
	@FindBy(xpath = "//*[contains(text(),'Department of Housing and Urban Development (HUD)')]/following::div[@id='UploadFile'][3]/a")
	@CacheLookup
	protected WebElement HUD_PUBLIC_RENT_STATEMENT_FILE_UPLOAD;
	
	@FindBy(xpath = "//*[contains(text(),'Department of Housing and Urban Development (HUD)')]/following::input[@type='radio'][4]")
	@CacheLookup
	protected WebElement HUD_PUBLIC_RENT_LETTER;
	
	@FindBy(xpath = "//*[contains(text(),'Department of Housing and Urban Development (HUD)')]/following::div[@id='UploadFile'][4]/a")
	@CacheLookup
	protected WebElement HUD_PUBLIC_RENT_LETTER_FILE_UPLOAD;
	
	@FindBy(xpath = "//*[contains(text(),'Department of Housing and Urban Development (HUD)')]/following::input[@type='radio'][5]")
	@CacheLookup
	protected WebElement HUD_HOUSING_CHOICE_LEASE;
	
	@FindBy(xpath = "//*[contains(text(),'Department of Housing and Urban Development (HUD)')]/following::div[@id='UploadFile'][5]/a")
	@CacheLookup
	protected WebElement HUD_HOUSING_CHOICE_LEASE_FILE_UPLOAD;
	
	@FindBy(xpath = "//*[contains(text(),'Department of Housing and Urban Development (HUD)')]/following::input[@type='radio'][6]")
	@CacheLookup
	protected WebElement HUD_HOUSING_CHOICE_TIC_FORM;
	
	@FindBy(xpath = "//*[contains(text(),'Department of Housing and Urban Development (HUD)')]/following::div[@id='UploadFile'][6]/a")
	@CacheLookup
	protected WebElement HUD_HOUSING_CHOICE_TIC_FORM_FILE_UPLOAD;
	
	@FindBy(xpath = "//*[contains(text(),'Department of Housing and Urban Development (HUD)')]/following::input[@type='radio'][7]")
	@CacheLookup
	protected WebElement HUD_HOUSING_CHOICE_VOUCHER_FORM;
	
	@FindBy(xpath = "//*[contains(text(),'Department of Housing and Urban Development (HUD)')]/following::div[@id='UploadFile'][7]/a")
	@CacheLookup
	protected WebElement HUD_HOUSING_CHOICE_VOUCHER_FORM_FILE_UPLOAD;
	
	@FindBy(xpath = "//*[contains(text(),'Department of Housing and Urban Development (HUD)')]/following::input[@type='radio'][8]")
	@CacheLookup
	protected WebElement HUD_HOUSING_CHOICE_FAMILY_REPORT;
	
	@FindBy(xpath = "//*[contains(text(),'Department of Housing and Urban Development (HUD)')]/following::div[@id='UploadFile'][8]/a")
	@CacheLookup
	protected WebElement HUD_HOUSING_CHOICE_FAMILY_REPORT_FILE_UPLOAD;
	
	@FindBy(xpath = "//*[contains(text(),'Department of Housing and Urban Development (HUD)')]/following::input[@type='radio'][9]")
	@CacheLookup
	protected WebElement HUD_HOUSING_CHOICE_LEASE_UP_DOC;
	
	@FindBy(xpath = "//*[contains(text(),'Department of Housing and Urban Development (HUD)')]/following::div[@id='UploadFile'][9]/a")
	@CacheLookup
	protected WebElement HUD_HOUSING_CHOICE_LEASE_UP_DOC_FILE_UPLOAD;
	
	@FindBy(xpath = "//*[contains(text(),'Department of Housing and Urban Development (HUD)')]/following::input[@type='radio'][10]")
	@CacheLookup
	protected WebElement HUD_MULTIFAMILY_LEASE;
	
	@FindBy(xpath = "//*[contains(text(),'Department of Housing and Urban Development (HUD)')]/following::div[@id='UploadFile'][10]/a")
	@CacheLookup
	protected WebElement HUD_MULTIFAMILY_LEASE_FILE_UPLOAD;
	
	@FindBy(xpath = "//*[contains(text(),'Department of Housing and Urban Development (HUD)')]/following::input[@type='radio'][11]")
	@CacheLookup
	protected WebElement HUD_MULTIFAMILY_TIC_FORM;

	@FindBy(xpath = "//*[contains(text(),'Department of Housing and Urban Development (HUD)')]/following::div[@id='UploadFile'][11]/a")
	@CacheLookup
	protected WebElement HUD_MULTIFAMILY_TIC_FORM_FILE_UPLOAD;
	
	@FindBy(xpath = "//*[contains(text(),'Department of Housing and Urban Development (HUD)')]/following::input[@type='radio'][12]")
	@CacheLookup
	protected WebElement HUD_MULTIFAMILY_HAP;
	
	@FindBy(xpath = "//*[contains(text(),'Department of Housing and Urban Development (HUD)')]/following::div[@id='UploadFile'][12]/a")
	@CacheLookup
	protected WebElement HUD_MULTIFAMILY_HAP_FILE_UPLOAD;
	
	@FindBy(xpath = "//*[contains(text(),'Department of Housing and Urban Development (HUD)')]/following::input[@type='radio'][13]")
	@CacheLookup
	protected WebElement HUD_MULTIFAMILY_TENENT_ELIGIBILITY;
	
	@FindBy(xpath = "//*[contains(text(),'Department of Housing and Urban Development (HUD)')]/following::div[@id='UploadFile'][13]/a")
	@CacheLookup
	protected WebElement HUD_MULTIFAMILY_TENENT_ELIGIBILITY_FILE_UPLOAD;
	
	//SENIOR PROGRAM
	@FindBy(xpath = "//*[contains(text(),'62 years of age or older')]/following::input[@type='radio'][1]")
	@CacheLookup
	protected WebElement SR_LICENSE;
	
	@FindBy(xpath = "//*[contains(text(),'62 years of age or older')]/following::div[@id='UploadFile'][1]/a")
	@CacheLookup
	protected WebElement SR_LICENSE_FILE_UPLOAD;
	
	@FindBy(xpath = "//*[contains(text(),'62 years of age or older')]/following::input[@type='radio'][2]")
	@CacheLookup
	protected WebElement SR_STATE_ID;
	
	@FindBy(xpath = "//*[contains(text(),'62 years of age or older')]/following::div[@id='UploadFile'][2]/a")
	@CacheLookup
	protected WebElement SR_STATE_ID_FILE_UPLOAD;
	
	@FindBy(xpath = "//*[contains(text(),'62 years of age or older')]/following::input[@type='radio'][3]")
	@CacheLookup
	protected WebElement SR_PASSPORT;
	
	@FindBy(xpath = "//*[contains(text(),'62 years of age or older')]/following::div[@id='UploadFile'][3]/a")
	@CacheLookup
	protected WebElement SR_PASSPORT_FILE_UPLOAD;
	
	@FindBy(xpath = "//*[contains(text(),'62 years of age or older')]/following::input[@type='radio'][4]")
	@CacheLookup
	protected WebElement SR_BIRTH_CERTIFICATE;
	
	@FindBy(xpath = "//*[contains(text(),'62 years of age or older')]/following::div[@id='UploadFile'][4]/a")
	@CacheLookup
	protected WebElement SR_BIRTH_CERTIFICATE_FILE_UPLOAD;
	
	@FindBy(xpath = "//*[contains(text(),'62 years of age or older')]/following::input[@type='radio'][5]")
	@CacheLookup
	protected WebElement SR_VOTER_CARD;
	
	@FindBy(xpath = "//*[contains(text(),'62 years of age or older')]/following::div[@id='UploadFile'][5]/a")
	@CacheLookup
	protected WebElement SR_VOTER_CARD_FILE_UPLOAD;
	
	@FindBy(xpath = "//*[contains(text(),'62 years of age or older')]/following::input[@type='radio'][6]")
	@CacheLookup
	protected WebElement SR_FEDERAL_MEDICAID;
	
	@FindBy(xpath = "//*[contains(text(),'62 years of age or older')]/following::div[@id='UploadFile'][6]/a")
	@CacheLookup
	protected WebElement SR_FEDERAL_MEDICAID_FILE_UPLOAD;
	
	@FindBy(xpath = "//*[contains(text(),'62 years of age or older')]/following::input[@type='radio'][7]")
	@CacheLookup
	protected WebElement SR_FEDERAL_SNAP;
	
	@FindBy(xpath = "//*[contains(text(),'62 years of age or older')]/following::div[@id='UploadFile'][7]/a")
	@CacheLookup
	protected WebElement SR_FEDERAL_SNAP_FILE_UPLOAD;
	
	@FindBy(xpath = "//*[contains(text(),'62 years of age or older')]/following::input[@type='radio'][8]")
	@CacheLookup
	protected WebElement SR_FEDERAL_SSI;
	
	@FindBy(xpath = "//*[contains(text(),'62 years of age or older')]/following::div[@id='UploadFile'][8]/a")
	@CacheLookup
	protected WebElement SR_FEDERAL_SSI_FILE_UPLOAD;
	
	@FindBy(xpath = "//*[contains(text(),'62 years of age or older')]/following::input[@type='radio'][9]")
	@CacheLookup
	protected WebElement SR_FEDERAL_SECTION8;
	
	@FindBy(xpath = "//*[contains(text(),'62 years of age or older')]/following::div[@id='UploadFile'][9]/a")
	@CacheLookup
	protected WebElement SR_FEDERAL_SECTION8_FILE_UPLOAD;
	
	@FindBy(xpath = "//*[contains(text(),'62 years of age or older')]/following::input[@type='radio'][10]")
	@CacheLookup
	protected WebElement SR_FEDERAL_LIHEAP;
	
	@FindBy(xpath = "//*[contains(text(),'62 years of age or older')]/following::div[@id='UploadFile'][10]/a")
	@CacheLookup
	protected WebElement SR_FEDERAL_LIHEAP_FILE_UPLOAD;
	
	@FindBy(xpath = "//*[contains(text(),'62 years of age or older')]/following::input[@type='radio'][11]")
	@CacheLookup
	protected WebElement SR_FEDERAL_TANF;
	
	@FindBy(xpath = "//*[contains(text(),'62 years of age or older')]/following::div[@id='UploadFile'][11]/a")
	@CacheLookup
	protected WebElement SR_FEDERAL_TANF_FILE_UPLOAD;
	
	@FindBy(xpath = "//*[contains(text(),'62 years of age or older')]/following::input[@type='radio'][12]")
	@CacheLookup
	protected WebElement SR_FEFERAL_NSLP;
	
	@FindBy(xpath = "//*[contains(text(),'62 years of age or older')]/following::div[@id='UploadFile'][12]/a")
	@CacheLookup
	protected WebElement SR_FEFERAL_NSLP_FILE_UPLOAD;
	
	@FindBy(xpath = "//*[contains(text(),'62 years of age or older')]/following::input[@type='radio'][13]")
	@CacheLookup
	protected WebElement SR_FEDERAL_INDIAN_AFFAIRS;
	
	@FindBy(xpath = "//*[contains(text(),'62 years of age or older')]/following::div[@id='UploadFile'][13]/a")
	@CacheLookup
	protected WebElement SR_FEDERAL_INDIAN_AFFAIRS_FILE_UPLOAD;
	
	@FindBy(xpath = "//*[contains(text(),'62 years of age or older')]/following::input[@type='radio'][14]")
	@CacheLookup
	protected WebElement SR_FEDERAL_TTANF;
	
	@FindBy(xpath = "//*[contains(text(),'62 years of age or older')]/following::div[@id='UploadFile'][14]/a")
	@CacheLookup
	protected WebElement SR_FEDERAL_TTANF_FILE_UPLOAD;
	
	@FindBy(xpath = "//*[contains(text(),'62 years of age or older')]/following::input[@type='radio'][15]")
	@CacheLookup
	protected WebElement SR_FEDERAL_FDPIR;
	
	@FindBy(xpath = "//*[contains(text(),'62 years of age or older')]/following::div[@id='UploadFile'][15]/a")
	@CacheLookup
	protected WebElement SR_FEDERAL_FDPIR_FILE_UPLOAD;
	
	@FindBy(xpath = "//*[contains(text(),'62 years of age or older')]/following::input[@type='radio'][16]")
	@CacheLookup
	protected WebElement SR_FEDERAL_HEAD_START;
	
	@FindBy(xpath = "//*[contains(text(),'62 years of age or older')]/following::div[@id='UploadFile'][16]/a")
	@CacheLookup
	protected WebElement SR_FEDERAL_HEAD_START_FILE_UPLOAD;
	
	@FindBy(xpath = "//*[contains(text(),'62 years of age or older')]/following::input[@type='radio'][17]")
	@CacheLookup
	protected WebElement SR_FEDERAL_MEDICARE_PROGRAM;
	
	@FindBy(xpath = "//*[contains(text(),'62 years of age or older')]/following::div[@id='UploadFile'][17]/a")
	@CacheLookup
	protected WebElement SR_FEDERAL_MEDICARE_PROGRAM_FILE_UPLOAD;
	
	//COMMUNITY COLLEGE PROGRAM
	
	@FindBy(xpath = "//*[contains(text(),'Community College in Illinois or Colorado')]/following::input[@type='radio'][1]")
	@CacheLookup
	protected WebElement CC_SCHOOL_YEAR_TRANSCRIPT;
	
	@FindBy(xpath = "//*[contains(text(),'Community College in Illinois or Colorado')]/following::div[@id='UploadFile'][1]/a")
	@CacheLookup
	protected WebElement CC_SCHOOL_YEAR_TRANSCRIPT_FILE_UPLOAD;
	
	@FindBy(xpath = "//*[contains(text(),'Community College in Illinois or Colorado')]/following::input[@type='radio'][2]")
	@CacheLookup
	protected WebElement CC_SCHOOL_YEAR_CLASS_SCHEDULE;
	
	@FindBy(xpath = "//*[contains(text(),'Community College in Illinois or Colorado')]/following::div[@id='UploadFile'][2]/a")
	@CacheLookup
	protected WebElement CC_SCHOOL_YEAR_CLASS_SCHEDULE_FILE_UPLOAD;
	
	@FindBy(xpath = "//*[contains(text(),'Community College in Illinois or Colorado')]/following::input[@type='radio'][3]")
	@CacheLookup
	protected WebElement CC_PELL_GRANT_AWARD_LETTER;
	
	@FindBy(xpath = "//*[contains(text(),'Community College in Illinois or Colorado')]/following::div[@id='UploadFile'][3]/a")
	@CacheLookup
	protected WebElement CC_PELL_GRANT_AWARD_LETTER_FILE_UPLOAD;
	
	@FindBy(xpath = "//*[contains(text(),'Community College in Illinois or Colorado')]/following::input[@type='radio'][4]")
	@CacheLookup
	protected WebElement CC_SAR;
	
	@FindBy(xpath = "//*[contains(text(),'Community College in Illinois or Colorado')]/following::div[@id='UploadFile'][4]/a")
	@CacheLookup
	protected WebElement CC_SAR_FILE_UPLOAD;
	
	//PHILADELPHIA BROADBAND ACCESS PROGRAM
	@FindBy(xpath = "//*[contains(text(),'Applicants for the Philadelphia Broadband Access Program')]/following::input[@type='radio'][1]")
	@CacheLookup
	protected WebElement PA_MEDICAID;
	
	@FindBy(xpath = "//*[contains(text(),'Applicants for the Philadelphia Broadband Access Program')]/following::div[@id='UploadFile'][1]/a")
	@CacheLookup
	protected WebElement PA_MEDICAID_FILE_UPLOAD;
	
	@FindBy(xpath = "//*[contains(text(),'Applicants for the Philadelphia Broadband Access Program')]/following::input[@type='radio'][2]")
	@CacheLookup
	protected WebElement PA_SSI;
	
	@FindBy(xpath = "//*[contains(text(),'Applicants for the Philadelphia Broadband Access Program')]/following::div[@id='UploadFile'][2]/a")
	@CacheLookup
	protected WebElement PA_SSI_FILE_UPLOAD;
	
	@FindBy(xpath = "//*[contains(text(),'Applicants for the Philadelphia Broadband Access Program')]/following::input[@type='radio'][3]")
	@CacheLookup
	protected WebElement PA_LIHEAP;
	
	@FindBy(xpath = "//*[contains(text(),'Applicants for the Philadelphia Broadband Access Program')]/following::div[@id='UploadFile'][3]/a")
	@CacheLookup
	protected WebElement PA_LIHEAP_FILE_UPLOAD;
	
	@FindBy(xpath = "//*[contains(text(),'Applicants for the Philadelphia Broadband Access Program')]/following::input[@type='radio'][4]")
	@CacheLookup
	protected WebElement PA_FREE_LUNCH_PROGRAM;
	
	@FindBy(xpath = "//*[contains(text(),'Applicants for the Philadelphia Broadband Access Program')]/following::div[@id='UploadFile'][4]/a")
	@CacheLookup
	protected WebElement PA_FREE_LUNCH_PROGRAM_FILE_UPLOAD;
	
	@FindBy(xpath = "//*[contains(text(),'Applicants for the Philadelphia Broadband Access Program')]/following::input[@type='radio'][5]")
	@CacheLookup
	protected WebElement PA_EAEDC;
	
	@FindBy(xpath = "//*[contains(text(),'Applicants for the Philadelphia Broadband Access Program')]/following::div[@id='UploadFile'][5]/a")
	@CacheLookup
	protected WebElement PA_EAEDC_FILE_UPLOAD;
	
	@FindBy(xpath = "//*[contains(text(),'Applicants for the Philadelphia Broadband Access Program')]/following::input[@type='radio'][6]")
	@CacheLookup
	protected WebElement PA_SNAP;
	
	@FindBy(xpath = "//*[contains(text(),'Applicants for the Philadelphia Broadband Access Program')]/following::div[@id='UploadFile'][6]/a")
	@CacheLookup
	protected WebElement PA_SNAP_FILE_UPLOAD;
	
	@FindBy(xpath = "//*[contains(text(),'Applicants for the Philadelphia Broadband Access Program')]/following::input[@type='radio'][7]")
	@CacheLookup
	protected WebElement PA_FEDERAL_PUBLIC_HOUSE_ASSISTANCE;
	
	@FindBy(xpath = "//*[contains(text(),'Applicants for the Philadelphia Broadband Access Program')]/following::div[@id='UploadFile'][7]/a")
	@CacheLookup
	protected WebElement PA_FEDERAL_PUBLIC_HOUSE_ASSISTANCE_FILE_UPLOAD;
	
	@FindBy(xpath = "//*[contains(text(),'Applicants for the Philadelphia Broadband Access Program')]/following::input[@type='radio'][8]")
	@CacheLookup
	protected WebElement PA_TANF;
	
	@FindBy(xpath = "//*[contains(text(),'Applicants for the Philadelphia Broadband Access Program')]/following::div[@id='UploadFile'][8]/a")
	@CacheLookup
	protected WebElement PA_TANF_FILE_UPLOAD;
	
	@FindBy(xpath = "//*[contains(text(),'Applicants for the Philadelphia Broadband Access Program')]/following::input[@type='radio'][9]")
	@CacheLookup
	protected WebElement PA_INDIAN_AFFAIRS;
	
	@FindBy(xpath = "//*[contains(text(),'Applicants for the Philadelphia Broadband Access Program')]/following::div[@id='UploadFile'][9]/a")
	@CacheLookup
	protected WebElement PA_INDIAN_AFFAIRS_FILE_UPLOAD;
	
	@FindBy(xpath = "//*[contains(text(),'Applicants for the Philadelphia Broadband Access Program')]/following::input[@type='radio'][10]")
	@CacheLookup
	protected WebElement PA_TTANF;
	
	@FindBy(xpath = "//*[contains(text(),'Applicants for the Philadelphia Broadband Access Program')]/following::div[@id='UploadFile'][10]/a")
	@CacheLookup
	protected WebElement PA_TTANF_FILE_UPLOAD;
	
	@FindBy(xpath = "//*[contains(text(),'Applicants for the Philadelphia Broadband Access Program')]/following::input[@type='radio'][11]")
	@CacheLookup
	protected WebElement PA_FDPIR;
	
	@FindBy(xpath = "//*[contains(text(),'Applicants for the Philadelphia Broadband Access Program')]/following::div[@id='UploadFile'][11]/a")
	@CacheLookup
	protected WebElement PA_FDPIR_FILE_UPLOAD;
	
	@FindBy(xpath = "//*[contains(text(),'Applicants for the Philadelphia Broadband Access Program')]/following::input[@type='radio'][12]")
	@CacheLookup
	protected WebElement PA_HEAD_START;
	
	@FindBy(xpath = "//*[contains(text(),'Applicants for the Philadelphia Broadband Access Program')]/following::div[@id='UploadFile'][12]/a")
	@CacheLookup
	protected WebElement PA_HEAD_START_FILE_UPLOAD;
	

	
	public Documents(WebDriver browser, GetParameters params) {
		super(browser, params);
		PageFactory.initElements(browser, this);
	}

	/*public void documentUploadPage() {
		String documents = getParams.getTestPerValue("DocumentsToUpload");
		String[] docs = documents.split(",");
	}

	public void programTypeUpload(String[] pgmTypeList) {
		for (int i = 0; i < pgmTypeList.length; i++) {
			WebElement pgmTypetoClick = null;
			switch (pgmTypeList[i]) {
			case "NSLP_CURRENT_PARTICIPATION":
				if(getParams.getTestPerValue("NSLP").equalsIgnoreCase("yes")){
					clickCheckboxOrRadioButton(NSLP_CURRENT_PARTICIPATION);
					click(NSLP_CURRENT_PARTICIPATION_FILE_UPLOAD);	
					break;
				}
			case "NSLP_SNAP":
				if(getParams.getTestPerValue("NSLP").equalsIgnoreCase("yes")){
					clickCheckboxOrRadioButton(NSLP_SNAP);
					click(NSLP_SNAP_FILE_UPLOAD);
					break;
				}
			case "NSLP_TANF":

				break;
			case "NSLP_FDPIR":

				break;
			case "NSLP_REPORTCARD":

				break;
			case "NSLP_STUDENTID":

				break;
			case "NSLP_SCHOOL_LETTER":

				break;
			case "NSLP_HOMESCHOOL_SNAP":

				break;
			case "NSLP_HOMESCHOOL_TANF":

				break;
			case "NSLP_HOMESCHOOL_FDPIR":

				break;
			case "NSLP_HOMESCHOOL_WAIVER":

				break;
			case "NSLP_HOMESCHOOL_PROOF_OF_PARTICIPATION":

				break;

			default:
				System.out.println("Case not found");
			}
		}
	}
*/
}
