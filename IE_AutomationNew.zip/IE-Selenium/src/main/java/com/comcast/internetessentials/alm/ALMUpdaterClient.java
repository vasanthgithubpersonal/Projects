package com.comcast.internetessentials.alm;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;

import com.comcast.almadapter.client.ALMAdapterClient;
import com.comcast.almadapter.client.entity.Test;
import com.comcast.almadapter.client.entity.TestRun;
import com.comcast.almadapter.client.entity.TestStep;
import com.comcast.internetessentials.reporting.*;
import com.google.gson.Gson;

public class ALMUpdaterClient {

	Logger log = Logger.getLogger(ALMUpdaterClient.class);
	private static ALMAdapterClient client;
	private static final String URL = "http://tqmapp-wc-1p.sys.comcast.net:8080/almadapter/";
	private static final String ALM_USER_NAME = Constants.USERNAME;
	private static final String ALM_PASSWORD = Constants.PASSWORD;

	private static final String DOMAIN = Constants.DOMAIN; // "CET_SIT";
	private static final String PROJECT = Constants.PROJECT;// "CET_SIT_TEST";

	int tryCount = 0;
	int MAXTRY = 20;

	/**
	 * @param testSetID
	 * @param testName
	 * @param testID
	 * @param status
	 * @param duration
	 * @throws Exception
	 */
	public synchronized void createTestRUN(String testSetID, String testName, String testID, String status,
			String duration) throws Exception {

		client = new ALMAdapterClient(URL, ALM_USER_NAME, ALM_PASSWORD);
		ArrayList<TestStep> testSteps = new ArrayList<TestStep>();
		Date dNow = new Date();
		SimpleDateFormat ft = new SimpleDateFormat("yyyy-MM-dd");
		SimpleDateFormat ft2 = new SimpleDateFormat("hh:mm");
		String dateString = ft.format(dNow);
		String timeString = ft2.format(dNow);

		String reportPath = ReportPath.getInstance().getReportPath();

		testSteps.add(new TestStep("Step1", status, dateString, timeString));
		testSteps.add(new TestStep("Step2", status, dateString, timeString));
		ArrayList<Test> tests = new ArrayList<com.comcast.almadapter.client.entity.Test>();

		Test test = new com.comcast.almadapter.client.entity.Test(testID, status, dateString, timeString, testSteps);
		test.setDuration(duration);
		tests.add(test);

		// params are testset name, test folder path, owner NT id, test list

		new ALMTestInformation();

		// TestRun testRun = new TestRun(ALM.GetTestSetName(testSetID),
		// testSetPath, ALM_USER_NAME, tests);
		// Alternative Implementations with TestID instead of testSetPath and
		// testSetName

		TestRun testRun = new TestRun();
		testRun.setLoginId(ALM_USER_NAME);
		testRun.setTestList(tests);
		testRun.setTestSetId(testSetID);

		createTestRUN(testRun, reportPath, testName);

	}

	/**
	 * @param testRun
	 * @param reportPath
	 * @param testName
	 */
	public void createTestRUN(TestRun testRun, String reportPath, String testName) {
		boolean done = false;
		try {

			tryCount = tryCount + 1;
			String runInfo = client.createTestRun(DOMAIN, PROJECT, testRun);
			System.out.println("Returns Run Info");
			System.out.println(runInfo);
			Map<String, Object> javaRootMapObject = new Gson().fromJson(runInfo, Map.class);
			String runID = (String) ((Map) ((List) ((Map) (javaRootMapObject.get("CreateResultResponse")))
					.get("RunInfo")).get(0)).get("RunId");
			System.out.println("runID:" + runID);
			client.createTestRunAttachment(DOMAIN, PROJECT, runID, reportPath + "\\" + testName + ".zip");
			done = true;
		} catch (Exception Ex) {
			while (tryCount < MAXTRY && !(done)) {
				if (tryCount == MAXTRY) {
					log.error("It failed to post the run results in ALM after " + MAXTRY + " attempts");
					break;
				} else { // Added by Kesavan on Mar 10 2017 as it failed to
					// create a test run in the first attempts.
					// Therefore, we are catching the exception and
					// retrying with maximum 5 attempts.
					log.warn("Calling the createTestRUN() method one more time!!!. " + tryCount + " attempts tried");
					createTestRUN(testRun, reportPath, testName);
				}
			}
		}
	}

}
