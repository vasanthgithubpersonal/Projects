package com.comcast.internetessentials.online.pages;

import org.openqa.selenium.WebDriver;

import com.comcast.internetessentials.libraries.GetParameters;
import com.comcast.internetessentials.libraries.Utilities;
import com.comcast.internetessentials.reporting.SeleniumReport;

public class PageFactory {

	protected WebDriver driver;
	protected GetParameters getParams;
	protected SeleniumReport report;
	
	public PageFactory(WebDriver browser, GetParameters getParameters) {
		this.driver = browser;
		this.getParams = getParameters;

	}

	public BasicDetails basicDetails(){
		BasicDetails obasicDetails = new BasicDetails(driver,getParams);
		return obasicDetails;
	}
	
	public PersonalDetails personalDetails(){
		PersonalDetails opersonalDetails = new PersonalDetails(driver,getParams);
		return opersonalDetails;
	}
	
	public ProgramTypes programTypes(){
		ProgramTypes oprogramTypes = new ProgramTypes(driver,getParams);
		return oprogramTypes;
	}
	
	public EssentialSteps essentialSteps(){
		EssentialSteps oessentialSteps = new EssentialSteps(driver,getParams);
		return oessentialSteps;
	}
	
	public DocumentsUpload documentsUpload(){
		DocumentsUpload odocUpload = new DocumentsUpload(driver, getParams);
		return odocUpload;
	}
	
	public TimeSlot timeSlot(){
		TimeSlot otimeSlot = new TimeSlot(driver, getParams);
		return otimeSlot;
	}
	
	
	public ReviewAndConfirm reviewAndConfirm(){
		ReviewAndConfirm oreviewandConfirm = new ReviewAndConfirm(driver,getParams);
		return oreviewandConfirm;
	}
	
	public RetrieveApplication retrieveApplication(){
		RetrieveApplication retrieveApplication = new RetrieveApplication(driver, getParams);
		return retrieveApplication;
	}
}
