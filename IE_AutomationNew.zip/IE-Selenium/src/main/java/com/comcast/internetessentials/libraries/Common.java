package com.comcast.internetessentials.libraries;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;
import java.util.concurrent.TimeUnit;

import javax.management.RuntimeErrorException;

import org.apache.commons.exec.ExecuteException;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.comcast.internetessentials.reporting.SeleniumReport;

/**
 * The Common program is implemented which will have all the common selenium
 * reusable methods
 * 
 * @author 589478
 * @since 2017-03-09
 * @version 1.2
 */

public class Common extends Reports {

	public static Utilities util;
	protected WebDriver driver;
	protected GetParameters getParams;
	public Database db = null;
	public final int LONG_WAIT = 99;

	
	public Common(){
		
	}
	/**
	 * Paramaterized Constructor
	 */
	public Common(WebDriver browser, GetParameters params) {

		this.driver = browser;
		this.getParams = params;
		db = new Database(getParams);
		/*if (Common.util == null) {
			Common.util = new Utilities(getParams);
		}*/
		
		if(Utilities.data == null || Utilities.data.isEmpty()){
			Common.util = new Utilities(getParams);
		}

	}

	/**
	 * This method will wait for the page load to get complete
	 */

	public void waitforPageLoadComplete() {
		WebDriverWait wait = new WebDriverWait(driver, LONG_WAIT);

		try {
			wait.until(new ExpectedCondition<Boolean>() {
				@Override
				public Boolean apply(WebDriver wdriver) {
					boolean flag = false;
					int tries = 0;
					while (!flag && tries < 20) {
						try {
							flag = ((JavascriptExecutor) driver).executeScript(
									"return document.readyState").equals(
									"complete");
							//break;
						} catch (Exception ex) {
							waitforPageLoadComplete();
						}
						tries += 1;
					}
					return flag;
				}
			});
		} catch (Exception ex) {
			// throw new RuntimeException(ex.getMessage());
			System.out.println(ex.getMessage());
		}

	}

	/**
	 * This method will click on the web element
	 * 
	 * @param element
	 *            (required) WebElement to be passed
	 */
	protected void click(WebElement element) {
		try {
			if (waitForElement(element)) {
				element.click();
			}
		} catch (Exception ex) {
			String errMessage = "Clicking on the Web element - " + element
					+ " got failed : " + ex.getMessage();
			throw new RuntimeException(errMessage);
		}

	}

	/**
	 * This method will scroll to the web element and perform click action using
	 * JavaScript
	 * 
	 * @param element
	 *            (required) WebElement to be passed
	 */
	protected void scrollToElementAndClick(WebElement element) {

		try {
			if (getParams.getEnvPerValue("BROWSER_TYPE").equalsIgnoreCase(
					"chrome")) {

				((JavascriptExecutor) driver).executeScript(
						"arguments[0].scrollIntoView(true);", element);
				sleep(500);
				((JavascriptExecutor) driver).executeScript(
						"arguments[0].click();", element);
			} else if (getParams.getEnvPerValue("BROWSER_TYPE")
					.equalsIgnoreCase("ie")) {
				((JavascriptExecutor) driver).executeScript(
						"arguments[0].click();", element);
			} else {
				element.click();
			}
		} catch (RuntimeException ex) {
			String errorMessage = "Clicking on the Webelement - " + element
					+ " got failed :" + ex.getMessage();
			throw new RuntimeException(errorMessage);
		}

	}

	/**
	 * This method will scroll to the web element using JavaScript
	 * 
	 * @param element
	 *            (required) WebElement to be passed
	 */

	protected void scrollToElement(WebElement element) {

		try {
			if (getParams.getEnvPerValue("BROWSER_TYPE").equalsIgnoreCase(
					"chrome")
					|| getParams.getEnvPerValue("BROWSER_TYPE")
							.equalsIgnoreCase("ie")
					|| getParams.getEnvPerValue("BROWSER_TYPE")
							.equalsIgnoreCase("firefox")) {

				((JavascriptExecutor) driver).executeScript(
						"arguments[0].scrollIntoView(true);", element);

			}
		} catch (RuntimeException ex) {
			String errorMessage = "Scrolling to the Webelement - " + element
					+ " got failed :" + ex.getMessage();
			throw new RuntimeException(errorMessage);
		}

	}

	/**
	 * This method will click on the web element based on the X and Y offset
	 * 
	 * @param element
	 *            (required) WebElement to be passed
	 */

	protected void actionClickOnAxis(WebElement element) {
		try {
			int width = element.getSize().getWidth();
			Actions act = new Actions(driver);
			act.moveToElement(element).moveByOffset((width / 2) - 2, 0).click()
					.perform();
		} catch (Exception ex) {
			String errMessage = "Clicking on the Webelement - " + element
					+ " (Add File link) got failed : " + ex.getMessage();
			throw new RuntimeException(errMessage);
		}

	}

	/**
	 * This method will wait for few milliseconds
	 * 
	 * @param milliseconds
	 *            (required) milliseconds to be passed
	 */

	protected void sleep(int milliseconds) {
		try {
			Thread.sleep(milliseconds);
		} catch (InterruptedException ex) {
			throw new RuntimeException(ex.getMessage());
		}
	}

	/**
	 * This method will wait for the web element. It can wait up to a maximum of
	 * 99 seconds
	 * 
	 * @param element
	 *            (required) WebElement to be passed
	 * @return true If the element is clickable
	 */

	protected boolean waitForElement(WebElement element) {
		try {
			new WebDriverWait(driver, LONG_WAIT).until(ExpectedConditions
					.elementToBeClickable(element));
			return true;
		} catch (Exception ex) {
			String errorMessage = "Unable to find the web element - " + element
					+ " to click : " + ex.getMessage();
			throw new RuntimeException(errorMessage);
		}
	}

	/**
	 * This method will wait for the web element. It can wait up to the maximum
	 * seconds that is passed
	 * 
	 * @param element
	 *            (required) WebElement to be passed
	 * @return true If the element is clickable
	 * @return false If the element is not clickable
	 */

	protected boolean waitForElement(WebElement element, int seconds) {
		try {
			new WebDriverWait(driver, seconds).until(ExpectedConditions
					.elementToBeClickable(element));
			return true;
		} catch (Exception ex) {
			return false;
		}
	}

	/**
	 * This method will wait for the web element to be visible. It can wait up
	 * to the maximum seconds that is passed
	 * 
	 * @param element
	 *            (required) WebElement to be passed
	 * @return true If the element is clickable
	 * @return false If the element is not clickable
	 */

	protected boolean waitForElementToBeVisible(WebElement element, int seconds) {
		try {
			new WebDriverWait(driver, seconds).until(ExpectedConditions
					.visibilityOf(element));
			return true;
		} catch (Exception ex) {
			return false;
		}
	}

	/**
	 * This method will send the text to the text box using java script
	 * 
	 * @param element
	 *            (required) WebElement to be passed
	 * @param text
	 *            (required) text to be passed
	 */

	protected void javaScriptSendKeys(WebElement element, String text) {
		String id;
		try {
			JavascriptExecutor executor = (JavascriptExecutor) driver;
			id = element.getAttribute("id");
			executor.executeScript("document.getElementById('" + id
					+ "').value='" + text + "'");
		} catch (Exception ex) {
			String errMessage = "Unable to send the text to the web element - "
					+ element + " via JavaScript : " + ex.getMessage();
			throw new RuntimeException(errMessage);
		}

	}

	/**
	 * This method will highlight the web element
	 * 
	 * @param element
	 *            (required) WebElement to be passed
	 * @param color
	 *            (required) color to be passed
	 */

	protected void highlightWebElement(WebElement element, String color) {
		String hStr = "3px dotted " + color;
		String jsStr = "arguments[0].style.border='" + hStr + "'";
		waitForElement(element);
		if (element == null) {
			return;
		}

		try {
			JavascriptExecutor js = (JavascriptExecutor) driver;
			js.executeScript(jsStr, element);
		} catch (Exception e) {
			String errMessage = "Unable to successfully run the script ["
					+ jsStr + "]  on web element=" + element;
			throw new RuntimeException(errMessage);
		}
	}

	/**
	 * This method sends the text to the web element
	 * 
	 * @param element
	 *            (required) WebElement to be passed
	 * @param text
	 *            (required) text to be passed
	 */

	protected void sendText(WebElement element, String text) {
		if (waitForElement(element)) {
			element.sendKeys(text);
		}
	}

	/**
	 * This method clicks on Check box / Radio button based on the web element
	 * passed
	 * 
	 * @param element
	 *            (required) WebElement to be passed
	 */

	protected void clickCheckboxOrRadioButton(WebElement element) {

		try {
			waitForElement(element);
			click(element);		
		} catch (RuntimeException ex) {
			String errMessage = "Unable to find the element : [" + element
					+ "]  to perform action";
			throw new RuntimeException(errMessage);
		}
	}

	/**
	 * This method will upload a file using AutoIt
	 * 
	 * @param fileName
	 *            (required) FileName to be passed
	 * @throws IOException
	 */
	protected void fileUpload(String fileName) throws IOException {
		String relativePath = new File(System.getProperty("user.dir"))
				.getAbsolutePath();

		String filePath = System.getProperty("user.dir")
				+ "\\src\\test\\resources\\AutoIt\\Attachments\\" + fileName;

		if (relativePath.endsWith("bin"))
			relativePath = new File(System.getProperty("user.dir")).getParent();

		relativePath = relativePath
				+ "\\src\\test\\resources\\AutoIT\\FileUpload.exe";
		String[] command = new String[] {
				"cmd.exe",
				"/C",
				"Start",
				System.getProperty("user.dir")
						+ "\\src\\test\\resources\\AutoIT\\ActivateWindowPopUp.vbs" };
		Runtime.getRuntime().exec(command);
		try {
			if (verifyPath(relativePath)) {
				Runtime.getRuntime().exec(
						relativePath
								+ " "
								+ filePath
								+ " "
								+ getParams.getEnvPerValue("BROWSER_TYPE")
										.toUpperCase());
			}
		} catch (Exception ex) {
			String errMessage = "Unable to upload a file : " + ex.getMessage();
			throw new RuntimeException(errMessage);
		}
	}

	/**
	 * This method will Verify the file path
	 * 
	 * @param filePath
	 *            (required) FilePath to be passed
	 */

	private boolean verifyPath(String filePath) {
		return IsFileExists(Paths.get(filePath));
	}

	/**
	 * This method will check whether the file exists or not
	 * 
	 * @param filePath
	 *            (required) FilePath to be passed
	 * @return true If file exists
	 * @return false If file not exists
	 */

	private boolean IsFileExists(Path filePath) {
		if (Files.exists(filePath))
			return true;
		else
			return false;
	}

	/**
	 * This method will select the value from the drop down
	 * 
	 * @param element
	 *            (required) Web element to be passed
	 * @param text
	 *            (required) text to be passed
	 */

	protected void selectValue(WebElement element, String text) {
		try {
			if (IsElementVisible(element)) {
				Select select = new Select(element);
				select.selectByVisibleText(text);
			}
		} catch (Exception ex) {
			String errMessage = "Unable to select value from the dropDown for a web element - "
					+ element + "" + ex.getMessage();
			throw new RuntimeException(errMessage);
		}
	}

	/**
	 * This method will wait for the element to be visible
	 * 
	 * @param element
	 *            (required) Web element to be passed
	 * @return true If the element is visible
	 * @return false If the element is not visible
	 */

	protected Boolean IsElementVisible(WebElement element) {
		WebDriverWait wait = new WebDriverWait(driver, LONG_WAIT);
		try {
			wait.until(ExpectedConditions.visibilityOf(element));
			return true;
		} catch (Exception ex) {
			return false;
		}

	}

	/**
	 * This method will return the webelement to a String
	 * 
	 * @param element
	 *            (required) Web element to be passed
	 * @return String - Returns the Xpath as a String
	 */
	public String getWebelementToString(WebElement element) {
		String text = null;
		if (element instanceof WebElement) {
			Object obj = element;

			text = obj.toString();
			text = text.substring(text.indexOf("xpath: ") + 7,
					text.length() - 1);
			System.out.println(text);
			return text;
		}
		return text;
	}

	public void verifyDocumentsUpload(String xpath, String documentName,
			WebElement element) {
		int count = 0;

		while (waitForElementDisappear(element)) {
			element = driver.findElement(By.xpath(xpath
					+ "/preceding::img[1][@class = 'uploadtick']"));
			// highlightWebElement(element, "blue");
			report.reportPassScreenshotEvent(documentName
					+ " doc upload status", "Uploaded Successfully");
			break;
		}
	}

	/*public void verifyDocumentsUpload(String xpath, String documentName) {
		WebElement element = null;
		int count = 0;
		element = driver.findElement(By.xpath(xpath
				+ "/preceding::img[1][@class = 'loadingspinner']"));
		while(waitForElementDisappear(element))
		{
			element = driver.findElement(By.xpath(xpath
					+ "/preceding::img[1][@class = 'uploadtick']"));
			//highlightWebElement(element, "blue");
			report.reportPassScreenshotEvent(documentName + " doc upload status",
					"Uploaded Successfully");
			break;
		}
	}*/

	public boolean waitForElementDisappear(WebElement we) {
		try {

			driver.manage().timeouts().implicitlyWait(1, TimeUnit.SECONDS);
			for (int i = 0; i < 120; i++) {
				if (isElementPresent(we)) {
					sleep(1000);
					System.out.println("Sleeping");
				} else {
					System.out.println("Else");
					break;				 
				}
			}
			return !isElementPresent(we);
		} catch (Exception Ex) {
			System.out.println("exception");
			return true;
		}
	}

	protected boolean isElementPresent(WebElement element) {
		try {
			return element.isDisplayed();
		} catch (NoSuchElementException ex) {
			return false;
		} catch (StaleElementReferenceException ex2) {
			return false;
		}
	}
	/**
	 * File Upload using Sikuli
	 */

	/*
	 * public void fileUpload(String filePath) { try { Screen screen = new
	 * Screen(); Pattern fileName = new Pattern(System.getProperty("user.dir") +
	 * "\\src\\test\\resources\\Sikuli\\FileName.PNG"); Pattern open = new
	 * Pattern(System.getProperty("user.dir") +
	 * "\\src\\test\\resources\\Sikuli\\Open.PNG"); String[] command = new
	 * String[] { "cmd.exe", "/C", "Start", System.getProperty("user.dir") +
	 * "\\src\\test\\resources\\Sikuli\\ActivateWindowPopUp.vbs" };
	 * Runtime.getRuntime().exec(command); screen.wait(fileName, 10);
	 * screen.type(fileName, filePath); sleep(2000); screen.click(open);
	 * 
	 * } catch (FindFailed ex) { System.out.println("Unable to find the Image :"
	 * + ex.getMessage()); } catch (Exception ex) {
	 * System.out.println(ex.getMessage()); } }
	 */

	/**
	 * Click using Javascript
	 */
	/*
	 * protected void javaScriptClick(WebElement element, String text) { String
	 * id; JavascriptExecutor executor = (JavascriptExecutor) driver; id =
	 * element.getAttribute("id");
	 * executor.executeScript("document.getElementById('" + id + "').value='" +
	 * text + "'"); }
	 */

	/**
	 * Send text to the web element
	 */

	/*
	 * protected void waitForElementAndEnterText(WebElement element, String
	 * text) {
	 * 
	 * if (waitForElement(element)) { sendText(element, text); } }
	 */

	/**
	 * This method clicks the webelement based on the browser type
	 * 
	 * @param element
	 *            (required) WebElement to be passed
	 */

	/*
	 * private void browserDependentClick(WebElement element) { if
	 * (getParams.getEnvPerValue("BROWSER_TYPE").equalsIgnoreCase("ie")) {
	 * waitForElement(element); element.sendKeys(Keys.ENTER); element.click(); }
	 * else { waitForElement(element); element.click(); //} }
	 */

}
