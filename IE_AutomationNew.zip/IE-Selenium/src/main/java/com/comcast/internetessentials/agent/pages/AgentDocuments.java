package com.comcast.internetessentials.agent.pages;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;

import com.comcast.internetessentials.libraries.GetParameters;
import com.comcast.internetessentials.online.pages.DocumentsUpload;

public class AgentDocuments extends AgentApplicationStatus {

	public AgentDocuments(WebDriver browser, GetParameters params) {
		super(browser, params);
	}

	@FindBy(xpath = "//th[contains(text(),'Documents Uploaded by customer')]")
	@CacheLookup
	private WebElement _docsUploadByCustomerSection;

	@FindBy(xpath = "//div[@id = 'UploadDocument']//following::tr[@class = 'row-highlight']/following-sibling::tr/td[1]")
	@CacheLookup
	private List<WebElement> _documents;

	// Method to verify the uploaded documents text
	public void verifyDocumentsAlternateText() {
		String agentDocumentDescription = null;
		String result = null;
		
		report.addTestLogSection("Agent Alternate Document Description");
		scrollToElement(_docsUploadByCustomerSection);
		String[] docs = DocumentsUpload.expectedDocsText.split(":");
		
		
		for (int i = 0; i < docs.length; i++) {
			boolean IsDocDescriptionEqual = false;
			for (WebElement element : _documents) {
				if(element.getText().trim().equalsIgnoreCase(docs[i])){
					IsDocDescriptionEqual = true;
					agentDocumentDescription = element.getText();
					break;
				}
				else{
					agentDocumentDescription = element.getText();
				}
			}
			
			if(IsDocDescriptionEqual)
			{
				result = "Expected : " +docs[i] + " and Actual : " +agentDocumentDescription + " are same";
				report.reportPassScreenshotEvent("Document Description Verification", result);
			}
			else
			{
				util.reportFailEvent("Document Description",docs[i],agentDocumentDescription);
			}
		}
		
	} 
}
