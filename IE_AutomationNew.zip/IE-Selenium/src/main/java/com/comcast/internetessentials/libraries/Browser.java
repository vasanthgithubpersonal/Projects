package com.comcast.internetessentials.libraries;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxBinary;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxProfile;
import org.openqa.selenium.firefox.internal.ProfilesIni;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.support.ThreadGuard;
import org.testng.Assert;
import org.testng.SkipException;
import org.testng.asserts.SoftAssert;

import com.comcast.internetessentials.reporting.SeleniumReport;

/**
 * The Browser program is implemented which will initialize the different
 * browsers
 * 
 * @author 589478
 * @since 2017-03-03
 * @version 1.0
 */

public class Browser {

	protected static WebDriver driver;
	protected static Reports report;
	public static GetParameters getParams;
	private String applicationType;
	private String portal;
	public static String url;
	private static Map<String, Object> preferences = new HashMap<String, Object>();
	protected com.comcast.internetessentials.online.pages.PageFactory onlinePages;
	protected com.comcast.internetessentials.agent.pages.PageFactory manualPages;

	/**
	 * Parameterized Constructor It will load the test data for IE application
	 */
	public Browser(String application, String testname) {
		getParams = new GetParameters(testname);
		
		switch (getParams.getTestPerValue("AgentValidation").toUpperCase()) {
		case "YES":
			url = getParams.getEnvPerValue("CUSTOMER_PORTAL") + "<br>"
					+ getParams.getEnvPerValue("AGENT_PORTAL");
			break;

		case "NO":
			url = getParams.getEnvPerValue("CUSTOMER_PORTAL");
			break;

		default:
			url = getParams.getEnvPerValue("LEARNING_PORTAL");
			break;
		}

		if (getParams.getEnvPerValue("EXE_MODE") == null) {
			driver = initializeDriver();
		} else if (getParams.getEnvPerValue("EXE_MODE").equalsIgnoreCase(
				"LOCAL")) {

			if (driver == null) {
				driver = initializeDriver();
			}
		}
		
		if(report == null){
			report = new Reports(testname, driver);
		}

		this.applicationType = application;

		switch (applicationType.trim().toUpperCase()) {
		case "CUSTOMER":
		case "ONLINE":
			onlinePages = new com.comcast.internetessentials.online.pages.PageFactory(
					driver, getParams);
			navigateToCustomerPortal();
			break;

		case "AGENT":
		case "MANUAL":
			manualPages = new com.comcast.internetessentials.agent.pages.PageFactory(
					driver, getParams);
			navigateToAgentPortal();
			break;

		case "LEARNING PORTAL":
		case "LEARNING":
			navigateToLearningPortal();
			break;
		}
	}

	/**
	 * This program will navigate to the IE Learning Portal
	 */
	private void navigateToLearningPortal() {
		portal = getParams.getEnvPerValue("LEARNING_PORTAL");
		driver.get(portal);

	}

	/**
	 * This program will navigate to the IE Agent Portal
	 */
	private void navigateToAgentPortal() {
		portal = getParams.getEnvPerValue("AGENT_PORTAL");
		driver.get(portal);
	}

	/**
	 * This program will navigate to the IE Customer Portal
	 */
	private void navigateToCustomerPortal() {
		portal = getParams.getEnvPerValue("CUSTOMER_PORTAL");
		if (getParams.getEnvPerValue("BROWSER_TYPE").equalsIgnoreCase("ie")) {
			driver.get(portal);
			driver.navigate()
					.to("javascript:document.getElementById('overridelink').click()");
		} else {
			driver.get(portal);
		}

	}

	/**
	 * This program will iniialize the browsers(Chrome (or) Firefox (or)
	 * Internet Explorer) based on the value passed in the framework.properties
	 */

	private WebDriver initializeDriver() {
		String browser = null;
		DesiredCapabilities capabilities;
		String relativePath = new File(System.getProperty("user.dir"))
				.getAbsolutePath();
		if (relativePath.endsWith("bin"))
			relativePath = new File(System.getProperty("user.dir")).getParent();
		relativePath = relativePath + "//src//test//seleniumdriver//";

		if ((!getParams.getEnvPerValue("BROWSER_TYPE").isEmpty())
				&& getParams.getEnvPerValue("BROWSER_TYPE").equalsIgnoreCase(
						"chrome")) {
			browser = getParams.getEnvPerValue("BROWSER_TYPE").trim()
					.toLowerCase();
		} else if ((!getParams.getEnvPerValue("BROWSER_TYPE").isEmpty())
				&& getParams.getEnvPerValue("BROWSER_TYPE").equalsIgnoreCase(
						"firefox")) {
			browser = getParams.getEnvPerValue("BROWSER_TYPE").trim()
					.toLowerCase();
		} else {
			browser = "ie";
		}

		switch (browser.toUpperCase()) {
		case "IE":
			System.setProperty("webdriver.ie.driver", relativePath
					+ "IEDriverServer.exe");

			capabilities = DesiredCapabilities.internetExplorer();
			capabilities.setJavascriptEnabled(false);
			capabilities
					.setCapability(
							InternetExplorerDriver.INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS,
							true);
			capabilities.setCapability(
					InternetExplorerDriver.IE_ENSURE_CLEAN_SESSION, true);

			driver = ThreadGuard.protect(new InternetExplorerDriver(
					capabilities));
			break;

		case "CHROME":
			System.setProperty("webdriver.chrome.driver", relativePath+ "chromedriver.exe");
			ChromeOptions options = new ChromeOptions();
			
			preferences.put("credentials_enable_service", false);
			preferences.put("password_manager_enabled", false); 
			options.setExperimentalOption("prefs", preferences);
			driver = new ChromeDriver(options);
			break;

		case "FIREFOX":

			// driver = new FirefoxDriver();
			/*
			 * ProfilesIni profilesIni = new ProfilesIni();
			 * 
			 * FirefoxProfile profile = profilesIni.getProfile("default");
			 * driver = new FirefoxDriver();
			 * profile.setEnableNativeEvents(true);
			 * 
			 * driver = ThreadGuard.protect(new FirefoxDriver(profile));
			 */
			// ThreadDriver.set(driver);

			FirefoxBinary binary = new FirefoxBinary(new File(
					"C:\\Program Files (x86)\\Mozilla Firefox\\firefox.exe"));
			driver = new FirefoxDriver(binary, null);
			break;
		}
		driver.manage().window().maximize();
		return driver;
	}

	/**
	 * This program will close the browser
	 */
	public void closeBrowser() {

		if (driver != null) {
			driver.close();
			driver.quit();
			driver = null;
			report = null;
		}
	}

	/**
	 * This program will return the driver and getParameters to the Page Factory
	 * class
	 */
	public com.comcast.internetessentials.online.pages.PageFactory onlinePortal() {
		return onlinePages;
	}

	public com.comcast.internetessentials.agent.pages.PageFactory agentPortal() {
		return manualPages;
	}
}
