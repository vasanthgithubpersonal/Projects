package com.comcast.internetessentials.libraries;

import org.openqa.selenium.WebDriver;
import org.testng.ITestContext;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeSuite;

import com.comcast.internetessentials.alm.ALMTestInformation;
import com.comcast.internetessentials.alm.ALMUpdaterClient;
import com.comcast.internetessentials.reporting.Report;
import com.comcast.internetessentials.reporting.ReportPath;
import com.comcast.internetessentials.reporting.ReportSettings;
import com.comcast.internetessentials.reporting.ReportThemeFactory;
import com.comcast.internetessentials.reporting.ReportThemeFactory.Theme;
import com.comcast.internetessentials.reporting.SeleniumReport;
import com.comcast.internetessentials.reporting.Util;

public class Reports {

	public static SeleniumReport report;
	public static SeleniumReport reportSummary;
	private static long startTestTime;
	private static long startSuiteTime;
	private static long endSuiteTime;
	private static long endTime;
	protected static long testDuration;
	public String timeStr;
	public int nTestsPassed, noOfTestsPassed;
	public int nTestsFailed, noOfTestsFailed;
	public String testStatus;
	public static String testCaseName;
	public String testSuiteName;
	public static GetParameters getparams;

	/**
	 * Default Constructor
	 */
	public Reports() {
	}

	/**
	 * Parameterized Constructor to load the GetParameters class
	 * 
	 * @param getParameters
	 *            (required) GetParameters to be passed
	 */

	public Reports(GetParameters getParameters) {
		this.getparams = getParameters;
	}

	/**
	 * Parameterized Constructor to initialize the reports and the assign the
	 * testcase Name
	 * 
	 * @param testName
	 *            (required) testName to be passed
	 * 
	 * @param driver
	 *            (required) driver to be passed
	 */

	@SuppressWarnings("static-access")
	public Reports(String testName, WebDriver driver) {
		initializeReport(testName, driver);
		this.testCaseName = testName;

	}

	/**
	 * This program is implemented to initialize the Summary report
	 * 
	 * @param context
	 *            (required) testNG ITestContext to be passed
	 */
	@BeforeSuite
	public synchronized void startMainBeforeSuite(ITestContext context) {
		startSuiteTime = System.currentTimeMillis();
		testSuiteName = context.getCurrentXmlTest().getSuite().getName();
		initializeSummaryReport();
	}

	/**
	 * This program is implemented to initialize the Summary report
	 */

	private synchronized void initializeSummaryReport() {
		String reportPath = ReportPath.getInstance().getReportPath();
		ReportSettings reportSettings = new ReportSettings(reportPath,
				"Execution Summary");
		reportSettings.generateHtmlReports = true;
		reportSettings.takeScreenshotFailedStep = true;
		reportSummary = new SeleniumReport(reportSettings,
				ReportThemeFactory.getReportsTheme(Theme.IE));

		reportSummary.initializeReportTypes();
		reportSummary.initializeResultSummary();
		reportSummary
				.addResultSummaryHeading("Internet Essentials Execution Summary");
		reportSummary.addResultSummarySubHeading("Component", "TestCaseName",
				"Time", "Status");
	}

	/**
	 * This program is implemented to display the number of passed and failed
	 * tests in the summary footer. It will also display the total time taken to
	 * execute the scripts
	 */

	@AfterSuite(alwaysRun = true)
	public synchronized void endMainBeforeSuite(ITestContext context) {
		endSuiteTime = System.currentTimeMillis();
		Long timeTaken = endSuiteTime - startSuiteTime;
		timeStr = getTimeTakenStr(timeTaken);
		reportSummary.addResultSummaryFooter(timeStr, noOfTestsPassed,
				noOfTestsFailed);
	}

	/**
	 * This program is implemented to display the passed/failed steps in the
	 * testLog Footer.
	 * @throws Exception 
	 */

	@AfterMethod(alwaysRun = true)
	public synchronized void endMainAfterMethod(ITestResult result) throws Exception {
		
		if(Utilities.data != null){
			Utilities.data.clear();
			Utilities.applicationNumber = null;
			Utilities.telephoneNumber = null;
		}
		if (Report.noOfStepsFailed >= 1)
			noOfTestsFailed++;
		else
			noOfTestsPassed++;
		int mStatus = result.getStatus();
		endTestMain(mStatus);
	}

	/**
	 * This program is implemented to display the passed/failed steps in the
	 * testLog Footer. It will also update the total time taken in the summary
	 * report
	 * @throws Exception 
	 */
	private synchronized void endTestMain(int status) throws Exception {

		endTime = System.currentTimeMillis();
		Long timeTaken = endTime - startTestTime;
		timeStr = getTimeTakenStr(timeTaken);
		if (status == 1) {
			nTestsPassed++;
			testStatus = "Passed";
		} else {
			nTestsFailed++;
			testStatus = "Failed";
		}
		report.addTestLogFooter(timeStr);
		updateTestSummary();
		//almRestUpdateStatus(timeTaken);
	}
	
	public void almRestUpdateStatus(Long timeTaken) {
		Util util = new Util();
		System.out.println("almRestUpdateStatus()");
		String reportPath = ReportPath.getInstance().getReportPath();		
		Util.createResultFile(reportPath, testStatus);
		System.out.println("ALM Update testStatus= " + testStatus);
		util.createZipFileOfReport(reportPath, testCaseName);
		timeTaken = timeTaken / 1000; // Converting to seconds
		String duration = timeTaken.toString();	
		
		String testSetID = getparams.getEnvPerValue("TEST_SET_ID");
		System.out.println(testSetID);
		if (!((testSetID == null) || (testSetID == ""))) {
			ALMTestInformation ALMInfo = new ALMTestInformation();
			ALMUpdaterClient ALMUpdate = new ALMUpdaterClient();
			String testID;
			try {
				testSetID = getparams.getEnvPerValue("TEST_SET_ID");				
				testID = ALMInfo.GetTestID(testCaseName);
				ALMUpdate.createTestRUN(testSetID, testCaseName, testID,
						testStatus, duration);
				String component = ALMInfo.getTestComponent(testID);
			} catch (Exception e1) {
				System.err.println("Failed ALM Update" + "---" + e1.getMessage());
				e1.printStackTrace();
			}
		}
		System.out.println("Done: almRestUpdateStatus()");

	}

	/**
	 * This program is implemented to update the test summary in the report
	 * 
	 */
	private synchronized void updateTestSummary() {
		reportSummary.updateResultSummary(testSuiteName, testCaseName, timeStr,
				testStatus);
	}

	/**
	 * This program is implemented to calculate the time taken to execute the
	 * tests
	 * 
	 * @param timeTaken
	 *            (required) time to be passed
	 * 
	 */
	private synchronized String getTimeTakenStr(Long timeTaken) {

		int h = (int) ((timeTaken / 1000) / 3600);
		int m = (int) (((timeTaken / 1000) / 60) % 60);
		int s = (int) ((timeTaken / 1000) % 60);
		String time = "" + h + ":hh " + m + ":mm " + s + ":ss";
		return time;
	}

	/**
	 * This program is implemented to initialize the report
	 * @param testCaseName
	 *            (required) testCaseName to be passed
	 * @param browser
	 *            (required) browser to be passed
	 * 
	 */
	public synchronized void initializeReport(String testCaseName,
			WebDriver browser) {
		startTestTime = System.currentTimeMillis();

		String reportPath = ReportPath.getInstance().getReportPath();
		ReportSettings reportSettings = new ReportSettings(reportPath,
				testCaseName);
		reportSettings.generateHtmlReports = true;
		reportSettings.takeScreenshotFailedStep = true;
		if (getparams == null) {
			getparams = new GetParameters();
		}

		reportSettings.takeScreenshotPassedStep = getparams
				.isTestSettingTrue("TAKES_SCREENSHOT_PASS");
		report = new SeleniumReport(reportSettings,
				ReportThemeFactory.getReportsTheme(Theme.IE));
		report.setDriver(browser);
		report.initializeReportTypes();
		report.initializeTestLog();
		report.addTestLogHeading(getparams.getEnvPerValue("APPLICATION") + ":"
				+ testCaseName);

		report.addTestLogSubHeading(
				"BROWSER : "
						+ getparams.getEnvPerValue("BROWSER_TYPE")
								.toUpperCase(), "URL : " + Browser.url,
				"ENVIRONMENT : "
						+ getparams.getEnvPerValue("ENV_KEY").toUpperCase());
		report.addTestLogTableHeadings();
	}

}
