package com.comcast.internetessentials.online.pages;

import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.comcast.internetessentials.libraries.Common;
import com.comcast.internetessentials.libraries.GetParameters;
import com.comcast.internetessentials.libraries.Reports;
import com.comcast.internetessentials.libraries.Utilities;
import com.comcast.internetessentials.reporting.SeleniumReport;

public class PersonalDetails extends Common{

	@FindBy(xpath = "//*[@id='picker-months']")
	@CacheLookup
	private WebElement _month;
	
	@FindBy(xpath = "//*[@id='picker-days']")
	@CacheLookup
	private WebElement _day;
	
	@FindBy(xpath = "//*[@id='picker-years']")
	@CacheLookup
	private WebElement _year;
	
	@FindBy(xpath = "//*[@id='SSNField1']")
	@CacheLookup
	private WebElement _SSNFieldOne;
	
	@FindBy(xpath = "//*[@id='SSNField2']")
	@CacheLookup
	private WebElement _SSNFieldTwo;
	
	@FindBy(xpath = "//*[@id='SSNField3']")
	@CacheLookup
	private WebElement _SSNFieldThree;
	
	@FindBy(xpath = "//*[@id='CSSNField1']")
	@CacheLookup
	private WebElement _CSSNFieldOne;
	
	@FindBy(xpath = "//*[@id='CSSNField2']")
	@CacheLookup
	private WebElement _CSSNFieldTwo;
	
	@FindBy(xpath = "//*[@id='CSSNField3']")
	@CacheLookup
	private WebElement _CSSNFieldThree;
	
	@FindBy(xpath = "//*[@id='ssnCheckBox']")
	@CacheLookup
	private WebElement _SSNCheckBox;
	
	@FindBy(xpath = "//div[contains(text(),'or')]/following-sibling::center/descendant::button[contains(text(),'Cancel')]")
	@CacheLookup
	private WebElement _SSNSelfieCancel;
	
	@FindBy(xpath = "//*[@id='HereAboutIE']")
	@CacheLookup
	private WebElement _hereAboutIE;
	
	@FindBy(xpath = "//*[@id='CurrentInternetProvider']")
	@CacheLookup
	private WebElement _currentInternetProvider;
	
	@FindBy(xpath = "//*[@id='saveBtn']")
	@CacheLookup
	private WebElement _personalDetailsSave;

	@FindBy(xpath = "//*[@name = 'PersonalDetailsNext']")
	@CacheLookup
	private WebElement _personalDetailsNext;
	
	@FindBy(xpath = "//*[@id='SaveOkBtn']")
	@CacheLookup
	private WebElement _popupOk;
	
	@FindBy(xpath = "//p[contains(text(),'Application Saved')]")
	@CacheLookup
	private WebElement _applicationState;
	
	@FindBy(xpath = "//span[@id = 'applicationSavedID']")
	@CacheLookup
	private WebElement _applicationNumber;
	
	public PersonalDetails(WebDriver browser, GetParameters getParameters) {
		super(browser,getParameters);
		PageFactory.initElements(browser, this);
	}
	public static String DOB = null;
	public void personalDetailspage(String ssn){
		
		report.addTestLogSection("Personal Details Page");

		if(getParams.getTestPerValue("DOB").equalsIgnoreCase("na")){
			
			DOB = util.get("DOB");
			
			selectValue(_month, DOB.substring(0,2));
			selectValue(_day, DOB.substring(3,5));
			selectValue(_year, DOB.substring(6,10));
			util.reportDoneEvent("DateOfBirth", DOB);		
			
		}else{
			
			DOB = getParams.getTestPerValue("DOB").trim();
			selectValue(_month, DOB.substring(0,2));
			selectValue(_day, DOB.substring(3,5));
			selectValue(_year, DOB.substring(6,10));
			util.set("DOB", DOB);
			util.reportDoneEvent("DateOfBirth", DOB);
		}
			if(ssn.equalsIgnoreCase("yes")){
				
				sendText(_SSNFieldOne,util.get("SSN"));
				sendText(_CSSNFieldOne,util.get("SSN"));
				util.reportDoneEvent("SocialSecurityNumber", util.get("SSN"));
				
			}else{
				click(_SSNCheckBox);
				if(waitForElement(_SSNSelfieCancel, 10)){
					
					scrollToElementAndClick(_SSNSelfieCancel);
					util.reportDoneEvent("No SSN Checkbox", "Clicked Successfully");
				}
				//Assigning Null value for SSN
				util.set("SSN", "NULL");
			}
			
			selectValue(_hereAboutIE,util.get("HEAR_ABOUT_IE"));
			util.reportDoneEvent("Hear About IE", util.get("HEAR_ABOUT_IE"));
			
			selectValue(_currentInternetProvider,util.get("INTERNET_SERVICE_PROVIDER"));
			util.reportDoneEvent("Other Internet Service Provider", util.get("INTERNET_SERVICE_PROVIDER"));
			
			//Save the Application
			if(getParams.getTestPerValue("AppState").trim().equalsIgnoreCase("save")&& getParams.getTestPerValue("PageToExit").trim().equalsIgnoreCase("personaldetailspage"))
			{
				scrollToElementAndClick(_personalDetailsSave);
				if(waitForElement(_popupOk, 5)){
					click(_popupOk);
					
					if(waitForElement(_applicationNumber, 10)){
						//Assigning Application Number to the static variable 
						Utilities.applicationNumber = _applicationNumber.getText();
					}
				}
				util.setApplicationStatus("Saved",getParams.getTestPerValue("SSN"),getParams.getTestPerValue("AutoApproved"));	
			}
			else
			{
				scrollToElementAndClick(_personalDetailsNext);
				waitforPageLoadComplete();		
				util.setApplicationStatus("Initiated",getParams.getTestPerValue("SSN"),getParams.getTestPerValue("AutoApproved"));
			}
			
			util.verifyPersonalDetailsPage();
			//Verify page data
			//util.verifyBasicDetailsPage();
			
			
			//Verifying the Application Status
			
			if(util.get("APPLICATION_STATUS").equalsIgnoreCase("saved"))
				util.verifyDBValue("Application", "Status", util.get("APPLICATION_STATUS"));
			
			else
				util.verifyDBValue("Application", "Status", util.get("APPLICATION_STATUS"));
			
			
		}		
}
