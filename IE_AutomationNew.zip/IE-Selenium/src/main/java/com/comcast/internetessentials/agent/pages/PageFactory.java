package com.comcast.internetessentials.agent.pages;

import org.openqa.selenium.WebDriver;

import com.comcast.internetessentials.libraries.GetParameters;
import com.comcast.internetessentials.reporting.SeleniumReport;

public class PageFactory {
	protected WebDriver driver;
	protected GetParameters getParams;
	protected SeleniumReport report;

	public PageFactory(WebDriver browser, GetParameters getParameters) {
		this.driver = browser;
		this.getParams = getParameters;

	}

	public Login login() {
		Login login = new Login(driver, getParams);
		return login;
	}

	public Logout logout() {
		Logout logout = new Logout(driver, getParams);
		return logout;
	}

	public AgentApplicationStatus agentApplicationStatus() {
		AgentApplicationStatus agentApplicationStatus = new AgentApplicationStatus(driver, getParams);
		return agentApplicationStatus;
	}

	public AgentSearch agentSearch() {
		AgentSearch agentSearch = new AgentSearch(driver, getParams);
		return agentSearch;
	}
	
	public AgentDocuments agentDocuments(){
		AgentDocuments agentDocuments = new AgentDocuments(driver, getParams);
		return agentDocuments;
	}
}

