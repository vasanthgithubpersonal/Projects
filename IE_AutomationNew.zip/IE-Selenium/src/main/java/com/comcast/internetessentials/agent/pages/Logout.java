package com.comcast.internetessentials.agent.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;

import com.comcast.internetessentials.libraries.Common;
import com.comcast.internetessentials.libraries.GetParameters;
import com.comcast.internetessentials.libraries.Reports;
import com.comcast.internetessentials.reporting.SeleniumReport;

public class Logout extends Common{

	@FindBy(xpath = "//*[@id='cultureLable']//a[1]")
	@CacheLookup
	private WebElement _logout;
	
	public Logout(WebDriver browser, GetParameters getParameters) {
		super(browser,getParameters);
	}
}
