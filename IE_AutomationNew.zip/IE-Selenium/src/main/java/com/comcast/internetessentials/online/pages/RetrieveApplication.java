package com.comcast.internetessentials.online.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

import com.comcast.internetessentials.libraries.Common;
import com.comcast.internetessentials.libraries.GetParameters;
import com.comcast.internetessentials.libraries.Utilities;

public class RetrieveApplication extends Common {

	@FindBy(xpath = "//*[@id='RetriveAppLink']")
	@CacheLookup
	public WebElement _resumeApplicationLink;

	@FindBy(xpath = "//h2[contains(text(),'Welcome Back')]")
	@CacheLookup
	public WebElement _popupWelcomeText;

	@FindBy(xpath = "//*[@id='SearchAppnumber']")
	@CacheLookup
	public WebElement _popupApplicationId;

	@FindBy(xpath = "//*[@id='SearchLastNameWithAppNo']")
	@CacheLookup
	public WebElement _popupLastName;

	@FindBy(xpath = "//*[@id='submitRetriveAppModal']")
	@CacheLookup
	public WebElement _popupSumit;

	@FindBy(xpath = "//label[contains(text(),'Protecting Your Identity')]")
	@CacheLookup
	public WebElement _popupProtectIdentity;

	@FindBy(xpath = "//*[@id='RetriveOkBtn']")
	@CacheLookup
	public WebElement _popupIdentityOk;

	@FindBy(xpath = "//*[@id='backBtn']")
	// @CacheLookup
	public WebElement _back;

	@FindBy(xpath = "//p[@class = 'page-msg-center page-msg-title1']")
	@CacheLookup
	public WebElement _basicWelcomeText;

	@FindBy(xpath = "//*[@id='FirstName']")
	@CacheLookup
	private WebElement _firstName;

	@FindBy(xpath = "//*[@id='LastName']")
	@CacheLookup
	private WebElement _lastName;

	@FindBy(xpath = "//*[@id='Email']")
	@CacheLookup
	private WebElement _emailField;

	@FindBy(xpath = "//*[@id='PhoneField1']")
	@CacheLookup
	private WebElement _phoneField1;

	@FindBy(xpath = "//*[@id='PhoneField2']")
	@CacheLookup
	private WebElement _phoneField2;

	@FindBy(xpath = "//*[@id='PhoneField3']")
	@CacheLookup
	private WebElement _phoneField3;

	@FindBy(xpath = "//*[@id='txtStreetAdd']")
	@CacheLookup
	private WebElement _streetAddress;

	@FindBy(xpath = "//*[@id='UnitNum']")
	@CacheLookup
	private WebElement _apartment;

	@FindBy(xpath = "//*[@id='ZipCode']")
	@CacheLookup
	private WebElement _zipCode;

	@FindBy(id = "edit-submit")
	@CacheLookup
	public WebElement _basicPageNext;

	@FindBy(xpath = "//*[@id='picker-months']")
	@CacheLookup
	private WebElement _month;

	@FindBy(xpath = "//*[@id='picker-days']")
	@CacheLookup
	private WebElement _day;

	@FindBy(xpath = "//*[@id='picker-years']")
	@CacheLookup
	private WebElement _year;

	@FindBy(xpath = "//*[@id='SSNField1']")
	@CacheLookup
	private WebElement _SSNFieldOne;

	@FindBy(xpath = "//*[@id='CSSNField1']")
	@CacheLookup
	private WebElement _CSSNFieldOne;

	@FindBy(xpath = "//*[@id='ssnCheckBox']")
	@CacheLookup
	private WebElement _SSNCheckBox;

	@FindBy(xpath = "//div[contains(text(),'or')]/following-sibling::center/descendant::button[contains(text(),'Cancel')]")
	@CacheLookup
	private WebElement _SSNSelfieCancel;

	@FindBy(xpath = "//*[@id='HereAboutIE']")
	@CacheLookup
	private WebElement _hereAboutIE;

	@FindBy(xpath = "//*[@id='CurrentInternetProvider']")
	@CacheLookup
	private WebElement _currentInternetProvider;

	@FindBy(xpath = "//*[@name = 'PersonalDetailsNext']")
	@CacheLookup
	private WebElement _personalDetailsNext;

	@FindBy(xpath = "//p[@class = 'page-msg headermsG']")
	@CacheLookup
	private WebElement _personalWelcomeText;

	@FindBy(xpath = "//*[@id='submit']")
	@CacheLookup
	private WebElement _programTypeNext;

	@FindBy(xpath = "//*[@id='FileUploadReadNow']")
	@CacheLookup
	private WebElement _essentialStepsUploadDocumentsNow;

	public RetrieveApplication(WebDriver browser, GetParameters getParameters) {
		super(browser, getParameters);
		PageFactory.initElements(browser, this);
	}

	public static String DOB = null;

	public void homePage() {

		report.addTestLogSection("Retrieve Application");
		try {
			if (getParams.getTestPerValue("RetrieveApplication")
					.equalsIgnoreCase("yes")) {

				driver.get(getParams.getEnvPerValue("CUSTOMER_PORTAL"));

				retrieveApplication();
				
				switch (getParams.getTestPerValue("PageToExit").toUpperCase()) {
				case "PROGRAMSELECTIONPAGE":
					// Program selection page validation
					if (getParams.getTestPerValue("SSN")
							.equalsIgnoreCase("yes")) {
						if (waitForElement(_popupProtectIdentity, 10)) {
							click(_popupIdentityOk);
							scrollToElementAndClick(_back);
							basicDetailsPage();
							personalDetailsPage();
							scrollToElementAndClick(_personalDetailsNext);
						} else {
							report.reportSoftFailEvent(
									"Protect Identity Popup", "Not displayed");
						}

					} else {
						String url = driver.getCurrentUrl();
						if (url.toLowerCase().contains("programselection")) {
							int i = 0;
							while (i < 2) {
								waitForElement(_back, 10);
								scrollToElementAndClick(_back);
								i++;
							}
							basicDetailsPage();
							personalDetailsPage();
							scrollToElementAndClick(_personalDetailsNext);
						} else if (url.toLowerCase()
								.contains("personaldetails")) {
							waitForElement(_back, 10);
							scrollToElementAndClick(_back);
							basicDetailsPage();
							personalDetailsPage();
							scrollToElementAndClick(_personalDetailsNext);
						}
					}
					break;

				case "PERSONALDETAILSPAGE":
					// Personal Details Page
					if (getParams.getTestPerValue("SSN").equalsIgnoreCase("yes")) {
						if (waitForElement(_popupProtectIdentity, 10)) {
							click(_popupIdentityOk);
							scrollToElementAndClick(_back);
							basicDetailsPage();
							personalDetailsPage();
						}
						else{
							report.reportSoftFailEvent("Protect Identity Popup", "Not displayed");
						}
					}else{
						String url = driver.getCurrentUrl();
						if (url.toLowerCase().contains("programselection")) {
							int i = 0;
							while (i < 2) {
								waitForElement(_back, 10);
								scrollToElementAndClick(_back);
								i++;
							}
							basicDetailsPage();
							personalDetailsPage();
						} else if ((url.toLowerCase()
								.contains("personaldetails"))) {
							waitForElement(_back, 10);
							scrollToElementAndClick(_back);
							basicDetailsPage();
							personalDetailsPage();
						}
						
					}
					break;
				}


			}
		}catch(Exception ex){
			ex.printStackTrace();
		}
	}
		
	/*
	 * case "DOCUMENTSUPLOADPAGE": // Documents Upload Page if
	 * (getParams.getTestPerValue("SSN") .equalsIgnoreCase("yes")) { if
	 * (waitForElement(_popupProtectIdentity, 10)) { click(_popupIdentityOk);
	 * documentsUploadPage(); }
	 * 
	 * } else { if (waitForElement(_back, 10)) { documentsUploadPage();
	 * 
	 * } }
	 * 
	 * break; } }
	 */

	private void retrieveApplication() {
		click(_resumeApplicationLink);

		// click on the retrieve Application
		if (waitForElement(_popupWelcomeText, 10)) {
			sendText(_popupApplicationId, Utilities.applicationNumber);
			sendText(_popupLastName, util.get("LASTNAME"));
			click(_popupSumit);
		}
	}

	private void documentsUploadPage() {
		scrollToElementAndClick(_back);
		waitforPageLoadComplete();
		basicDetailsPage();

		personalDetailsPage();
		scrollToElementAndClick(_personalDetailsNext);
		waitforPageLoadComplete();
		scrollToElementAndClick(_programTypeNext);
		waitforPageLoadComplete();
		scrollToElement(_essentialStepsUploadDocumentsNow);
		waitforPageLoadComplete();
	}

	private void personalDetailsPage() {

		if (getParams.getTestPerValue("DOB").equalsIgnoreCase("na")) {

			DOB = util.get("DOB");

			selectValue(_month, DOB.substring(0, 2));
			selectValue(_day, DOB.substring(3, 5));
			selectValue(_year, DOB.substring(6, 10));

		} else {

			DOB = getParams.getTestPerValue("DOB").trim();
			selectValue(_month, DOB.substring(0, 2));
			selectValue(_day, DOB.substring(3, 5));
			selectValue(_year, DOB.substring(6, 10));
			util.set("DOB", DOB);
		}

		if (getParams.getTestPerValue("SSN").equalsIgnoreCase("yes")) {

			sendText(_SSNFieldOne, util.get("SSN"));
			sendText(_CSSNFieldOne, util.get("SSN"));

		} /*
		 * else { click(_SSNCheckBox); if (waitForElement(_SSNSelfieCancel, 10))
		 * {
		 * 
		 * scrollToElementAndClick(_SSNSelfieCancel); } }
		 */
		String hearAboutIE = new Select(_hereAboutIE).getFirstSelectedOption()
				.getText();
		util.verifyDBValue("Application", "HearAboutIE", hearAboutIE);

		String internetServiceProvider = new Select(_currentInternetProvider)
				.getFirstSelectedOption().getText();
		util.verifyDBValue("Application", "HaveServiceFromOtherProvider",
				internetServiceProvider);
	}

	private void basicDetailsPage() {
		if (waitForElement(_basicWelcomeText, 15)) {
			String firstName = _firstName.getAttribute("value");
			util.verifyDBValue("Application", "FirstName", firstName);

			String lastName = _lastName.getAttribute("value");
			util.verifyDBValue("Application", "LastName", lastName);

			String email = _emailField.getAttribute("value");
			if (email.isEmpty()) {
				email = null;
				util.verifyDBValue("Application", "Email", email);

			} else {
				util.verifyDBValue("Application", "Email", email);
			}

			int phoneNumber = Integer.valueOf(String.valueOf(_phoneField1
					.getAttribute("value"))
					+ String.valueOf(_phoneField2.getAttribute("value"))
					+ String.valueOf(_phoneField3.getAttribute("value")));

			util.verifyDBValue("Application", "TelephoneNumber",
					String.valueOf(phoneNumber));

			String address = String.valueOf(_streetAddress
					.getAttribute("value") + ", ")
					+ String.valueOf("APT " + _apartment.getAttribute("value")
							+ ", ")
					+ String.valueOf(_zipCode.getAttribute("value"));

			util.verifyDBValue("Application", "Address", address);

			scrollToElementAndClick(_basicPageNext);
			waitforPageLoadComplete();
		}
	}
}
