package com.comcast.internetessentials.online.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.comcast.internetessentials.libraries.Common;
import com.comcast.internetessentials.libraries.GetParameters;
import com.comcast.internetessentials.libraries.Reports;
import com.comcast.internetessentials.libraries.Utilities;
import com.comcast.internetessentials.reporting.SeleniumReport;

public class ReviewAndConfirm extends Common {

	@FindBy(xpath = "//*[@id='terms']")
	@CacheLookup
	private WebElement _tcAgree;

	@FindBy(xpath = "//*[@id='edit-back']")
	@CacheLookup
	private WebElement _tcBack;

	@FindBy(xpath = "//*[@id='btnnext']")
	@CacheLookup
	private WebElement _tcConfirm;

	@FindBy(xpath = "//span[@id = 'applicationSavedID']")
	@CacheLookup
	private WebElement _autoApprovedApplicationNumber;

	@FindBy(xpath = "//p[contains(text(),'CONGRATULATIONS!')]")
	@CacheLookup
	private WebElement _congrats;

	/*@FindBy(xpath = "//p[contains(text(), 'Application Summary')]//preceding::p[1]")
	@CacheLookup
	private WebElement _nonAutoApprovedApplicationNumber;*/
	
	@FindBy(xpath = "//p[contains(text(), 'for Eligible Households')]//following::span[@id = 'applicationSavedID'] | //p[contains(text(), 'for Eligible Households')]//following::p[@class = 'page-msg-center page-msg-title5']")
	@CacheLookup
	private WebElement _nonAutoApprovedApplicationNumber;
	
	@FindBy(xpath = "//p[contains(text(), 'Application Summary')]")
	@CacheLookup
	private WebElement _applicationSummary;

	public ReviewAndConfirm(WebDriver browser, GetParameters getParameters) {
		super(browser, getParameters);
		PageFactory.initElements(browser, this);
	}

	public void reviewAndConfirmPage() {
		try{		
			report.addTestLogSection("Review and Confirm Page");
			scrollToElement(_tcAgree);
			clickCheckboxOrRadioButton(_tcAgree);
			util.reportDoneEvent("Terms and Conditions","Selected Successfully");
			scrollToElementAndClick(_tcConfirm);
			waitforPageLoadComplete();
			
			if (getParams.getTestPerValue("AppState").equalsIgnoreCase("submit")) {
				if (getParams.getTestPerValue("AutoApproved").equalsIgnoreCase(
						"yes")) {
					
					if (waitForElement(_congrats, 10)
							&& _congrats.getText().equalsIgnoreCase(
									"congratulations!")) {
						report.reportPassScreenshotEvent("Is Order Confirmed", "Yes");
						// Retrieve the autoapproved application number
						String applicationId = _autoApprovedApplicationNumber.getText();
						String[] applicationNumber = applicationId.split(":");
						report.reportPassEvent("Is AutoApproved", "Yes");
						if (applicationNumber[1] != null
								&& !applicationNumber[1].isEmpty()) {
							Utilities.applicationNumber = applicationNumber[1];
							report.reportPassEvent("Application Number",applicationNumber[1]);
						} else {
							report.reportSoftFailEvent("Application Number",
									applicationNumber[1]);
						}
					}
				} else {
					if (waitForElement(_nonAutoApprovedApplicationNumber, 10)) {
						// Retrieve the non autoapproved application number
						String applicationNumber = _nonAutoApprovedApplicationNumber.getText();
						report.reportPassScreenshotEvent("Is Order Confirmed", "Yes");
						report.reportPassEvent("Is AutoApproved", "No");
						
						if(applicationNumber != null && !applicationNumber.isEmpty()){
							if(applicationNumber.toLowerCase().contains("application id")){
								String[] applicationId = applicationNumber.split(":");
								Utilities.applicationNumber = applicationId[1];
								report.reportPassEvent("Application Number", "Application ID: "  +applicationId[1]);
							}
							else{
								Utilities.applicationNumber = applicationNumber;
								report.reportPassEvent("Application Number", "Application ID: "  +applicationNumber);
							}
						}
						else{
							report.reportSoftFailEvent("Application Number",applicationNumber);
						}
					}
				}
			}
			util.setApplicationStatus("Submitted", getParams.getTestPerValue("SSN"),getParams.getTestPerValue("AutoApproved"));
			
			switch(util.get("APPLICATION_STATUS").toUpperCase()){
			
			case "PENDING VERIFICATION DOCS AND ID":
			case "PENDING VERIFICATION - DOCS":
			case "PENDING VERIFICATION - ID":
			case "APPROVED":
				util.verifyDBValue("Application", "Status", util.get("APPLICATION_STATUS"));
				break;
			}
			
		}catch (Exception ex) {
			System.out.println(ex.getMessage());
		}
	}
}
