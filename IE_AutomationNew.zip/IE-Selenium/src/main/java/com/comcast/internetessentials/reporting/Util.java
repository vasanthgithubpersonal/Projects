package com.comcast.internetessentials.reporting;

import java.io.BufferedOutputStream;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.zip.ZipOutputStream;

import org.apache.commons.io.FileUtils;
import org.apache.commons.io.filefilter.TrueFileFilter;
import org.apache.tools.zip.ZipEntry;


/**
 * Class to encapsulate utility functions of the framework
 */
public class Util {
	/**
	 * Function to get the separator string to be used for directories and files
	 * based on the current OS
	 * 
	 * @return The file separator string
	 */
	public static String getFileSeparator() {
		return System.getProperty("file.separator");
	}

	/**
	 * Function to return the current time, formatted as per the
	 * DateFormatString setting
	 * 
	 * @param dateFormatString
	 *            The date format string to be applied
	 * @return The current time, formatted as per the date format string
	 *         specified
	 * @see #getCurrentTime()
	 * @see #getFormattedTime(Date, String)
	 */
	public static String getCurrentFormattedTime(String dateFormatString) {
		DateFormat dateFormat = new SimpleDateFormat(dateFormatString);
		Calendar calendar = Calendar.getInstance();
		return dateFormat.format(calendar.getTime());
	}

	/**
	 * Get Current time stamp
	 * 
	 * @return
	 */
	public static String TestName;

	public static String getTimeStamp() {
		Date date = new Date();
		SimpleDateFormat format = new SimpleDateFormat("yyyy_MMM_dd_HH_mm_ss");
		return format.format(date);
	}

	/**
	 * Get relative path of the framework
	 * 
	 * @return
	 */
	public static String getRelativePath() {
		String relativePath = new File(System.getProperty("user.dir"))
				.getAbsolutePath();
		if (relativePath.endsWith("bin")) {
			relativePath = new File(System.getProperty("user.dir")).getParent();
		}
		return relativePath;
	}

	/**
	 * Method to execute the external script
	 * 
	 * @param script
	 */
	public static void executeScript(String script) {
		try {
			ProcessBuilder pb = new ProcessBuilder(script);
			// Start the process.
			Process p = pb.start();
			// Wait for the process to finish.
			p.waitFor();
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
	}
	
	 public void createZipFileOfReport(String reportPath, String testCaseQCName) {
			System.out.println("createZipFileOfReport() for reportPath= " + reportPath);
			File dir = new File(reportPath);
			try {
			    List<File> files = (List<File>) FileUtils.listFiles(dir, TrueFileFilter.INSTANCE, TrueFileFilter.INSTANCE);
			    byte[] b;

			    FileOutputStream fout = new FileOutputStream(reportPath + "\\" + testCaseQCName + ".zip");
			    ZipOutputStream zout = new ZipOutputStream(new BufferedOutputStream(fout));

			    for (int i = 0; i < files.size(); i++) {
				if (files.get(i).getName().contains(testCaseQCName)) {
				    b = new byte[1024];
				    FileInputStream fin = new FileInputStream(files.get(i));
				    zout.putNextEntry(new ZipEntry(files.get(i).getName()));
				    int length;
				    while (((length = fin.read(b, 0, 1024))) > 0) {
					zout.write(b, 0, length);
				    }
				    zout.closeEntry();
				    fin.close();
				}

			    }
			    zout.close();
			    System.out.println("Done: createZipFileOfReport()");

			} catch (Exception e) {
				System.err.println("Exception caught for: " + reportPath + "---" + e.getMessage());
			}
			/*
			 * String fileName = new File(reportPath + testCaseQCName +
			 * ".zip").getName(); String folderName = new File(reportPath +
			 * testCaseQCName + ".zip").getParent();
			 */
		    }

		    /**
		     * Creates the result file
		     *
		     * @param reportPath
		     * @param runStatus
		     */
		    public static void createResultFile(String reportPath, String runStatus) {
		    System.out.println("createResultFile() for reportPath= " + reportPath);
			BufferedWriter writer = null;
			try {
			    writer = new BufferedWriter(new FileWriter(reportPath + "\\result.txt"));
			    writer.write(runStatus);

			} catch (IOException e) {
				System.err.println("Failed to write result file for: " + reportPath + "---" + e.getMessage());
			} finally {
			    try {
				if (writer != null) {
				    writer.close();
				}
			    } catch (IOException e) {
			    	System.err.println("Failed to write result file for: " + reportPath + "---" + e.getMessage());
			    }
			}
		    }
}