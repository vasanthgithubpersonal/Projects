package com.comcast.internetessentials.agent.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;

import com.comcast.internetessentials.libraries.GetParameters;
import com.comcast.internetessentials.libraries.Reports;
import com.comcast.internetessentials.reporting.SeleniumReport;

public class Report extends Logout{

	@FindBy(name = "AppSearchStatus")
	@CacheLookup
	private WebElement _applicationStatus;
	
	@FindBy(id = "edit-submit-status")
	@CacheLookup
	private WebElement _search;
	
	public Report(WebDriver browser, GetParameters getParameters) {
		super(browser,getParameters);
	}
}
