package com.comcast.internetessentials.libraries;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Properties;

/**
 * The EnvironmentParams Program is implemented to read the specific row and
 * column values from the Environments excel sheet based on the key/value pair
 * defined in the framework.properties file
 * 
 * @author 589478
 * @since 2017-02-24
 * @version 1.1
 */

public class EnvironmentParameters {

	/**
	 * Global variables declaration
	 */
	Properties properties;
	String relativePath;

	/**
	 * Default Constructor Read data from the Environments excel sheet
	 */
	public EnvironmentParameters() {
		properties = new Properties();

		try {
			relativePath = new File(System.getProperty("user.dir"))
					.getAbsolutePath();

			if (relativePath.endsWith("bin")) {
				relativePath = new File(System.getProperty("user.dir"))
						.getParent();
			}

			properties.load(new FileInputStream(relativePath
					+ "\\src\\test\\resources" + File.separator
					+ "framework.properties"));

			get_env_data(properties.getProperty("AUT"),
					properties.getProperty("ENV_KEY"));

		} catch (FileNotFoundException ex) {
			ex.printStackTrace();
		} catch (IOException ex) {
			ex.printStackTrace();
		} catch (Exception ex) {
			ex.printStackTrace();
		}

	}

	/**
	 * Assigning the values to the property file
	 * 
	 * @param key
	 *            (required) Key to assign.
	 * @param value
	 *            (required) Value to assign.
	 * @return null
	 */
	public void setValue(String key, String value) {
		properties.setProperty(key.toUpperCase(), value);
	}

	/**
	 * Retrieving the values from the properties file based on the Key
	 * 
	 * @param key
	 *            (required) Key to assign.
	 * @return value will be returned from the properties file based on the key
	 */
	public String getValue(String key) {
		return properties.getProperty(key.toUpperCase());
	}

	/**
	 * Retrieving the data from the Environments excel sheet based on the
	 * environment key provided
	 * 
	 * @param applicationundertest
	 *            (required) Application Name
	 * @param env_key
	 *            (required) Environment Name
	 * @return null
	 */

	public void get_env_data(String applicationundertest, String env_key) {

		/**
		 * Local variables declaration
		 */
		ExcelInteface excelInteface = null;
		String relativePath;
		String xlsPath;
		String xlsSheetName = null;
		ArrayList<String> columnValues, rowValues;
		int rowNumber;

		try {
			relativePath = new File(System.getProperty("user.dir"))
					.getAbsolutePath();

			if (relativePath.endsWith("bin")) {
				relativePath = new File(System.getProperty("user.dir"))
						.getParent();
			}

			xlsPath = relativePath + "\\src\\test\\resources" + File.separator
					+ getValue("ENV_DATA_XLS");

			if (applicationundertest.equalsIgnoreCase("IE"))
				xlsSheetName = "InternetEssentials";

			excelInteface = new ExcelInteface(xlsPath, xlsSheetName);

			rowNumber = excelInteface.getRowNo(0, env_key.toUpperCase());

			if (rowNumber == 0) {
				throw new RuntimeException(
						"Unable to find a row for the Environment " + env_key);
			}

			columnValues = excelInteface.getRowValues(0);
			rowValues = excelInteface.getRowValues(rowNumber);

			retrieveEnvironmentValues(columnValues, rowValues);

			setValue("OVERALL_STATUS", "Passed");

		} catch (Exception ex) {
			ex.printStackTrace();
		}
		
		finally{
			if(excelInteface.fileInputStream != null){
				try {
					excelInteface.fileInputStream.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}

	}

	/**
	 * Storing the environment key/value pairs(Row and Column) into the
	 * properties file
	 * 
	 * @param colValues
	 *            (required) Environment Excel Column
	 * @param rowValues
	 *            (required) Environment Excel Row
	 * @return null
	 */
	private void retrieveEnvironmentValues(ArrayList<String> columnValues,
			ArrayList<String> rowValues) {

		for (int i = 0; i < columnValues.size(); i++) {
			properties.setProperty(columnValues.get(i).toUpperCase(),
					rowValues.get(i));
		}
	}
}
