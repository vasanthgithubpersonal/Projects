package com.comcast.internetessentials.online.pages;

import java.util.List;
import java.util.Random;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.comcast.internetessentials.libraries.Common;
import com.comcast.internetessentials.libraries.GetParameters;

public class TimeSlot extends Common {

	@FindBy(xpath = "//input[@name = 'scheduleSelection']")
	@CacheLookup
	private List<WebElement> _timeSlotSelection;

	@FindBy(xpath = "//*[@id='profInstalTermsCheck']")
	@CacheLookup
	private WebElement _timeSlotConfirm;

	@FindBy(xpath = "//*[@id='submit']")
	@CacheLookup
	private WebElement _timeSlotSubmit;

	@FindBy(xpath = "//*[@id='edit-back']")
	@CacheLookup
	private WebElement _timeSlotBack;
	

	public TimeSlot(WebDriver browser, GetParameters params) {
		super(browser, params);
		PageFactory.initElements(browser, this);
	}

	public void timeSlotSelection() {
		report.addTestLogSection("TimeSlot Selection Page");
		
		if (getParams.getTestPerValue("SSN").equalsIgnoreCase("yes")) {
			if (getParams.getTestPerValue("AutoApproved").equalsIgnoreCase(
					"yes")) {
				
				int size = _timeSlotSelection.size();
				WebElement timeSlot = _timeSlotSelection.get(util.getRandomNumber(size));
				if (waitForElement(timeSlot, 5)) {
					scrollToElement(timeSlot);
					clickCheckboxOrRadioButton(timeSlot);
					clickCheckboxOrRadioButton(_timeSlotConfirm);
					scrollToElementAndClick(_timeSlotSubmit);
					waitforPageLoadComplete();
					
					report.reportPassEvent("TimeSlot Selection", "TimeSlot selected successfully");
				}
				else{
					report.reportSoftFailEvent("TimeSlot Selection","No timeslot to select");
				}
			} else {
				System.out.println("SS");
				report.reportSoftFailEvent("Please select the Autoapproved = 'Yes' in the TestData Excel Sheet","Failed");
			}
		} else {
			report.reportSoftFailEvent("Please select the SSN = 'Yes' in the TestData Excel Sheet","Failed");
		}
	}

}
