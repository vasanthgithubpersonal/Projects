package com.comcast.internetessentials.reporting;

/**
 * Class to encapsulate the reporting settings in the framework
 */
public class ReportSettings {
	private String reportPath;

	/**
	 * Function to get the absolute path where the report is to be stored
	 * 
	 * @return The report path
	 */
	public String getReportPath() {
		return reportPath;
	}

	private String reportName;

	/**
	 * Function to get the name of the report
	 * 
	 * @return The report name
	 */
	public String getReportName() {
		return reportName;
	}

	private int logLevel = 4;

	/**
	 * Function to get the logging level of the reports
	 * @return The log level
	 */
	public int getLogLevel() {
		return logLevel;
	}

	/**
	 * Boolean variable indicating whether HTML reports should be generated
	 */
	public Boolean generateHtmlReports = true;

	/**
	 * Boolean variable indicating whether a screenshot should be captured for
	 * failed/warning steps
	 */
	public Boolean takeScreenshotFailedStep = true;
	
	/**
	 * Boolean variable indicating whether a screenshot should be captured for
	 * passed steps
	 */
	public Boolean takeScreenshotPassedStep = false;

	private String dateFormatString = "dd-MMM-yyyy hh:mm:ss a";

	/**
	 * Function to get a string indicating the format for the date/time to be
	 * used within the report
	 * 
	 * @return The date/time formatting string
	 * @see java.text.SimpleDateFormat
	 */
	public String getDateFormatString() {
		return dateFormatString;
	}

	/**
	 * Function to set a string indicating the format for the date/time to be
	 * used within the report
	 * 
	 * @param dateFormatString
	 *            The date/time formatting string
	 * @see java.text.SimpleDateFormat
	 */
	public void setDateFormatString(String dateFormatString) {
		this.dateFormatString = dateFormatString;
	}

	/**
	 * Constructor to initialize the report settings
	 * 
	 * @param reportPath
	 *            The report path
	 * @param reportName
	 *            The report name
	 */
	public ReportSettings(String reportPath, String reportName) {
		this.reportPath = reportPath;
		this.reportName = reportName;
	}
}