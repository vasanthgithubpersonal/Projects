package com.comcast.internetessentials.agent.pages;

import java.util.ArrayList;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.comcast.internetessentials.libraries.Common;
import com.comcast.internetessentials.libraries.Database;
import com.comcast.internetessentials.libraries.GetParameters;
import com.comcast.internetessentials.libraries.Utilities;

public class AgentApplicationStatus extends Common {

	public AgentApplicationStatus(WebDriver browser, GetParameters params) {
		super(browser, params);
		PageFactory.initElements(browser, this);
	}

	@FindBy(id = "EditFullNamelink")
	@CacheLookup
	private WebElement _fullNameLink;

	@FindBy(xpath = "//*[@id='FullNameDisplay']")
	@CacheLookup
	private WebElement _fullNameText;

	@FindBy(id = "EditTelePhonelink")
	@CacheLookup
	private WebElement _telephoneNumberLink;

	@FindBy(xpath = "//*[@id='telephone1']")
	@CacheLookup
	private WebElement _telephoneNumberText;

	@FindBy(xpath = "//*[@id='frmCustomerDetail']/div[2]/div[2]")
	@CacheLookup
	private WebElement _addressText;

	@FindBy(xpath = "//*[@id='frmCustomerDetail']/div[2]/div[4]")
	@CacheLookup
	private WebElement _dobText;

	@FindBy(xpath = "//*[@id='frmCustomerDetail']/div[9]/div[2]/div[1]")
	@CacheLookup
	private WebElement _applicationStatusText;

	@FindBy(xpath = "//*[@id='ShowSSNLink']")
	@CacheLookup
	private WebElement _viewSSN;

	@FindBy(xpath = "//*[@id='dvSSN']/div[1]/div[2]")
	@CacheLookup
	private WebElement _SSNText;

	@FindBy(xpath = "//*[@id='myModalLabel']")
	@CacheLookup
	private WebElement _SSNPopup;

	@FindBy(xpath = "//*[@id='SSNBlock']/b")
	@CacheLookup
	private WebElement _SSNPopupText;

	@FindBy(id = "UpdateAppstatusLink")
	@CacheLookup
	private WebElement _updateApplicationStatus;

	@FindBy(xpath = "//*[@id='frmCustomerDetail']/div[11]/div[4]/b")
	@CacheLookup
	private WebElement _autoApprovedText;

	@FindBy(id = "EditAccountlink")
	@CacheLookup
	private WebElement _enterAccountNumber;

	@FindBy(id = "EditEmaillink")
	@CacheLookup
	private WebElement _emailId;

	@FindBy(id = "btnCreate1")
	@CacheLookup
	private WebElement _uploadDocument;
	
	public void verifyAgentValues() {
		try {
			
			report.addTestLogSection("Agent Application Status Verification");
				//FirstName Verification
				util.verifyDBValue("Application", "FirstName", util.get("FIRSTNAME"));
				
				//LastName Verification
				util.verifyDBValue("Application", "LastName", util.get("LASTNAME"));
					
				//Telephone Number Verification
				util.verifyDBValue("Application", "TelephoneNumber", util.get("PHONENUMBER"));
				
				//Address Verification
				util.verifyDBValue("Application", "Address", util.get("ADDRESS"));
				
				//DOB Verification
				util.verifyDBValue("Application", "DateOfBirth", util.getDateFormat(util.get("DOB"), "YYYY-MM-DD"));
				
				//SSN Verification
				if(getParams.getTestPerValue("SSN").equalsIgnoreCase("yes")){
                    String ssn = db.getDbColumnValue("Application", "SSN");
                    if(!(ssn.isEmpty()) || !(ssn.toUpperCase() == "NULL")){
                    	report.reportPassEvent("SSN  Verification","Expected and Actual are same");
                    	
                    }
                    else if(getParams.getTestPerValue("SSN").equalsIgnoreCase("No")){
                    	if(ssn.isEmpty() || ssn.toUpperCase() == "NULL"){
                    		report.reportPassEvent("SSN  Verification","Expected and Actual are same");
                    	}
                    }
                    
                    else{
                	report.reportSoftFailEvent("SSN  Verification","Expected and Actual are not same");
                    }
				}
				
				//Application Status Verification
				util.verifyDBValue("Application", "Status", util.get("APPLICATION_STATUS"));
				
				
				//AutoApproved Verification
				if(getParams.getTestPerValue("AutoApproved").equalsIgnoreCase("no") || getParams.getTestPerValue("AutoApproved").equalsIgnoreCase("yes")){
					 String autoApproved = db.getDbColumnValue("Application", "AutoApproved");
					 if(Integer.parseInt(autoApproved) == 1){
						 report.reportPassEvent("Is AutoApproved Verification","Expected is AutoApproved and Actual is AutoApproved are same");
					 }
					 else if(Integer.parseInt(autoApproved) == 0){
						 report.reportPassEvent("Is AutoApproved Verification","Expected is Non AutoApproved and Actual is Non AutoApproved are same");
					 }
					 else{
						 report.reportSoftFailEvent("Is AutoApproved Verification","Expected and Actual are not same");	 
					 }
				}
				//db.updateApplicationStatus(Utilities.applicationNumber);
				

		}catch(Exception ex){
			System.out.println(ex);

		} /*finally {
			Database.disconnectDB();

		}*/

	}

}
