package com.comcast.internetessentials.agent.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.comcast.internetessentials.libraries.GetParameters;
import com.comcast.internetessentials.libraries.Utilities;
import com.comcast.internetessentials.reporting.SeleniumReport;

public class AgentSearch extends Logout{

	@FindBy(name = "ApplicationNumber")
	@CacheLookup
	private WebElement _applicationNumber;
	
	@FindBy(name = "TelephoneNumber")
	@CacheLookup
	private WebElement _telephoneNumber;
	
	@FindBy(id = "txtStreetAdd")
	@CacheLookup
	private WebElement _address;
	
	@FindBy(name = "FirstName")
	@CacheLookup
	private WebElement _firstName;
	
	@FindBy(name = "LastName")
	@CacheLookup
	private WebElement _lastName;
	
	@FindBy(name = "UnitNumber")
	@CacheLookup
	private WebElement _unitNumber;
	
	@FindBy(name="ZipCode")
	@CacheLookup
	private WebElement _zipCode;
	
	@FindBy(name="AccountNumber")
	@CacheLookup
	private WebElement _accountNumber;
	
	@FindBy(id="ApplicationStatus")
	@CacheLookup
	private WebElement _applicationStatus;
	
	@FindBy(xpath="//*[@id='edit-submit']")
	@CacheLookup
	private WebElement _search;
	
	
	public AgentSearch(WebDriver browser, GetParameters getParameters) {
		super(browser,getParameters);
		PageFactory.initElements(browser, this);
		
	}
	
	public void agentSearchApplication(){
		report.addTestLogSection("Agent Application Search Page");
		sendText(_applicationNumber, Utilities.applicationNumber);
		util.reportDoneEvent("Application Number", "Entered Successfully");
		click(_search);
		waitforPageLoadComplete();
	}
	

}
