package com.comcast.internetessentials.agent.pages;

import java.util.NoSuchElementException;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.comcast.internetessentials.libraries.Common;
import com.comcast.internetessentials.libraries.GetParameters;
import com.comcast.internetessentials.libraries.Reports;
import com.comcast.internetessentials.libraries.Utilities;
import com.comcast.internetessentials.reporting.SeleniumReport;

public class Login extends Common{

	@FindBy(id = "username")
	@CacheLookup
	private WebElement _userName;
	
	@FindBy(id = "password")
	@CacheLookup
	private WebElement _password;
	
	@FindBy(xpath = "//button[contains(text(),'Log in')]")
	@CacheLookup
	private WebElement _login;
	
	public Login(WebDriver browser, GetParameters getparameters) {
		super(browser,getparameters);
		PageFactory.initElements(browser, this);
	}
	
	public void loginPage(){
		report.addTestLogSection("Agent Login Page");
		try{
			sendText(_userName, getParams.getEnvPerValue("AGENT_USERNAME"));
			util.reportDoneEvent("UserName", "Entered Successfully");
			sendText(_password, Utilities.data.get("AGENT_PASSWORD"));
			util.reportDoneEvent("Password", "Entered Successfully");
			click(_login);
		}catch(NoSuchElementException ex){
			System.out.println(ex.getMessage());
			throw ex;
		}
		catch(Exception ex){
			System.out.println(ex.getMessage());
		}
		
		waitforPageLoadComplete();
		
	}
	
}
