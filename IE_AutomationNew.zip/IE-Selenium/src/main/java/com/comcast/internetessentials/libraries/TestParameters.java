package com.comcast.internetessentials.libraries;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Hashtable;
import java.util.LinkedHashMap;

/**
 * The TestParameters program is implemented to read the specific row and column
 * values from the IE test data excel sheet based on the test name
 * 
 * @author 589478
 * @since 2017-02-24
 * @version 1.1
 */
public class TestParameters {
	/**
	 * Global variables declaration
	 */
	
	protected LinkedHashMap<String, String> testData;
	//protected Hashtable<String, String> testData;
	protected EnvironmentParameters envParameters;
	private String testName;

	/**
	 * Default Constructor
	 */
	public TestParameters() {
	}

	/**
	 * Parameterized Constructor Read values from the IE TestData excel sheet
	 */
	public TestParameters(EnvironmentParameters envParam, String testName) {
		this.envParameters = envParam;
		this.testName = testName;
		if (!(testName == null) && !testName.equals("")) {
			loadTestData();
		}
	}

	/**
	 * Read data from the Test data excel sheet
	 * 
	 * @return null
	 */
	private void loadTestData() {
		/**
		 * Local variables declaration
		 */
		ExcelInteface excelInteface = null;
		String relativePath = null;
		String xlsPath = null;
		String xlsSheetName = null;
		ArrayList<String> columnValues, rowValues;
		int rowNumber;

		try{
			testData = new LinkedHashMap<String, String>();
			//testData = new Hashtable<String, String>();
			relativePath = new File(System.getProperty("user.dir"))
					.getAbsolutePath();

			if (relativePath.endsWith("bin"))
				relativePath = new File(System.getProperty("user.dir")).getParent();

			xlsPath = relativePath
					+ "\\src\\test\\resources"
					+ File.separator
					+ envParameters.getValue(envParameters.getValue("AUT")
							+ "_TEST_DATA_XLS");

			if (envParameters.getValue("AUT").equalsIgnoreCase("IE")) {
				xlsSheetName = envParameters.getValue(envParameters.getValue("AUT")
						+ "_TEST_DATA_SHEET");
			}

			System.out.println("Data Sheet Path : " + xlsPath + " ## xlsSheetName"
					+ xlsSheetName);

			excelInteface = new ExcelInteface(xlsPath, xlsSheetName);

			rowNumber = excelInteface.getRowNo(0, testName);

			if (rowNumber == 0)
				throw new RuntimeException(
						"Unable to find a row for the test case " + testName);

			// Read the excel column data's
			columnValues = excelInteface.getRowValues(0);

			// Read the excel row data's
			rowValues = excelInteface.getRowValues(rowNumber);

			prepareExcelTestData(columnValues, rowValues);
			
			System.out.println("Value Readed");

		}
		catch(Exception e){
			e.printStackTrace();
		}
		
		finally{
			
			if(excelInteface.fileInputStream != null){
				try {
					excelInteface.fileInputStream.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
		
	}

	/**
	 * Read Row and Column data
	 * 
	 * @param colValues
	 *            (required) collection of excel column data
	 * @param rowValues
	 *            (required) collection of excel row data
	 * @return null
	 */
	private void prepareExcelTestData(ArrayList<String> colValues,
			ArrayList<String> rowValues) {

		for (int i = 1; i < colValues.size(); i++) {
			if(colValues.get(i).equals("AppStatus")){
				if(rowValues.get(i).equalsIgnoreCase("submitted")){
					setValue("AppState", rowValues.get(i));
				}
				else{
					String[] arr = rowValues.get(i).split("-");
					setValue("AppState", arr[0]);
					if(arr.length > 1)
					{
						setValue("PageToExit", arr[1]);
					}					
				}
				
			}
			else{
				setValue(colValues.get(i), rowValues.get(i));
				//System.out.println(colValues.get(i) + ":" +rowValues.get(i));	
			}
			System.out.println(colValues.get(i) + ":" +rowValues.get(i));
		}

	}

	/**
	 * Store the Row and Column data into the Hash table
	 * 
	 * @param key
	 *            (required) Key to assign.
	 * @param key
	 *            (required) Value to assign.
	 * @return null
	 */
	public void setValue(String key, String value) {
		if (!key.equals(null) && !key.equals("") && !value.equals(null)
				&& !value.equals("")) {
			testData.put(key.toUpperCase(), value);
		}
	}

	/**
	 * Retrieving the values based on the Key
	 * 
	 * @param key
	 *            (required) Key to assign.
	 * @return value will be returned based on the key.
	 *         (or) Null will be returned if there is no matching key found
	 */
	public String getValue(String key) {
		if (testData.containsKey(key.toUpperCase()))
			return testData.get(key.toUpperCase());
		else
			return null;
	}

}
