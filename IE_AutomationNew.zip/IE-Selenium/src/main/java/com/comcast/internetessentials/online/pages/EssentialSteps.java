package com.comcast.internetessentials.online.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.comcast.internetessentials.libraries.Common;
import com.comcast.internetessentials.libraries.GetParameters;
import com.comcast.internetessentials.libraries.Reports;
import com.comcast.internetessentials.reporting.SeleniumReport;

public class EssentialSteps extends Common {

	@FindBy(xpath = "//*[@id='FileUploadReadMail']")
	@CacheLookup
	private WebElement _essentialStepsCompleteByMail;

	@FindBy(xpath = "//*[@id='FileUploadReadNow']")
	@CacheLookup
	private WebElement _essentialStepsUploadDocumentsNow;

	@FindBy(xpath = "//*[@id='FileUploadDocumentLater']")
	@CacheLookup
	private WebElement _essentialStepsUploadDocumentsLater;

	@FindBy(xpath = "//*[@id='edit-back']")
	@CacheLookup
	private WebElement _essentialStepsBack;

	public EssentialSteps(WebDriver browser, GetParameters getParameters) {
		super(browser,getParameters);
		PageFactory.initElements(browser, this);
	}

	public void essentialStepsPage(String docUpload) {
		waitforPageLoadComplete();
		report.addTestLogSection("Essential Steps Page");
		
		switch (docUpload.toUpperCase()) {
		
		case "FILEUPLOADNOW":
			if(waitForElement(_essentialStepsUploadDocumentsNow,10)){
				scrollToElementAndClick(_essentialStepsUploadDocumentsNow);	
				util.reportDoneEvent("DocumentsUploadNow button", "Clicked Successfully");
			}
			break;
		case "FILEUPLOADLATER":
			if(waitForElement(_essentialStepsUploadDocumentsLater,10)){
				scrollToElementAndClick(_essentialStepsUploadDocumentsLater);
				util.reportDoneEvent("DocumentsUploadLater button", "Clicked Successfully");	
			}
			break;
		case "COMPLETEBYMAIL":
			if(waitForElement(_essentialStepsUploadDocumentsNow,10)){
				scrollToElementAndClick(_essentialStepsCompleteByMail);
				util.reportDoneEvent("CompleteByMail button", "Clicked Successfully");
			}
			break;
		default:
			scrollToElementAndClick(_essentialStepsBack);
			break;
		}
		
		util.setApplicationStatus("Initiated", getParams.getTestPerValue("SSN"),getParams.getTestPerValue("AutoApproved"));
		if(util.get("APPLICATION_STATUS").equalsIgnoreCase("initiated")){
			util.verifyDBValue("Application", "Status", util.get("APPLICATION_STATUS"));
		}
	}
}
