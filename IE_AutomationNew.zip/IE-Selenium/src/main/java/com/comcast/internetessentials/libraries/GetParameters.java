package com.comcast.internetessentials.libraries;

public class GetParameters {

	public EnvironmentParameters envParameters;
	public TestParameters testParameters;

	/**
	 * Default Constructor to load the Environment parameters
	 */
	public GetParameters() {
		envParameters = new EnvironmentParameters();
	}

	/**
	 * Parameterized Constructor to load the EnvironmentParameters and
	 * GetParameters
	 * 
	 * @param testScriptName
	 *            (required) TestScript Name to be passed
	 * @param getParameters
	 *            (required) GetParameters to be passed
	 */

	public GetParameters(String testScriptName) {
		envParameters = new EnvironmentParameters();
		if (testScriptName != null || testParameters == null) {
			testParameters = new TestParameters(envParameters, testScriptName);
		}

	}

	/**
	 * This program is implemented to retrieve the value based on the Key from
	 * the Test Data Excel sheet
	 * 
	 * @param Key
	 *            (required) Key to be passed
	 * 
	 * @return value will be returned based on the key
	 */
	public String getTestPerValue(String key) {
		String testValue = testParameters.getValue(key);
		return testValue;
	}

	/**
	 * This program is implemented to retrieve the value based on the Key from
	 * the Environments Excel sheet
	 * 
	 * @param Key
	 *            (required) Key to be passed
	 * 
	 * @return value will be returned based on the key
	 */

	public String getEnvPerValue(String key) {
		String envValue = envParameters.getValue(key);
		return envValue;
	}

	/**
	 * This program is implemented to verify the TAKES_SCREENSHOT_PASS property
	 * from the framework.properties file
	 * 
	 * @param Key
	 *            (required) Key to be passed
	 * 
	 * @return true/false
	 */
	public boolean isTestSettingTrue(String key) {
		String val;
		val = envParameters.getValue(key);
		if (val == null) {
			return (false);
		}

		val = val.trim();
		return (isValueTrue(val));
	}

	/**
	 * This program is implemented to verify the True/False value in the framework.properties file
	 * 
	 * @param Key
	 *            (required) Key to be passed
	 * 
	 * @return true/false
	 */

	public boolean isValueTrue(String val) {
		if (val == null) {
			return (false);
		}
		val = val.trim();
		if (val.equalsIgnoreCase("true")) {
			return (true);
		}

		if (val.matches("^[0-9]+$")) {
			int ilw = Integer.parseInt(val);
			return (ilw != 0);
		}

		return (false);
	}

}
