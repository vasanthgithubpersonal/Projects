package com.comcast.internetessentials.test;

import java.io.IOException;

import com.comcast.internetessentials.libraries.Browser;
import com.comcast.internetessentials.libraries.Database;
import com.comcast.internetessentials.libraries.GetParameters;
import com.comcast.internetessentials.libraries.Reports;

import org.testng.annotations.*;

public class Customer extends Reports {

	private Browser browser = null;

	@Test
	public void HUD_WithoutSSN_DocumentsUploadLater() throws IOException {

		try{
			
			String testName = Thread.currentThread().getStackTrace()[1]
					.getMethodName();

			browser = new Browser("CUSTOMER", testName);
			browser.onlinePortal().basicDetails()
					.basicDetialsPage(Browser.getParams.getTestPerValue("Email"));
			browser.onlinePortal().personalDetails()
					.personalDetailspage(Browser.getParams.getTestPerValue("SSN"));
			browser.onlinePortal().programTypes().programSelectionPage();
			browser.onlinePortal()
					.essentialSteps()
					.essentialStepsPage(
							Browser.getParams.getTestPerValue("DocUploadButton"));
			//browser.onlinePortal().documentsUpload().programTypesDocumentUploadPage();
			browser.onlinePortal().reviewAndConfirm().reviewAndConfirmPage();

			browser = new Browser("AGENT", testName);
			browser.agentPortal().login().loginPage();
			browser.agentPortal().agentSearch().agentSearchApplication();
			browser.agentPortal().agentApplicationStatus().verifyAgentValues();
			}
		finally{
			browser.closeBrowser();
			Database.disconnectDB();	
		}
		

	}

	@Test
	public void NSLP_WithSSN_DocumentsUpload() throws IOException {

		
		try {
			String testName = Thread.currentThread().getStackTrace()[1]
					.getMethodName();
			
			
				browser = new Browser("CUSTOMER", testName);

				browser.onlinePortal()
						.basicDetails()
						.basicDetialsPage(
								Browser.getParams.getTestPerValue("Email"));
				browser.onlinePortal()
						.personalDetails()
						.personalDetailspage(
								Browser.getParams.getTestPerValue("SSN"));
				browser.onlinePortal().programTypes().programSelectionPage();
				browser.onlinePortal()
						.essentialSteps()
						.essentialStepsPage(
								Browser.getParams
										.getTestPerValue("DocUploadButton"));
				browser.onlinePortal().documentsUpload().programTypesDocumentUploadPage();
				browser.onlinePortal().reviewAndConfirm().reviewAndConfirmPage();

				browser = new Browser("AGENT", testName);
				browser.agentPortal().login().loginPage();
				browser.agentPortal().agentSearch().agentSearchApplication();
				browser.agentPortal().agentApplicationStatus().verifyAgentValues();
		} finally {
			browser.closeBrowser();
			Database.disconnectDB();
		}

	}

	@Test
	public void NSLP_CC_Save_Retrieve() throws IOException {
		try {
		String testName = Thread.currentThread().getStackTrace()[1]
				.getMethodName();
		browser = new Browser("CUSTOMER", testName);

		browser.onlinePortal().basicDetails()
				.basicDetialsPage(Browser.getParams.getTestPerValue("Email"));
		browser.onlinePortal().personalDetails()
				.personalDetailspage(Browser.getParams.getTestPerValue("SSN"));
		browser.onlinePortal().programTypes().programSelectionPage();
		browser.onlinePortal().retrieveApplication().homePage();
		 }
		catch(Exception ex){
			System.out.println(ex.getMessage());
		}
		finally {
		 browser.closeBrowser();
		 Database.disconnectDB();
		 }
	}

	@Test
	public void US1019302_Agent_New_Online_Alternate_Doc_Description_CC_A(){
		String testName = Thread.currentThread().getStackTrace()[1]
				.getMethodName();
		browser = new Browser("CUSTOMER", testName);

		browser.onlinePortal().basicDetails().basicDetialsPage(Browser.getParams.getTestPerValue("Email"));
		browser.onlinePortal().personalDetails().personalDetailspage(Browser.getParams.getTestPerValue("SSN"));
		browser.onlinePortal().programTypes().programSelectionPage();
		browser.onlinePortal().essentialSteps().essentialStepsPage(Browser.getParams.getTestPerValue("DocUploadButton"));
		browser.onlinePortal().documentsUpload().programTypesDocumentUploadPage();
		browser.onlinePortal().reviewAndConfirm().reviewAndConfirmPage();

		browser = new Browser("AGENT", testName);
		browser.agentPortal().login().loginPage();
		browser.agentPortal().agentSearch().agentSearchApplication();
		browser.agentPortal().agentApplicationStatus().verifyAgentValues();
		browser.agentPortal().agentDocuments().verifyDocumentsAlternateText();
		
	}
	
	@Test
	public void US1019302_Agent_New_Online_Alternate_Doc_Description_NSLP2_A(){
		String testName = Thread.currentThread().getStackTrace()[1]
				.getMethodName();
		browser = new Browser("CUSTOMER", testName);

		browser.onlinePortal().basicDetails().basicDetialsPage(Browser.getParams.getTestPerValue("Email"));
		browser.onlinePortal().personalDetails().personalDetailspage(Browser.getParams.getTestPerValue("SSN"));
		browser.onlinePortal().programTypes().programSelectionPage();
		browser.onlinePortal().essentialSteps().essentialStepsPage(Browser.getParams.getTestPerValue("DocUploadButton"));
		browser.onlinePortal().documentsUpload().programTypesDocumentUploadPage();
		browser.onlinePortal().reviewAndConfirm().reviewAndConfirmPage();

		browser = new Browser("AGENT", testName);
		browser.agentPortal().login().loginPage();
		browser.agentPortal().agentSearch().agentSearchApplication();
		browser.agentPortal().agentApplicationStatus().verifyAgentValues();
		browser.agentPortal().agentDocuments().verifyDocumentsAlternateText();
		
	}
}
