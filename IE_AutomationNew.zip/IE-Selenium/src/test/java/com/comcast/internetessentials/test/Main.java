package com.comcast.internetessentials.test;

import java.util.concurrent.TimeUnit;

import org.apache.commons.codec.binary.Base64;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import com.comcast.internetessentials.libraries.Common;
import com.comcast.internetessentials.online.pages.DocumentsUpload;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		decryptPassword("Q29tY2FzdCE=");
		/*String agentDocumentDescription = null;
		Common common = new Common();
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\589478\\git\\IE-Selenium_Automation\\src\\test\\seleniumdriver\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.get("http://ieweb-dt-01t.cable.comcast.com/Agent/AgentSearch");
		driver.findElement(By.id("username")).sendKeys("vkp001c");
		driver.findElement(By.id("password")).sendKeys("May@2017");
		driver.findElement(By.xpath("//button[contains(text(),'Log in')]")).click();
		//common.waitforPageLoadComplete();
		driver.findElement(By.name("ApplicationNumber")).sendKeys("100051708148");
		driver.findElement(By.xpath("//*[@id='edit-submit']")).click();
		
		//String[] docs = DocumentsUpload.expectedDocsText.split(":");
		String[] docs = new String[] {"Current or prior school year transcript","Pell Grant Award Letter from the community college"};
		
		for (int i = 0; i < docs.length; i++) {
			boolean found =false;
			for (WebElement elem : driver.findElements(By.xpath("//div[@id = 'UploadDocument']//following::tr[@class = 'row-highlight']/following-sibling::tr/td[1]"))) {
				if(elem.getText().trim().equalsIgnoreCase(docs[i])){
					found = true;
					agentDocumentDescription = elem.getText();
					break;
				}
				else{
					agentDocumentDescription = elem.getText();
				}
			}
			if(found)
			{
				//util.reportPassEvent("Document Alternate Description",docs[i],agentDocumentDescription);
				System.out.println("Original Document Alternate Description " +docs[i] + "Actual Document Alternate Description " +agentDocumentDescription );
			}
			else
			{
				System.out.println("Original Document Alternate Description " +docs[i] + "Actual Document Alternate Description " +agentDocumentDescription );
			}
		}*/
		
		

	}
	
private static void decryptPassword(String password) {
		
		String[] arrPassword = null;

		
		byte[] passwordDecoded = Base64.decodeBase64(password);
		String plainText = new String(passwordDecoded);
		System.out.println(plainText);
		
		
		
	}

}
